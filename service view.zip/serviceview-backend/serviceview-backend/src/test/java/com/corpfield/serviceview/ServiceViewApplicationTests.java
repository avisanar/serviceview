package com.corpfield.serviceview;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceViewApplicationTests {

    @Test
    void contextLoads() {
    }

}
