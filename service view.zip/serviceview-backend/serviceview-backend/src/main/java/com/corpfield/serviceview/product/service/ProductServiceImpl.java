package com.corpfield.serviceview.product.service;

import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.common.exception.ServiceViewException;
import com.corpfield.serviceview.common.utils.AuthUtil;
import com.corpfield.serviceview.organization.enities.Organization;
import com.corpfield.serviceview.organization.facade.OrganizationAdminFacade;
import com.corpfield.serviceview.product.dao.ProductDao;
import com.corpfield.serviceview.product.dto.requestDto.CreateProductReqDto;
import com.corpfield.serviceview.product.dto.requestDto.EditProductReqDto;
import com.corpfield.serviceview.product.dto.pojo.ProductListFilter;
import com.corpfield.serviceview.product.dto.responseDto.ProductResDto;
import com.corpfield.serviceview.product.entities.Product;
import com.corpfield.serviceview.product.facade.ProductFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    OrganizationAdminFacade organizationAdminFacade;

    @Autowired
    ProductFacade productFacade;

    @Autowired
    ProductDao productDao;


    @Override
    public ResponseDto createProduct(CreateProductReqDto reqDto) {
        try {
            String adminUuid = AuthUtil.currentUserUUId();
            Organization organization = this.organizationAdminFacade.findOrganizationByAdminUuid(adminUuid);
            this.productFacade.createProduct(reqDto, organization);
            return new ResponseDto(HttpStatus.OK, "Product Added Successfully");
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto editProduct(EditProductReqDto reqDto) {
        try{
            this.productFacade.editProduct(reqDto);
            return new ResponseDto(HttpStatus.OK, "Product Edited Successfully");
        }catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto getProductsList(ProductListFilter filter) {
        try{
            String adminUuid = AuthUtil.currentUserUUId();
            Organization organization = this.organizationAdminFacade.findOrganizationByAdminUuid(adminUuid);
            long organizationId=organization.getOrganizationId();
            List<Object[]> objProductList=productDao.findAllProducts(filter,organizationId);
            List<ProductResDto> productsList=this.productFacade.mapObjectsToDto(objProductList);
            int productsCount=productDao.findAllProductsCount(filter,organizationId);
            Page<ProductResDto> pagedProducts = new PageImpl<>(productsList, filter.getPageable(), productsCount);
            return new ResponseDto(HttpStatus.OK, pagedProducts);
        }catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto getProductById(long productId) {
        try {
            Product product=this.productFacade.findProductById(productId);
            ProductResDto resDto=ProductResDto.convertEntityToDto(product);
            return new ResponseDto(HttpStatus.OK,resDto);
        }catch (Exception e){
            return ServiceViewException.sendErrorResponse(e);
        }
    }


}
