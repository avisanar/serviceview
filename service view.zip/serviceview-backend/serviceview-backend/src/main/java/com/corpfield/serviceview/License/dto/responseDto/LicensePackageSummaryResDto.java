package com.corpfield.serviceview.License.dto.responseDto;

import lombok.Data;

import java.util.Date;

@Data
public class LicensePackageSummaryResDto {
    private String planSelected;
    private double costPerLicense;
    private Date LicenseValidity;
    private double licenseCost;
    private double previousBalance;
    private double totalCost;
}
