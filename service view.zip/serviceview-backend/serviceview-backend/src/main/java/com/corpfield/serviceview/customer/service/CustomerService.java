package com.corpfield.serviceview.customer.service;

import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.customer.dto.reqDto.CreateCustomerReqDto;
import com.corpfield.serviceview.customer.dto.reqDto.CustomerFilterReqDto;
import com.corpfield.serviceview.customer.dto.reqDto.EditCustomerReqDto;
import org.springframework.data.domain.Pageable;

public interface CustomerService {
    
    ResponseDto createCustomer(CreateCustomerReqDto reqDto);

    ResponseDto findCustomerByNumber(String customerPhoneNumber);

    ResponseDto customerList(CustomerFilterReqDto filter, Pageable pageable);

    ResponseDto getCustomerById(long customerId);

    ResponseDto editCustomer(EditCustomerReqDto reqDto);
}
