package com.corpfield.serviceview.settings.service;

import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.common.exception.ServiceViewException;
import com.corpfield.serviceview.settings.dto.requestDto.DeliveryModeCreateReqDto;
import com.corpfield.serviceview.settings.dto.requestDto.EditDeliveryModeReqDto;
import com.corpfield.serviceview.settings.dto.responseDto.DeliveryModeResDto;
import com.corpfield.serviceview.settings.entities.OrganizationDeliveryMode;
import com.corpfield.serviceview.settings.facade.OrganizationDeliveryModeFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
public class OrganizationDeliveryModeImpl implements OrganizationDeliveryModeService {

    @Autowired
    OrganizationDeliveryModeFacade deliveryModeFacade;

    @Override
    public ResponseDto addDeliveryType(DeliveryModeCreateReqDto reqDto) {
        try {
            OrganizationDeliveryMode deliveryMode = reqDto.convertDtoToEntity();
            deliveryModeFacade.setOrganization(deliveryMode);
            deliveryModeFacade.persistOrganizationDeliveryMode(deliveryMode);
            return new ResponseDto(HttpStatus.OK, "OK", "Delivery Type have been added");
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto findDeliveryModeById(long deliveryModeId) {
        try {
            OrganizationDeliveryMode deliveryMode = deliveryModeFacade.findDeliveryModeById(deliveryModeId);
            DeliveryModeResDto resDto = DeliveryModeResDto.convertEntityToDto(deliveryMode);
            return new ResponseDto(HttpStatus.OK, "OK", resDto);
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto editDeliveryModeStatus(EditDeliveryModeReqDto reqDto) {
        try {
            OrganizationDeliveryMode deliveryMode = deliveryModeFacade.findDeliveryModeById(reqDto.getOrganizationDeliveryModeId());
            reqDto.updateDeliveryMode(deliveryMode);
            deliveryModeFacade.persistOrganizationDeliveryMode(deliveryMode);
            return new ResponseDto(HttpStatus.OK, "OK", "DeliveryMode have been updated");
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

}
