package com.corpfield.serviceview.common.exception;

import com.corpfield.serviceview.common.dto.ResponseDto;
import lombok.extern.log4j.Log4j2;
import org.springframework.http.HttpStatus;

@Log4j2
public class ServiceViewException extends Exception {

    public ServiceViewException(String message) {
        super(message);
    }

    public static ResponseDto sendErrorResponse(Exception e) {
        if (e instanceof ServiceViewException) {
            log.info("Handled Error " + e.getMessage());
            return new ResponseDto(HttpStatus.BAD_REQUEST, e.getMessage());
        }
        log.error("Unhandled Exception Occurred ", e);
        return new ResponseDto(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error Occurred");
    }


}
