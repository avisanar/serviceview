package com.corpfield.serviceview.settings.facade;

import com.corpfield.serviceview.common.exception.ServiceViewException;
import com.corpfield.serviceview.organization.enities.OrganizationAdmin;
import com.corpfield.serviceview.organization.repositories.OrganizationAdminsRepo;
import com.corpfield.serviceview.settings.entities.OrganizationDeliveryMode;
import com.corpfield.serviceview.settings.repositories.OrganizationDeliveryModesRepo;
import com.corpfield.serviceview.utils.AuthUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class OrganizationDeliveryModeFacade {

    @Autowired
    OrganizationDeliveryModesRepo organizationDeliveryModesRepo;

    @Autowired
    OrganizationAdminsRepo organizationAdminsRepo;

    public void persistOrganizationDeliveryMode(OrganizationDeliveryMode deliveryMode) {
        organizationDeliveryModesRepo.save(deliveryMode);
    }

    public OrganizationDeliveryMode findDeliveryModeById(long deliveryModeId) throws Exception {
        Optional<OrganizationDeliveryMode> deliveryModeOptional = organizationDeliveryModesRepo.findById(deliveryModeId);
        return deliveryModeOptional.orElseThrow(() -> new ServiceViewException("DeliveryMode not found"));
    }

    public void setOrganization(OrganizationDeliveryMode deliveryMode) throws Exception {
        String organizationAdminUuid = AuthUtil.currentUserId();
        Optional<OrganizationAdmin> optOrganizationAdmin = this.organizationAdminsRepo.findByOrganizationAdminUuid(organizationAdminUuid);
        optOrganizationAdmin.orElseThrow(() -> new ServiceViewException("OrganizationAdmin not found"));
        if (optOrganizationAdmin.isPresent()) {
            deliveryMode.setOrganization(optOrganizationAdmin.get().getOrganization());
        }
    }

}
