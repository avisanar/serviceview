package com.corpfield.serviceview.settings.dto.pojo;

import lombok.Builder;
import lombok.Data;

import java.util.Date;

@Data
@Builder
public class SettingFilterReqDto {
    private Date fromDate;
    private Date toDate;
}
