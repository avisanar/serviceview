package com.corpfield.serviceview.security.service;

import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.security.dto.OrganizationAdminLoginDto;

public interface AuthenticationService {
    ResponseDto organizationalAdminLogin(OrganizationAdminLoginDto adminUuid);
}
