package com.corpfield.serviceview.employee.controllers;

import com.corpfield.serviceview.common.constants.RoleConstants;
import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.employee.dto.pojo.AdminEmployeeFilterDto;
import com.corpfield.serviceview.employee.dto.requestDto.CreateEmployeeReqDto;
import com.corpfield.serviceview.employee.dto.requestDto.UpdateEmployeeStatusReqDto;
import com.corpfield.serviceview.employee.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class EmployeeController {

    @Autowired
    EmployeeService employeeService;

    @PostMapping("/admin/employee")
    public ResponseEntity<ResponseDto> createEmployee(@RequestBody CreateEmployeeReqDto reqDto) {
        ResponseDto dto = employeeService.createNewEmployee(reqDto);
        return new ResponseEntity<>(dto, HttpStatus.valueOf(dto.getStatusCode()));
    }

    @GetMapping("/admin/employee-exist")
    public ResponseEntity<ResponseDto> findEmployeeExist(
            @RequestParam(value = "phoneNumber") String phoneNumber
    ) {
        ResponseDto dto = employeeService.checkIfEmployeeExistByPhoneNumber(phoneNumber);
        return new ResponseEntity<>(dto, HttpStatus.valueOf(dto.getStatusCode()));
    }

    @GetMapping("/admin/employee/{employeeId}")
    public ResponseEntity<ResponseDto> findEmployeeDetailsById(
            @PathVariable("employeeId") long employeeId
    ) {
        ResponseDto dto = employeeService.findEmployeeByEmployeeId(employeeId);
        return new ResponseEntity<>(dto, HttpStatus.valueOf(dto.getStatusCode()));
    }

    @GetMapping("/admin/employee")
    public ResponseEntity<ResponseDto> getAllEmployeeList(
            @PageableDefault(size = RoleConstants.DEFAULT_PAGE_SIZE) Pageable pageable,
            @RequestParam(value = "sortField", defaultValue = "e.employee_id") String sortField,
            @RequestParam(value = "sortMethod", defaultValue = "DESC") String sortMethod,
            @RequestParam(value = "searchKey", required = false) String searchKey,
            @RequestParam(value = "department", required = false) String department,
            @RequestParam(value = "status", required = false) String status,
            @RequestParam(value = "licenceAssigned", required = false) String licenceAssigned
    ) {
        AdminEmployeeFilterDto filter = AdminEmployeeFilterDto.builder()
                .sortField(sortField)
                .sortMethod(sortMethod)
                .searchKey(searchKey)
                .department(department)
                .status(status)
                .licenceAssigned(licenceAssigned)
                .pageable(pageable)
                .build();
        ResponseDto dto = employeeService.findAllEmployeesList(filter);
        return new ResponseEntity<>(dto, HttpStatus.valueOf(dto.getStatusCode()));
    }

    @PutMapping("/admin/employee")
    public ResponseEntity<ResponseDto> updateEmployeeStatus(@RequestBody UpdateEmployeeStatusReqDto reqDto) {
        ResponseDto dto = employeeService.editEmployeeStatus(reqDto);
        return new ResponseEntity<>(dto, HttpStatus.valueOf(dto.getStatusCode()));
    }

}
