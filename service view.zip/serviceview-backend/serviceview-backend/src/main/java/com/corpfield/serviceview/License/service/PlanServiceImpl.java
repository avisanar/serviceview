package com.corpfield.serviceview.License.service;

import com.corpfield.serviceview.License.dto.requestDto.CreatePlanReqDto;
import com.corpfield.serviceview.License.dto.responseDto.PlanListResDto;
import com.corpfield.serviceview.License.entities.Plan;
import com.corpfield.serviceview.License.facade.PlanFacade;
import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.common.exception.ServiceViewException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;
import java.util.UUID;

@Service
public class PlanServiceImpl implements PlanService {

    @Autowired
    PlanFacade planFacade;


    @Override
    public ResponseDto createPlan(CreatePlanReqDto dto) {
        try {
            Plan plan = new Plan();
            plan.setPlanUuid((UUID.randomUUID().toString().replace("-", "")));
            plan.setNumberOfDays(dto.getNumberOfDays());
            plan.setPerLicenseCost(dto.getPerLicenseCost());
            planFacade.save(plan);
            return new ResponseDto(HttpStatus.OK, "Plan Created");
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }

    }

    @Override
    public ResponseDto listAllPlans() {
        try {
            List<Plan> plans = planFacade.findAllPlans();
            List<PlanListResDto> plansList = PlanListResDto.convertEntityToDto(plans);
            return new ResponseDto(HttpStatus.OK, plansList);
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }
}
