package com.corpfield.serviceview.order.dto.responseDto;

import com.corpfield.serviceview.customer.entities.Customer;
import com.corpfield.serviceview.order.entities.Order;
import lombok.Data;

import java.util.Date;
import java.util.List;


@Data
public class OrderResDto {
    private long orderId;
    private String customerName;
    private Date orderedOn;
    private Date deliveryOn;
    private String deliveryStatus;
    private String deliveryType;
    private String deliveryPerson;
    private List<OrderProductResDto> orderProductList;

    public static OrderResDto convertEntityToDto(Order order, Customer customer) {
        OrderResDto dto = new OrderResDto();
        dto.setOrderId(order.getOrderId());
        dto.setCustomerName(customer.getCustomerName());
        dto.setOrderedOn(order.getOrderedOn());
        dto.setDeliveryOn(order.getDeliveryOn());
        dto.setDeliveryStatus(order.getDeliveryStatus());
        dto.setDeliveryType(order.getOrganizationDeliveryMode().getDeliveryType());
        dto.setDeliveryPerson(order.getDeliveryPerson());
        return dto;
    }

}
