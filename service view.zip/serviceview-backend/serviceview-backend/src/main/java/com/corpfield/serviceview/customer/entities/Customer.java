package com.corpfield.serviceview.customer.entities;

import com.corpfield.serviceview.common.enities.AuditEntity;
import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "customers")
public class Customer extends AuditEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "customer_id")
    private long customerId;

    @Column(name = "customer_uuid", unique = true, nullable = false)
    private String customerUuid;

    @Column(name = "customer_name")
    private String customerName;

    @Column(name = "customer_phone_number")
    private String customerPhoneNumber;

    @Column(name = "customer_email")
    private String customerEmail;

    @Column(name = "customer_location")
    private String customerLocation;

    @Column(name = "active")
    private boolean active;


}
