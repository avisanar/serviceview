package com.corpfield.serviceview.common.department.dto;

import com.corpfield.serviceview.common.department.entities.OrganizationDepartment;
import lombok.Data;

@Data
public class EditDepartmentReqDto {
    private long organizationDepartmentId;
    private String departmentName;
    private Boolean active;

    public void updateDepartment(OrganizationDepartment department) {
        if (departmentName != null) {
            department.setDepartmentName(departmentName);
        }

        if (active != null) {
            department.setActive(active);
        }
    }

}
