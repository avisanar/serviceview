package com.corpfield.serviceview.License.facade;

import com.corpfield.serviceview.License.entities.Plan;
import com.corpfield.serviceview.License.repositories.PlanRepo;
import com.corpfield.serviceview.common.exception.ServiceViewException;
import lombok.SneakyThrows;
import org.hibernate.service.spi.ServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
public class PlanFacade {

    @Autowired
    PlanRepo planRepo;

    public void save(Plan plan) {
        planRepo.save(plan);
    }

    @SneakyThrows
    public List<Plan> findAllPlans() {
       List<Plan> plans = planRepo.findAll();
       if(plans.isEmpty()){
           throw new ServiceViewException("No Plans are Available");
       }else{
           return plans;
       }
    }

    public Plan findById(long planId) {
        Optional<Plan> plan=planRepo.findById(planId);
        return plan.get();
    }
}
