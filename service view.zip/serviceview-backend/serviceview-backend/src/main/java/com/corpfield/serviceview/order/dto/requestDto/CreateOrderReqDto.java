package com.corpfield.serviceview.order.dto.requestDto;

import com.corpfield.serviceview.common.constants.CommonConstants;
import com.corpfield.serviceview.order.entities.Order;
import lombok.Data;

import java.util.Date;
import java.util.List;
import java.util.UUID;

@Data
public class CreateOrderReqDto {

    private long customerId;
    private String deliveryPerson;
    private long deliveryModeId;
    private String deliveryStatus;
    private Date orderedOn;
    private Date deliveryOn;
    private List<OrderProductReqDto> productReqDtoList;

    public Order convertDtoToEntity() {
        Order order = new Order();
        order.setDeliveryPerson(deliveryPerson);
        order.setOrderUuid(UUID.randomUUID().toString().replace("-", ""));
        order.setOrderedOn(orderedOn);
        order.setDeliveryOn(deliveryOn);
        order.setDeliveryStatus(CommonConstants.READY);
        return order;
    }

}
