package com.corpfield.serviceview.dashboard.facade;

import com.corpfield.serviceview.dashboard.dto.OverviewResDto;
import com.corpfield.serviceview.organization.enities.Organization;
import com.corpfield.serviceview.organization.enities.OrganizationAdmin;
import com.corpfield.serviceview.organization.repositories.OrganizationAdminsRepo;
import com.corpfield.serviceview.organization.repositories.OrganizationRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
public class DashboardFacade {

    @Autowired
    OrganizationAdminsRepo organizationAdminsRepo;

    public Organization findOrganizationByAdminUuid(String adminUuid) {
        Optional<OrganizationAdmin> organizationAdmin=organizationAdminsRepo.findByOrganizationAdminUuid(adminUuid);
        return organizationAdmin.get().getOrganization();

    }

    public List<OverviewResDto> mapObjectsToDto(List<Object[]> detailsObjects) {
        List<OverviewResDto> resDto=detailsObjects.stream()
                .map(OverviewResDto::convertObjToDto)
                .collect(Collectors.toList());
        return resDto;
    }

    public String getTodayDate() {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();
        String today=formatter.format(date);
        return today;
    }
}
