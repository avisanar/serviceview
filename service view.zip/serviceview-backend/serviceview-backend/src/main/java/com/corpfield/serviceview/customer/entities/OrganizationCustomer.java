package com.corpfield.serviceview.customer.entities;

import com.corpfield.serviceview.common.enities.AuditEntity;
import com.corpfield.serviceview.organization.enities.Organization;
import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "organization_customers")
public class OrganizationCustomer extends AuditEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "organization_customer_id")
    private long organizationCustomerId;

    @Column(name = "organization_customer_uuid", unique = true, nullable = false)
    private String organizationCustomerUuid;

    @Column(name = "active")
    private boolean active;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id")
    private Customer customer;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "organization_id")
    private Organization organization;
}
