package com.corpfield.serviceview.employee.repositories;

import com.corpfield.serviceview.employee.entities.OrganizationEmployee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface OrganizationEmployeesRepo extends JpaRepository<OrganizationEmployee,Long> {

    Optional<OrganizationEmployee> findByOrganizationEmployeeUuid(String organizationEmployeeUuid);


    Optional<OrganizationEmployee> findByEmployeeEmployeeId(long employeeId);

    Optional<OrganizationEmployee> findByOrganizationOrganizationId(long organizationId);

    Optional<Long> countByOrganizationOrganizationId(long organizationId);

    Optional<OrganizationEmployee> findByEmployeeEmployeeIdAndOrganizationOrganizationId(long employeeId, long organizationId);
}
