package com.corpfield.serviceview.dashboard.controllers;

import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.common.utils.ResponseUtil;
import com.corpfield.serviceview.dashboard.service.DashboardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DashboardController {

    @Autowired
    DashboardService dashboardService;

    @GetMapping("/admin/dashboard-overview")
        public ResponseEntity<ResponseDto> getOverviewDetails(){
        ResponseDto response=dashboardService.getOverviewDetails();
        return ResponseUtil.generateResponse(response);
    }
}
