package com.corpfield.serviceview.organization.dto.responseDto;

import com.corpfield.serviceview.organization.enities.Organization;
import com.corpfield.serviceview.organization.enities.OrganizationAdmin;
import lombok.Data;

@Data
public class OrganizationAdminProfileResDto {
    private String organizationDomainName;
    private String organizationName;
    private String contactNumber;
    private String emailAddress;

    public OrganizationAdminProfileResDto(OrganizationAdmin organizationAdmin){
        Organization organization = organizationAdmin.getOrganization();
        this.setOrganizationDomainName(organization.getOrganizationDomainName());
        this.setOrganizationName(organization.getOrganizationName());
        this.setContactNumber(organizationAdmin.getPhone());
        this.setEmailAddress(organizationAdmin.getEmail());

    }
}
