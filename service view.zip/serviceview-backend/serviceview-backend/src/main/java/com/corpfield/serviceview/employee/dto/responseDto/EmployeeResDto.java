package com.corpfield.serviceview.employee.dto.responseDto;

import com.corpfield.serviceview.employee.entities.Employee;
import com.corpfield.serviceview.employee.entities.OrganizationEmployee;
import lombok.Data;

@Data
public class EmployeeResDto {
    private long employeeId;
    private String fullName;
    private String email;
    private String gender;
    private String phoneNumber;
    private boolean active;
    private long organizationDepartmentId;
    private boolean licenseAssigned;
    private double activeTickets;

    public static EmployeeResDto convertEntityToDto(Employee employee, OrganizationEmployee organizationEmployee) {
        EmployeeResDto dto = new EmployeeResDto();
        dto.setEmployeeId(employee.getEmployeeId());
        if (employee.getLastName() != null) {
            dto.setFullName(employee.getFirstName() + " " + employee.getLastName());
        }
        dto.setFullName(employee.getFirstName());
        dto.setEmail(employee.getEmail());
        dto.setGender(employee.getGender());
        dto.setPhoneNumber(employee.getPhoneNumber());
        dto.setActive(organizationEmployee.isActive());
        dto.setOrganizationDepartmentId(organizationEmployee.getOrganizationDepartment().getOrganizationDepartmentId());
        dto.setLicenseAssigned(organizationEmployee.isLicenseAssigned());
        return dto;
    }

}
