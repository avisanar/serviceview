package com.corpfield.serviceview.common.constants;

public class CommonConstants {
    public static final int DEFAULT_PAGE_SIZE = 10;

    //Order Delivery Status

    public static final String READY = "Ready";
    public static final String IN_PROGRESS = "In Progress";
    public static final String DELIVERY = "Delivery";
    public static final String CANCELLED = "Cancelled";
}
