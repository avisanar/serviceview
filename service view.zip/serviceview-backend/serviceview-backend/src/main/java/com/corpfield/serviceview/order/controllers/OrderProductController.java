package com.corpfield.serviceview.order.controllers;

import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.order.dto.requestDto.EditOrderProductReqDto;
import com.corpfield.serviceview.order.service.OrderProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class OrderProductController {

    @Autowired
    OrderProductService orderProductService;

    @PutMapping("/admin/orderProduct")
    public ResponseEntity<ResponseDto> editProduct(
            @RequestBody EditOrderProductReqDto reqDto
    ) {
        ResponseDto dto = orderProductService.editOrderProduct(reqDto);
        return new ResponseEntity<>(dto, HttpStatus.valueOf(dto.getStatusCode()));
    }

    @DeleteMapping("/admin/orderProduct/{orderProductId}")
    public ResponseEntity<ResponseDto> deleteOrderProduct(
            @PathVariable("orderProductId") long orderProductId
    ) {
        ResponseDto dto = orderProductService.removeOrderProduct(orderProductId);
        return new ResponseEntity<>(dto, HttpStatus.valueOf(dto.getStatusCode()));
    }

}
