package com.corpfield.serviceview;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceViewApplication {

    public static void main(String[] args) {
        SpringApplication.run(ServiceViewApplication.class, args);
    }

}
