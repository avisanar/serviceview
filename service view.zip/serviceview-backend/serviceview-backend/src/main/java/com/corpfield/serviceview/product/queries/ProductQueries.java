package com.corpfield.serviceview.product.queries;

public class ProductQueries {
    public static final String GET_PRODUCTS_LIST ="SELECT p.product_id, " +
            "p.product_image_url, " +
            "p.product_name, " +
            "ou.unit_name, " +
            "p.available_stock, " +
            "p.current_price, " +
            "p.new_price, " +
            "p.price_effective_date, " +
            "p.active " +
            " FROM products p " +
            " left join organization_units ou on p.organization_id=ou.organization_id " +
            " where p.organization_id=:organizationId  and " +
            " (p.product_id like :searchKey or  " +
            " p.product_name like :searchKey or " +
            " p.available_stock like :searchKey) " +
            " order by p.product_id " ;

    public static final String GET_PRODUCTS_LIST_COUNT ="SELECT count(*) from products p " +
            "left join organization_units ou on p.organization_id=ou.organization_id " +
            "             where p.organization_id=:organizationId  and " +
            "             (p.product_id like :searchKey or  " +
            "             p.product_name like :searchKey or " +
            "             p.available_stock like :searchKey)  " ;
}
