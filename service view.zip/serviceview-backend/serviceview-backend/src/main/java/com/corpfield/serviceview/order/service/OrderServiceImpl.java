package com.corpfield.serviceview.order.service;

import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.common.exception.ServiceViewException;
import com.corpfield.serviceview.customer.entities.Customer;
import com.corpfield.serviceview.customer.entities.OrganizationCustomer;
import com.corpfield.serviceview.customer.facade.CustomerServiceFacade;
import com.corpfield.serviceview.employee.facade.EmployeeFacade;
import com.corpfield.serviceview.order.dao.OrderDao;
import com.corpfield.serviceview.order.dto.pojo.OrderFilterDto;
import com.corpfield.serviceview.order.dto.requestDto.CreateOrderReqDto;
import com.corpfield.serviceview.order.dto.responseDto.DeliveredOrderDetailResDto;
import com.corpfield.serviceview.order.dto.responseDto.OrderListResDto;
import com.corpfield.serviceview.order.dto.responseDto.OrderResDto;
import com.corpfield.serviceview.order.entities.Order;
import com.corpfield.serviceview.order.facade.OrderFacade;
import com.corpfield.serviceview.order.facade.OrderProductFacade;
import com.corpfield.serviceview.organization.enities.OrganizationAdmin;
import com.corpfield.serviceview.utils.AuthUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    OrderFacade orderFacade;

    @Autowired
    OrderProductFacade orderProductFacade;

    @Autowired
    EmployeeFacade employeeFacade;

    @Autowired
    OrderDao orderDao;

    @Autowired
    CustomerServiceFacade customerServiceFacade;


    @Override
    public ResponseDto createOrder(CreateOrderReqDto reqDto) {
        try {
            Order order = reqDto.convertDtoToEntity();
            orderFacade.setCustomer(order, reqDto.getCustomerId());
            orderFacade.setOrganization(order);
            orderFacade.setDeliveryMode(order, reqDto.getDeliveryModeId());
            orderProductFacade.setProductsForOrder(order, reqDto.getProductReqDtoList());
            orderFacade.persistOrder(order);
            return new ResponseDto(HttpStatus.OK, "OK", "Order Created Successfully");
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto findOrderList(OrderFilterDto filter) {
        try {
            String organizationAdminUuid = AuthUtil.currentUserId();
            OrganizationAdmin admin = employeeFacade.findAuthOrganization(organizationAdminUuid);
            List<OrderListResDto> orderListDto = orderFacade.getOrderListSorted(filter, admin);
            int totalCount = orderDao.findOrderListCount(filter, admin);
            Page<OrderListResDto> pagedOrder = new PageImpl<>(orderListDto, filter.getPageable(), totalCount);
            return new ResponseDto(HttpStatus.OK, "OK", pagedOrder);
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto viewOrderDetailsByOrderId(long orderId) {
        try {
            Order order = orderFacade.findOrderByOrderId(orderId);
            Customer customer = customerServiceFacade.findCustomerByCustomerId(order.getCustomer().getCustomerId());
            OrderResDto orderDto = OrderResDto.convertEntityToDto(order, customer);
            orderProductFacade.mapProductToOrder(orderDto);
            return new ResponseDto(HttpStatus.OK, "OK", orderDto);
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto findDeliveredDetail(long orderId) {
        try {
            Order order = orderFacade.findOrderByOrderId(orderId);
            Customer customer = customerServiceFacade.findCustomerByCustomerId(order.getCustomer().getCustomerId());
            DeliveredOrderDetailResDto deliveredDto = DeliveredOrderDetailResDto.convertEntityToDto(order, customer);
            orderProductFacade.mapDeliveredProductForOrder(deliveredDto);
            return new ResponseDto(HttpStatus.OK, "OK", deliveredDto);
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

}
