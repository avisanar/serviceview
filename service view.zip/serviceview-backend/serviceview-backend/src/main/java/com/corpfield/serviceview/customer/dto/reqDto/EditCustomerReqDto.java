package com.corpfield.serviceview.customer.dto.reqDto;

import com.corpfield.serviceview.customer.entities.Customer;
import lombok.Data;

@Data
public class EditCustomerReqDto {
    private long customerId;
    private String customerName;
    private String customerPhoneNumber;
    private String customerEmail;
    private String customerLocation;
    private Boolean active;

   public void updateCustomer(Customer customer) {
        customer.setCustomerName(this.customerName);
        customer.setCustomerPhoneNumber(this.customerPhoneNumber);
        customer.setCustomerEmail(this.customerEmail);
        customer.setCustomerLocation(this.customerLocation);
        customer.setActive(this.active);
    }
}

