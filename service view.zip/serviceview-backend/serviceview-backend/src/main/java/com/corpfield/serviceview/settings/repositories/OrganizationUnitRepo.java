package com.corpfield.serviceview.settings.repositories;

import com.corpfield.serviceview.settings.entities.OrganizationUnit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface OrganizationUnitRepo extends JpaRepository<OrganizationUnit,Long> {

    Optional<OrganizationUnit> findByUnitName(String unitName);

    List<OrganizationUnit> findByOrganizationOrganizationId(long organizationId);
}
