package com.corpfield.serviceview.order.repositories;

import com.corpfield.serviceview.order.entities.OrderProduct;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrderProductsRepo extends JpaRepository<OrderProduct, Long> {

    List<OrderProduct> findByOrderOrderId(long orderId);

}
