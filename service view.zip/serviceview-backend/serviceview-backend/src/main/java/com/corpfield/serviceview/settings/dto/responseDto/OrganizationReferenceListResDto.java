package com.corpfield.serviceview.settings.dto.responseDto;

import com.corpfield.serviceview.settings.entities.OrganizationSetting;
import lombok.Data;

@Data
public class OrganizationReferenceListResDto {
    private String gst;
    private String referencePrefix;
    private String referenceNumber;
    private String termsAndConditions;

    public static OrganizationReferenceListResDto convertObjToDto(OrganizationSetting organizationSetting) {
        OrganizationReferenceListResDto dto = new OrganizationReferenceListResDto();
        dto.setGst(organizationSetting.getGst());
        dto.setReferencePrefix(organizationSetting.getReferencePrefix());
        dto.setReferenceNumber(organizationSetting.getReferenceNumber());
        dto.setTermsAndConditions(organizationSetting.getTermsAndConditions());
        return dto;
    }
}
