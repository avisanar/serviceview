package com.corpfield.serviceview.order.dto.responseDto;

import com.corpfield.serviceview.customer.entities.Customer;
import com.corpfield.serviceview.order.entities.Order;
import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
public class DeliveredOrderDetailResDto {

    private long customerId;
    private String customerName;
    private String deliveryStatus;
    private long orderId;
    private Date orderedOn;
    private Date deliveredOn;
    private String deliveryType;
    private String deliveryPerson;
    private List<ProductForDeliverResDto> orderProductList;

    public static DeliveredOrderDetailResDto convertEntityToDto(Order order, Customer customer) {
        DeliveredOrderDetailResDto dto = new DeliveredOrderDetailResDto();
        dto.setCustomerId(customer.getCustomerId());
        dto.setCustomerName(customer.getCustomerName());
        dto.setDeliveryStatus(order.getDeliveryStatus());
        dto.setOrderId(order.getOrderId());
        dto.setOrderedOn(order.getOrderedOn());
        dto.setDeliveredOn(order.getDeliveryOn());
        dto.setDeliveryType(order.getOrganizationDeliveryMode().getDeliveryType());
        dto.setDeliveryPerson(order.getDeliveryPerson());
        return dto;
    }

}
