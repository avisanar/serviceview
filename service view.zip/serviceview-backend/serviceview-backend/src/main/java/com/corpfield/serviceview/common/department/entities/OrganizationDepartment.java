package com.corpfield.serviceview.common.department.entities;

import com.corpfield.serviceview.common.enities.AuditEntity;
import com.corpfield.serviceview.organization.enities.Organization;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@EqualsAndHashCode(callSuper = true)
@Data
@Entity
@Table(name = "organization_departments")
public class OrganizationDepartment extends AuditEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "organization_department_id")
    private long organizationDepartmentId;

    @Column(name = "department_name")
    private String departmentName;

    @Column(name = "active")
    private boolean active;

    @ManyToOne
    @JoinColumn(name = "organization_id")
    @NotNull
    private Organization organization;

}
