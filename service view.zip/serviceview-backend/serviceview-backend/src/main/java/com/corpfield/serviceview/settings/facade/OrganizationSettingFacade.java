package com.corpfield.serviceview.settings.facade;

import com.corpfield.serviceview.common.department.entities.OrganizationDepartment;
import com.corpfield.serviceview.common.exception.ServiceViewException;
import com.corpfield.serviceview.customer.facade.CustomerServiceFacade;
import com.corpfield.serviceview.organization.enities.OrganizationAdmin;
import com.corpfield.serviceview.organization.repositories.OrganizationAdminsRepo;
import com.corpfield.serviceview.settings.dao.OrganizationSettingDao;
import com.corpfield.serviceview.settings.dto.pojo.SettingFilterReqDto;
import com.corpfield.serviceview.settings.dto.responseDto.OrganizationDepartmentListResDto;
import com.corpfield.serviceview.settings.dto.responseDto.OrganizationReferenceListResDto;
import com.corpfield.serviceview.settings.dto.responseDto.OrganizationSettingListResDto;
import com.corpfield.serviceview.settings.dto.responseDto.OrganizationUnitListResDto;
import com.corpfield.serviceview.settings.dto.responseDto.OrganizationDeliveryModeListResDto;
import com.corpfield.serviceview.settings.entities.OrganizationDeliveryMode;
import com.corpfield.serviceview.settings.entities.OrganizationSetting;
import com.corpfield.serviceview.settings.entities.OrganizationUnit;
import com.corpfield.serviceview.settings.repositories.OrganizationDeliveryModesRepo;
import com.corpfield.serviceview.settings.repositories.OrganizationDepartmentListRepo;
import com.corpfield.serviceview.settings.repositories.OrganizationSettingRepo;
import com.corpfield.serviceview.settings.repositories.OrganizationUnitRepo;
import com.corpfield.serviceview.utils.AuthUtil;
import org.hibernate.service.spi.ServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
public class OrganizationSettingFacade {

    @Autowired
    OrganizationAdminsRepo organizationAdminsRepo;

    @Autowired
    OrganizationSettingRepo organizationSettingRepo;

    @Autowired
    OrganizationUnitRepo organizationUnitRepo;

    @Autowired
    OrganizationDepartmentListRepo organizationDepartmentListRepo;

    @Autowired
    OrganizationDeliveryModesRepo organizationDeliveryModesRepo;

    @Autowired
    OrganizationSettingDao organizationSettingDao;

    @Autowired
    CustomerServiceFacade customerServiceFacade;

    public void setOrganization(OrganizationSetting organizationSetting) {
        String organizationAdminUuid = AuthUtil.currentUserId();
        Optional<OrganizationAdmin> organizationAdminOptional = this.organizationAdminsRepo.findByOrganizationAdminUuid(organizationAdminUuid);
        organizationAdminOptional.orElseThrow(() -> new ServiceException("Organization not found"));
        if (organizationAdminOptional.isPresent()) {
            organizationSetting.setOrganization(organizationAdminOptional.get().getOrganization());
        }
    }

    public OrganizationSetting findOrganizationSettingsById(long organizationSettingsId) throws ServiceViewException {
        Optional<OrganizationSetting> optionalOrganizationSetting = this.organizationSettingRepo.findById(organizationSettingsId);
        optionalOrganizationSetting.orElseThrow(() -> new ServiceViewException("Organization Settings not found"));
        return optionalOrganizationSetting.get();
    }

    public List<OrganizationSettingListResDto> findListOfSetting(List<Object[]> settingsObject, SettingFilterReqDto filter) {
        List<OrganizationSettingListResDto> settingsList = settingsObject.stream()
                .map(OrganizationSettingListResDto::convertObjToDto)
                .collect(Collectors.toList());
        mapUnitsToSettings(settingsList);
        mapDepartmentToSettings(settingsList,filter);
        mapReferenceToSettings(settingsList);
        mapDeliveryModeToSettings(settingsList,filter);
        return settingsList;
    }

    private List<OrganizationSettingListResDto> mapDeliveryModeToSettings(List<OrganizationSettingListResDto> settingsList,SettingFilterReqDto filter) {
        String organizationAdminUuid = AuthUtil.currentUserId();
        OrganizationAdmin organizationAdmin = customerServiceFacade.findAuthOrganization(organizationAdminUuid);
        for(OrganizationSettingListResDto dto : settingsList){
            List<Object[]>deliveryModeList=this.organizationSettingDao.findDeliveryModeList(organizationAdmin,filter);
            List<OrganizationDeliveryModeListResDto>deliveryModeListResDto=deliveryModeList.stream()
                    .map(OrganizationDeliveryModeListResDto::convertObjToDto)
                    .collect(Collectors.toList());
            dto.setOrganizationDeliveryModeList(deliveryModeListResDto);
        }
        return settingsList;
    }

    private List<OrganizationSettingListResDto> mapReferenceToSettings(List<OrganizationSettingListResDto> settingsList) {
        for(OrganizationSettingListResDto dto : settingsList){
            List<OrganizationSetting>referenceList = this.organizationSettingRepo.findByOrganizationOrganizationId(dto.getOrganizationId());
            List<OrganizationReferenceListResDto>referenceListResDto=referenceList.stream()
                    .map(OrganizationReferenceListResDto::convertObjToDto)
                    .collect(Collectors.toList());
            dto.setOrganizationReferenceList(referenceListResDto);
        }
        return settingsList;
    }

    private List<OrganizationSettingListResDto> mapDepartmentToSettings(List<OrganizationSettingListResDto> settingsList,SettingFilterReqDto filter) {
        String organizationAdminUuid = AuthUtil.currentUserId();
        OrganizationAdmin organizationAdmin = customerServiceFacade.findAuthOrganization(organizationAdminUuid);
        for(OrganizationSettingListResDto dto : settingsList){
            List<Object[]>departmentList=this.organizationSettingDao.findDepartmentList(organizationAdmin,filter);
            List<OrganizationDepartmentListResDto>departmentListResDto=departmentList.stream()
                            .map(OrganizationDepartmentListResDto::convertObjToDto)
                            .collect(Collectors.toList());
            dto.setOrganizationDepartmentList(departmentListResDto);
        }
        return settingsList;
    }

    private List<OrganizationSettingListResDto> mapUnitsToSettings(List<OrganizationSettingListResDto> settingsList) {
        for (OrganizationSettingListResDto dto : settingsList) {
            List<OrganizationUnit> unitList = this.organizationUnitRepo.findByOrganizationOrganizationId(dto.getOrganizationId());
            List<OrganizationUnitListResDto> unitListResDto = unitList.stream()
                    .map(OrganizationUnitListResDto::convertObjToDto)
                    .collect(Collectors.toList());
            dto.setOrganizationUnitList(unitListResDto);
        }
        return settingsList;
    }
}
