package com.corpfield.serviceview.employee.queries;

public class EmployeeQueries {

    public static final String GET_EMPLOYEE_LIST_SORTED = "SELECT  " +
            "oe.organization_employee_uuid, " +
            "e.first_name, " +
            "e.last_name, " +
            "e.phone_number, " +
            "od.department_name, " +
            "oe.license_assigned, " +
            "oe.active " +
            "FROM organization_employees oe " +
            "INNER JOIN employees e on e.employee_id = oe.employee_id " +
            "INNER JOIN organization_departments od on od.organization_department_id = oe.organization_department_id " +
            "INNER JOIN organizations o on o.organization_id = oe.organization_id " +
            "where " +
            "o.organization_id =:organizationId and " +
            "(e.first_name like :searchKey or e.last_name like :searchKey or " +
            "e.phone_number like :searchKey or od.department_name like :searchKey) ";

    public static final String GET_EMPLOYEE_LIST_COUNT = "SELECT " +
            "count(*) " +
            "FROM organization_employees oe " +
            "INNER JOIN employees e on e.employee_id = oe.employee_id " +
            "INNER JOIN organization_departments od on od.organization_department_id = oe.organization_department_id " +
            "INNER JOIN organizations o on o.organization_id = oe.organization_id " +
            "where " +
            "o.organization_id =:organizationId and " +
            "(e.first_name like :searchKey or e.last_name like :searchKey or " +
            "e.phone_number like :searchKey or od.department_name like :searchKey) ";

}
