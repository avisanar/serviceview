package com.corpfield.serviceview.common.constants;

public class RoleConstants {
    public static final int DEFAULT_PAGE_SIZE = 10;
    public static final String INTERNAL_ADMIN = "INTERNAL_ADMIN";
    public static final String ORGANIZATIONAL_SUPER_ADMIN = "ORGANIZATIONAL_ADMIN";
}
