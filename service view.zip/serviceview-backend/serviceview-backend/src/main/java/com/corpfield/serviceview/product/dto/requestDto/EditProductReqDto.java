package com.corpfield.serviceview.product.dto.requestDto;

import lombok.Data;

import java.util.Date;

@Data
public class EditProductReqDto {
    private long productId;
    private String productName;
    private long unitId;
    private long availableStock;
    private double currentPrice;
    private double newPrice;
    private Date priceEffectiveDate;
    private boolean status;
}
