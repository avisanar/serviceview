package com.corpfield.serviceview.employee.dao;

import com.corpfield.serviceview.employee.dto.pojo.AdminEmployeeFilterDto;
import com.corpfield.serviceview.employee.queries.EmployeeQueries;
import com.corpfield.serviceview.organization.enities.OrganizationAdmin;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

import static com.corpfield.serviceview.utils.QueryUtils.*;

@Component
public class EmployeeDao {

    @PersistenceContext
    EntityManager entityManager;

    public List<Object[]> findEmployeeList(AdminEmployeeFilterDto filter, OrganizationAdmin admin) {

        String sql = EmployeeQueries.GET_EMPLOYEE_LIST_SORTED;
        sql = addFilterArgs(sql, "oe.active", filter.getStatus());
        sql = addFilterArgs(sql, "oe.license_assigned", filter.getLicenceAssigned());
        sql = addFilterArgs(sql, "od.department_name", filter.getDepartment());
        sql = addSortArgs(sql, filter.getSortField(), filter.getSortMethod());
        Pageable pageable = filter.getPageable();
        Query query = entityManager.createNativeQuery(sql)
                .setParameter("searchKey", setSearchKey(filter.getSearchKey()))
                .setParameter("organizationId", admin.getOrganization().getOrganizationId())
                .setFirstResult(pageable.getPageNumber() * pageable.getPageSize())
                .setMaxResults(pageable.getPageSize());

        return query.getResultList();
    }

    public int getEmployeeListCount(AdminEmployeeFilterDto filter, OrganizationAdmin admin) {
        String sql = EmployeeQueries.GET_EMPLOYEE_LIST_COUNT;
        sql = addFilterArgs(sql, "oe.active", filter.getStatus());
        sql = addFilterArgs(sql, "oe.license_assigned", filter.getLicenceAssigned());
        sql = addFilterArgs(sql, "od.department_name", filter.getDepartment());
        Query query = entityManager.createNativeQuery(sql)
                .setParameter("searchKey", setSearchKey(filter.getSearchKey()))
                .setParameter("organizationId", admin.getOrganization().getOrganizationId());
        Object object = query.getSingleResult();
        return convertObjToInteger(object);
    }

}
