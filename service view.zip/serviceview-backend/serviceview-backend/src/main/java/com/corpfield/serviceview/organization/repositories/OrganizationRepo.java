package com.corpfield.serviceview.organization.repositories;

import com.corpfield.serviceview.organization.enities.Organization;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface OrganizationRepo  extends JpaRepository<Organization, Long> {

    Organization findByOrganizationDomainName(String domainName);

    Optional<Organization> findByOrganizationUuid(String organizationUuid);
}
