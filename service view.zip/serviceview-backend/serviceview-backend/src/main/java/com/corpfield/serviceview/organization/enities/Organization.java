package com.corpfield.serviceview.organization.enities;

import com.corpfield.serviceview.common.enities.AuditEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;

@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@Table(name = "organizations")
public class Organization extends AuditEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "organization_id")
    private long organizationId;

    @Column(name = "organization_uuid", unique = true, nullable = false)
    private String organizationUuid;

    @Column(name = "organization_domain_name", unique = true, nullable = false)
    private String organizationDomainName;

    @Column(name = "organization_name")
    private String organizationName;

    @Column(name = "organization_image_url")
    private String organizationImageUrl;

}
