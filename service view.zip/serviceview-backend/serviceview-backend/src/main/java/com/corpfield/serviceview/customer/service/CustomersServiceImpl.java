package com.corpfield.serviceview.customer.service;

import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.common.exception.ServiceViewException;
import com.corpfield.serviceview.customer.dto.reqDto.CreateCustomerReqDto;
import com.corpfield.serviceview.customer.dto.reqDto.CustomerFilterReqDto;
import com.corpfield.serviceview.customer.dto.reqDto.EditCustomerReqDto;
import com.corpfield.serviceview.customer.dto.resDto.CustomerDetailResDto;
import com.corpfield.serviceview.customer.dto.resDto.CustomerListResDto;
import com.corpfield.serviceview.customer.dto.resDto.CustomerResDto;
import com.corpfield.serviceview.customer.entities.Customer;
import com.corpfield.serviceview.customer.entities.OrganizationCustomer;
import com.corpfield.serviceview.customer.facade.CustomerServiceFacade;
import com.corpfield.serviceview.customer.repositories.CustomerRepo;
import com.corpfield.serviceview.customer.repositories.OrganizationCustomerRepo;
import com.corpfield.serviceview.organization.enities.OrganizationAdmin;
import com.corpfield.serviceview.utils.AuthUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;

@Service
public class CustomersServiceImpl implements CustomerService{

    @Autowired
    CustomerRepo customerRepo;

    @Autowired
    CustomerServiceFacade customerServiceFacade;

    @Autowired
    OrganizationCustomerRepo organizationCustomerRepo;

    @Override
    public ResponseDto createCustomer(CreateCustomerReqDto reqDto) {
        try {
            if (reqDto.getCustomerPhoneNumber() == null)
                throw new ServiceViewException("Phone Number should not be null");
            this.customerServiceFacade.checkIfCustomerAlreadyPresentInOrganization(reqDto);
            customerServiceFacade.addCustomer(reqDto);
            return new ResponseDto(HttpStatus.OK, "Customer Created Successfully");
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto findCustomerByNumber(String customerPhoneNumber) {
        try {
            Optional<Customer> optionalCustomer = customerRepo.findByCustomerPhoneNumber(customerPhoneNumber);
            Customer customer = optionalCustomer.orElseThrow(() -> new ServiceViewException("Customer cannot Found"));
            CustomerDetailResDto dto = CustomerDetailResDto.convertObjToDto(customer);
            return new ResponseDto(HttpStatus.OK, "OK", dto);
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto customerList(CustomerFilterReqDto filter, Pageable pageable) {
        try {
            String organizationAdminUuid = AuthUtil.currentUserId();
            OrganizationAdmin admin = customerServiceFacade.findAuthOrganization(organizationAdminUuid);
            Page<CustomerListResDto> customerListResDto = customerServiceFacade.customerList(filter, pageable,admin);
            return new ResponseDto(HttpStatus.OK, "Success", customerListResDto);
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto getCustomerById(long customerId) {
        try {
            Optional<Customer> customerOptional = this.customerRepo.findById(customerId);
            Customer customer = customerOptional.orElseThrow(() -> new ServiceViewException("cannot find customer"));
            CustomerResDto dto = new CustomerResDto(customer);
            return new ResponseDto(HttpStatus.OK, "Success", dto);
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto editCustomer(EditCustomerReqDto reqDto) {
        try {
            Customer customer = customerServiceFacade.findCustomerByCustomerId(reqDto.getCustomerId());
            OrganizationCustomer organizationCustomer = customerServiceFacade.findCustomerInOrganizationCustomer(customer.getCustomerId());
            reqDto.updateCustomer(customer);
            customerRepo.save(customer);
            organizationCustomer.setActive(customer.isActive());
            organizationCustomerRepo.save(organizationCustomer);
            return new ResponseDto(HttpStatus.OK, "Customer updated successfully");
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }
}


