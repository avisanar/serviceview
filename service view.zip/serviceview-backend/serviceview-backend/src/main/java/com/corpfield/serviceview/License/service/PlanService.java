package com.corpfield.serviceview.License.service;

import com.corpfield.serviceview.License.dto.requestDto.CreatePlanReqDto;
import com.corpfield.serviceview.common.dto.ResponseDto;

public interface PlanService {
    ResponseDto createPlan(CreatePlanReqDto dto);

    ResponseDto listAllPlans();
}
