package com.corpfield.serviceview.admin.entities;

import com.corpfield.serviceview.common.enities.AuditEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;

@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@Table(name = "internal_users")
public class InternalUser extends AuditEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "internal_user_id")
    private long internalUserId;

    @Column(name = "internal_user_uuid", unique = true)
    private String internalUserUuid;

    @Column(name = "email", unique = true)
    private String email;

    @Column(name = "password")
    private String password;

    @Column(name = "is_active")
    private boolean isActive;

    @Column(name = "role")
    private String role;

}
