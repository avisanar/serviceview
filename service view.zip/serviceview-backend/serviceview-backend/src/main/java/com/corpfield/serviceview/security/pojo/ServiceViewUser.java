package com.corpfield.serviceview.security.pojo;

import com.corpfield.serviceview.organization.enities.OrganizationAdmin;
import com.corpfield.serviceview.security.config.UserDetail;
import io.jsonwebtoken.Claims;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.HashMap;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
public class ServiceViewUser extends UserDetail {
    private String role;
    private String uuid;

    private boolean isActive;
    private boolean isSubscriptionActive;

    public static UserDetail createUserFromClaims(Claims tokenClaims) {
        ServiceViewUser user = ServiceViewUser
                .builder()
                .uuid(tokenClaims.get("uuid").toString())
                .role(tokenClaims.get("role").toString())
                .build();
        UserDetail userDetail = new UserDetail();
        userDetail.setUser(user);
        return userDetail;
    }

    public static ServiceViewUser generateUser(OrganizationAdmin admin) {
        return ServiceViewUser.builder()
                .role(admin.getRole())
                .uuid(admin.getOrganizationAdminUuid())
                .build();
    }

    public HashMap<String, Object> generateClaims() {
        HashMap<String, Object> claims = new HashMap<>();
        claims.put("role", this.getRole());
        claims.put("uuid", this.getUuid());
        return claims;
    }

}
