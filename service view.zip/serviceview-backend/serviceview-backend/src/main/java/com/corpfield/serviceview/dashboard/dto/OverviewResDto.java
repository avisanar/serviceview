package com.corpfield.serviceview.dashboard.dto;

import lombok.Data;

import static com.corpfield.serviceview.utils.QueryUtils.convertObjToDouble;
import static com.corpfield.serviceview.utils.QueryUtils.convertObjToLong;

@Data
public class OverviewResDto {
    private long holdingLicenses;
    private long dueDays;
    private double dueAmount;
    private long ticketsResolved;
    private long openTickets;
    private long ordersToday;
    private long ordersCompleted;

    public static OverviewResDto convertObjToDto(Object[] objects) {
        OverviewResDto dto=new OverviewResDto();
        dto.setHoldingLicenses(convertObjToLong(objects[0]));
//        dto.setDueDays(convertObjToLong(objects[2]));
        dto.setDueAmount(convertObjToDouble(objects[2]));
        /*dto.setTicketsResolved(convertObjToLong(objects[4]));
        dto.setOpenTickets(convertObjToLong(objects[5]));*/
        dto.setOrdersToday(convertObjToLong(objects[3]));
        dto.setOrdersCompleted(convertObjToLong(objects[4]));
        return dto;
    }
}
