package com.corpfield.serviceview.settings.facade;

import com.corpfield.serviceview.common.exception.ServiceViewException;
import com.corpfield.serviceview.organization.enities.OrganizationAdmin;
import com.corpfield.serviceview.organization.repositories.OrganizationAdminsRepo;
import com.corpfield.serviceview.settings.dto.requestDto.EditOrganizationUnitReqDto;
import com.corpfield.serviceview.settings.entities.OrganizationUnit;
import com.corpfield.serviceview.settings.repositories.OrganizationUnitRepo;
import com.corpfield.serviceview.utils.AuthUtil;
import org.hibernate.service.spi.ServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class OrganizationUnitFacade {

    @Autowired
    OrganizationAdminsRepo organizationAdminsRepo;

    @Autowired
    OrganizationUnitRepo organizationUnitRepo;

    public void setOrganization(OrganizationUnit organizationUnit) {
        String organizationAdminUuid = AuthUtil.currentUserId();
        Optional<OrganizationAdmin> organizationAdminOptional = this.organizationAdminsRepo.findByOrganizationAdminUuid(organizationAdminUuid);
        organizationAdminOptional.orElseThrow(() -> new ServiceException("Organization not found"));
        if (organizationAdminOptional.isPresent()) {
            organizationUnit.setOrganization(organizationAdminOptional.get().getOrganization());
        }
    }

    public OrganizationUnit findOrganizationUnitById(long organizationUnitId) throws Exception {
        Optional<OrganizationUnit> optionalOrganizationUnit = organizationUnitRepo.findById(organizationUnitId);
        return optionalOrganizationUnit.orElseThrow(() -> new ServiceViewException("Unit not found"));
    }

    public void checkUnitAlreadyExist(String unitName) throws ServiceViewException {
        Optional<OrganizationUnit> optionalOrganizationUnit = organizationUnitRepo.findByUnitName(unitName);
        if (optionalOrganizationUnit.isPresent()) {
            throw new ServiceViewException("Unit already exist");
        }
    }

    public void checkUnitAlreadyExistForEdit(EditOrganizationUnitReqDto dto) throws ServiceViewException {
        Optional<OrganizationUnit> optionalOrganizationUnit = organizationUnitRepo.findByUnitName(dto.getOrganizationUnitName());
        if (optionalOrganizationUnit.isPresent()) {
            if (dto.getOrganizationUnitId() != optionalOrganizationUnit.get().getOrganizationUnitId()) {
                throw new ServiceViewException("Unit already exist");
            }
        }
    }
}
