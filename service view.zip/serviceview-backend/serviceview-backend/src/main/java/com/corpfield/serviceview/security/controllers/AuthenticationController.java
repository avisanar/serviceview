package com.corpfield.serviceview.security.controllers;

import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.common.utils.ResponseUtil;
import com.corpfield.serviceview.security.dto.OrganizationAdminLoginDto;
import com.corpfield.serviceview.security.service.AuthenticationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AuthenticationController {

    @Autowired
    private AuthenticationService authenticationService;

    @PostMapping("/login/organization-admin")
    public ResponseEntity<ResponseDto> organizationLogin(@RequestBody OrganizationAdminLoginDto dto) {
        ResponseDto response = authenticationService.organizationalAdminLogin(dto);
        return ResponseUtil.generateResponse(response);
    }

}
