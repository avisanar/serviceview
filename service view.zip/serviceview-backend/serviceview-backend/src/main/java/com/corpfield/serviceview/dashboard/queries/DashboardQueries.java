package com.corpfield.serviceview.dashboard.queries;

public class DashboardQueries {
    public static final String GET_OVERVIEW_DETAILS ="SELECT l.total_license, " +
            "l.expiry_date, " +
            "l.total_cost, " +
            "(select count(*) from orders o where o.organization_id=1 and o.created_at like :todayDate) as ordersToday, " +
            "(select count(*) from orders o where o.organization_id=1 and o.delivery_status='Delivered') as ordersCompleted " +
            "from organizations oz " +
            "inner join license l on oz.organization_id=l.organization_id " +
            "where oz.organization_id=:organizationId " ;
}
