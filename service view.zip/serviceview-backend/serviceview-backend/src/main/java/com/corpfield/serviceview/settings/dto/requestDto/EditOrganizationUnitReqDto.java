package com.corpfield.serviceview.settings.dto.requestDto;

import com.corpfield.serviceview.settings.entities.OrganizationUnit;
import lombok.Data;

@Data
public class EditOrganizationUnitReqDto {
    private long organizationUnitId;
    private String organizationUnitName;
    private Boolean active;

    public void editUnit(OrganizationUnit organizationUnit) {
        if(organizationUnitName!=null){
            organizationUnit.setUnitName(organizationUnitName);
        }
        if(active!=null){
            organizationUnit.setActive(active);
        }
    }
}
