package com.corpfield.serviceview.settings.dto.responseDto;

import com.corpfield.serviceview.common.department.entities.OrganizationDepartment;
import lombok.Data;

import static com.corpfield.serviceview.utils.QueryUtils.*;

@Data
public class OrganizationDepartmentListResDto {
    private long departmentId;
    private String departmentName;
    private Boolean status;


    public static OrganizationDepartmentListResDto convertObjToDto(Object[] objects) {
        OrganizationDepartmentListResDto dto = new OrganizationDepartmentListResDto();
        dto.setDepartmentId(convertObjToLong(objects[0]));
        dto.setDepartmentName(convertObjToString(objects[1]));
        dto.setStatus(getActiveStatus(objects[2]));
        return dto;
    }
}
