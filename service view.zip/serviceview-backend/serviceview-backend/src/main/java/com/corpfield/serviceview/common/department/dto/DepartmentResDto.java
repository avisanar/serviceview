package com.corpfield.serviceview.common.department.dto;

import com.corpfield.serviceview.common.department.entities.OrganizationDepartment;
import lombok.Data;

@Data
public class DepartmentResDto {
    private long organizationDepartmentId;
    private String departmentName;
    private boolean status;
    private long organizationId;

    public static DepartmentResDto convertEntityToDto(OrganizationDepartment department) {
        DepartmentResDto dto = new DepartmentResDto();
        dto.setOrganizationDepartmentId(department.getOrganizationDepartmentId());
        dto.setDepartmentName(department.getDepartmentName());
        dto.setStatus(department.isActive());
        dto.setOrganizationId(department.getOrganization().getOrganizationId());
        return dto;
    }

}

