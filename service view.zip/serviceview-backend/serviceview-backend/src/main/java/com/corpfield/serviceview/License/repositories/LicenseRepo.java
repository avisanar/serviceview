package com.corpfield.serviceview.License.repositories;

import com.corpfield.serviceview.License.entities.License;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface LicenseRepo extends JpaRepository<License, Long> {

    Optional <License> findByOrganizationOrganizationUuid(String adminUuid);

  Optional<License> findByLicenseUuid(String licenseUUid);
}
