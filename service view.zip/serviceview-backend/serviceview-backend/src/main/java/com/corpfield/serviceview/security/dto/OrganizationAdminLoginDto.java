package com.corpfield.serviceview.security.dto;

import lombok.Data;

@Data
public class OrganizationAdminLoginDto {
    private String email;
    private String password;
}
