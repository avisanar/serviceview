package com.corpfield.serviceview.settings.service;

import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.settings.dto.pojo.SettingFilterReqDto;
import com.corpfield.serviceview.settings.dto.requestDto.UpdateReferenceIdReqDto;

public interface OrganizationSettingService {

    ResponseDto createSetting();

    ResponseDto updateTermsAndConditions(long organizationSettingsId, String termsAndConditions);

    ResponseDto updateReferenceNumber(UpdateReferenceIdReqDto reqDto);

    ResponseDto findOrganizationSettingsById(long organizationSettingsId);

    ResponseDto getAllSettingsList(SettingFilterReqDto filter);
}
