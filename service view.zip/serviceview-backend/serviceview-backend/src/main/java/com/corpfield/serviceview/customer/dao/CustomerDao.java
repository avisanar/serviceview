package com.corpfield.serviceview.customer.dao;

import com.corpfield.serviceview.customer.dto.reqDto.CustomerFilterReqDto;
import com.corpfield.serviceview.customer.query.CustomerQueries;
import com.corpfield.serviceview.organization.enities.OrganizationAdmin;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.corpfield.serviceview.utils.QueryUtils.*;

@Component
public class CustomerDao {

    @PersistenceContext
    EntityManager em;

    public List<Object[]> listOfCustomer(CustomerFilterReqDto filter, Pageable pageable, OrganizationAdmin admin) {
        String sql = CustomerQueries.GET_ALL_CUSTOMER;
        sql = addStatusArgs(sql, "oc", "active", filter.getStatus());
        sql = addSortArgs(sql, filter.getSortField(), filter.getSortMethod());
        Query query = em.createNativeQuery(sql)
                .setParameter("searchKey", setSearchKey(filter.getSearchKey()))
                .setParameter("organizationId", admin.getOrganization().getOrganizationId())
                .setFirstResult(pageable.getPageSize() * pageable.getPageNumber())
                .setMaxResults(pageable.getPageSize());
        return query.getResultList();
    }

    public int totalCustomer(CustomerFilterReqDto filter,OrganizationAdmin admin) {
        String sql = CustomerQueries.GET_ALL_CUSTOMER_COUNT;
        sql = addStatusArgs(sql, "oc", "active", filter.getStatus());
        Query query = em.createNativeQuery(sql)
                .setParameter("searchKey", setSearchKey(filter.getSearchKey()))
                .setParameter("organizationId", admin.getOrganization().getOrganizationId());
        int totalCustomer = convertObjToInteger(query.getSingleResult());
        return totalCustomer;
    }
}
