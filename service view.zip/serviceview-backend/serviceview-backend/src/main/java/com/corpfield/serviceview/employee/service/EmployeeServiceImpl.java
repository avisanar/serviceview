package com.corpfield.serviceview.employee.service;

import com.corpfield.serviceview.common.department.entities.OrganizationDepartment;
import com.corpfield.serviceview.common.department.facade.DepartmentFacade;
import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.common.exception.ServiceViewException;
import com.corpfield.serviceview.employee.dao.EmployeeDao;
import com.corpfield.serviceview.employee.dto.pojo.AdminEmployeeFilterDto;
import com.corpfield.serviceview.employee.dto.requestDto.CreateEmployeeReqDto;
import com.corpfield.serviceview.employee.dto.requestDto.UpdateEmployeeStatusReqDto;
import com.corpfield.serviceview.employee.dto.responseDto.EmployeeExistResDto;
import com.corpfield.serviceview.employee.dto.responseDto.EmployeeListResDto;
import com.corpfield.serviceview.employee.dto.responseDto.EmployeeResDto;
import com.corpfield.serviceview.employee.entities.Employee;
import com.corpfield.serviceview.employee.entities.OrganizationEmployee;
import com.corpfield.serviceview.employee.facade.EmployeeFacade;
import com.corpfield.serviceview.organization.enities.OrganizationAdmin;
import com.corpfield.serviceview.utils.AuthUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeServiceImpl implements EmployeeService{

    @Autowired
    EmployeeFacade employeeFacade;

    @Autowired
    EmployeeDao employeeDao;

    @Autowired
    DepartmentFacade departmentFacade;

    @Override
    public ResponseDto createNewEmployee(CreateEmployeeReqDto reqDto) {
        try {
            if (reqDto.getPhoneNumber() == null)
                throw new ServiceViewException("Employee Phone Number should not be Null");
            this.employeeFacade.checkIfEmployeeIsAlreadyPresentInOrganization(reqDto);
            OrganizationDepartment department = departmentFacade.findOrganizationDepartmentById(reqDto.getDepartmentId());
            employeeFacade.addEmployee(reqDto,department);
            return new ResponseDto(HttpStatus.OK, "Employee Added Successfully");
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto checkIfEmployeeExistByPhoneNumber(String phoneNumber) {
        try {
            Employee employee = employeeFacade.findEmployeeByPhoneNumber(phoneNumber);
            OrganizationEmployee organizationEmployee = employeeFacade.findEmployeeInOrganizationEmployee(employee.getEmployeeId());
            EmployeeExistResDto existResDto = EmployeeExistResDto.convertEntityToDto(employee, organizationEmployee);
            return new ResponseDto(HttpStatus.OK, "OK", existResDto);
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto findEmployeeByEmployeeId(long employeeId) {
        try {
            Employee employee = employeeFacade.findEmployeeById(employeeId);
            OrganizationEmployee organizationEmployee = employeeFacade.findEmployeeInOrganizationEmployee(employee.getEmployeeId());
            EmployeeResDto resDto = EmployeeResDto.convertEntityToDto(employee, organizationEmployee);
            return new ResponseDto(HttpStatus.OK, "OK", resDto);
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto findAllEmployeesList(AdminEmployeeFilterDto filter) {
        try {
            String organizationAdminUuid = AuthUtil.currentUserId();
            OrganizationAdmin admin = employeeFacade.findAuthOrganization(organizationAdminUuid);
            List<EmployeeListResDto> resDto = employeeFacade.findEmployeeListSorted(filter,admin);
            int totalCount = employeeDao.getEmployeeListCount(filter,admin);
            Page<EmployeeListResDto> pagedEmployee = new PageImpl<>(resDto, filter.getPageable(), totalCount);
            return new ResponseDto(HttpStatus.OK, "OK", pagedEmployee);
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto editEmployeeStatus(UpdateEmployeeStatusReqDto reqDto) {
        try {
            Employee employee = employeeFacade.findEmployeeById(reqDto.getEmployeeId());
            OrganizationEmployee organizationEmployee = employeeFacade.findEmployeeInOrganizationEmployee(employee.getEmployeeId());
            reqDto.updateOrganizationEmployeeEntity(organizationEmployee);
            employeeFacade.persistOrganizationEmployee(organizationEmployee);
            return new ResponseDto(HttpStatus.OK, "OK", "Employee status Updated");
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

}
