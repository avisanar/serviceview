package com.corpfield.serviceview.organization.facade;

import com.corpfield.serviceview.common.exception.ServiceViewException;
import com.corpfield.serviceview.organization.enities.Organization;
import com.corpfield.serviceview.organization.enities.OrganizationAdmin;
import com.corpfield.serviceview.organization.repositories.OrganizationAdminsRepo;
import com.corpfield.serviceview.organization.repositories.OrganizationRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.io.SerialException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;
import java.util.UUID;

@Component
public class OrganizationFacade {
    @Autowired
    private OrganizationRepo organizationRepo;

    @Autowired
    OrganizationAdminsRepo organizationAdminsRepo;

    public Organization findOrganizationByName(String domainName) {
        Organization organization = organizationRepo.findByOrganizationDomainName(domainName);
        return organization;
    }
    public String checkAlreadyExistOrganizationUuid(String organizationUuid) {
        Optional<Organization> organizationOptional = organizationRepo.findByOrganizationUuid(organizationUuid);
        while(organizationOptional.isPresent()){
            organizationUuid = UUID.randomUUID().toString().replace("-","");
            checkAlreadyExistOrganizationUuid(organizationUuid);
        }
        return organizationUuid;
    }

    public void persistOrganization(Organization organization) {
        organizationRepo.save(organization);
    }

    public OrganizationAdmin findAdminProfileByAdminUuid(String organizationAdminUuid) throws ServiceViewException {
        Optional<OrganizationAdmin> organizationAdminOptional = organizationAdminsRepo.findByOrganizationAdminUuid(organizationAdminUuid);
        organizationAdminOptional.orElseThrow(() -> new ServiceViewException("Organization not found"));
        return organizationAdminOptional.get();
    }


}
