package com.corpfield.serviceview.License.pojo;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class LicensePlanFilter {
    private String licenseUuid;
    private long planId;
    private long numberOfLicense;
}

