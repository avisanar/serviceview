package com.corpfield.serviceview.settings.dto.requestDto;

import com.corpfield.serviceview.settings.entities.OrganizationDeliveryMode;
import lombok.Data;

@Data
public class DeliveryModeCreateReqDto {

    private String deliveryType;

    public OrganizationDeliveryMode convertDtoToEntity() {
        OrganizationDeliveryMode deliveryMode = new OrganizationDeliveryMode();
        deliveryMode.setDeliveryType(deliveryType);
        deliveryMode.setActive(true);
        return deliveryMode;
    }

}
