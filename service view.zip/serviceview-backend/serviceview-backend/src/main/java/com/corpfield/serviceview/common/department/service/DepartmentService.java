package com.corpfield.serviceview.common.department.service;

import com.corpfield.serviceview.common.department.dto.CreateDepartmentReqDto;
import com.corpfield.serviceview.common.department.dto.EditDepartmentReqDto;
import com.corpfield.serviceview.common.dto.ResponseDto;

public interface DepartmentService {

    ResponseDto createDepartment(CreateDepartmentReqDto reqDto);

    ResponseDto findOrganizationDepartmentById(long organizationDepartmentId);

    ResponseDto UpdateDepartmentDetails(EditDepartmentReqDto reqDto);

}
