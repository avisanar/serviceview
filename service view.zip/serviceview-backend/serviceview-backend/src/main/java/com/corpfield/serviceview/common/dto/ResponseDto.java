package com.corpfield.serviceview.common.dto;

import lombok.Data;
import org.springframework.http.HttpStatus;

import java.util.Date;

@Data
public class ResponseDto {
    private int statusCode;
    private String message;
    private Object data;
    private Date time;

    public ResponseDto(HttpStatus status, String message, Object data) {
        this.setMessage(message);
        this.setData(data);
        this.setStatusCode(status.value());
        this.setTime(new Date());
    }

    public ResponseDto(HttpStatus status, String message) {
        this.setMessage(message);
        this.setStatusCode(status.value());
        this.setTime(new Date());
    }

    public ResponseDto(HttpStatus status, Object data) {
        this.setMessage(message);
        this.setStatusCode(status.value());
        this.setData(data);
        this.setTime(new Date());
    }
}
