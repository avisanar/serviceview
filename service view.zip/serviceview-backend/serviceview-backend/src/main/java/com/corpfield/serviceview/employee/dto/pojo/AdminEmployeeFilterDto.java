package com.corpfield.serviceview.employee.dto.pojo;

import lombok.Builder;
import lombok.Data;
import org.springframework.data.domain.Pageable;

@Data
@Builder
public class AdminEmployeeFilterDto {
    private String searchKey;
    private Pageable pageable;
    private String sortField;
    private String sortMethod;
    private String status;
    private String licenceAssigned;
    private String department;

}
