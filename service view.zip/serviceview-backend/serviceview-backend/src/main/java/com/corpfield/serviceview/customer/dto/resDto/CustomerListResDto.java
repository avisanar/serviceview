package com.corpfield.serviceview.customer.dto.resDto;

import com.corpfield.serviceview.customer.entities.Customer;
import lombok.Data;

import static com.corpfield.serviceview.utils.QueryUtils.*;

@Data
public class CustomerListResDto {
    private String customerUuid;
    private String customerName;
    private String customerPhoneNumber;
    private String customerEmail;
    private String customerLocation;
  //  private String status;

    public static CustomerListResDto mapListToDto(Object[] objects) {
        CustomerListResDto dto = new CustomerListResDto();
        dto.setCustomerUuid(convertObjToString(objects[0]));
        dto.setCustomerName(convertObjToString(objects[1]));
        dto.setCustomerPhoneNumber(convertObjToString(objects[2]));
        dto.setCustomerEmail(convertObjToString(objects[3]));
        dto.setCustomerLocation(convertObjToString(objects[4]));
     //   dto.setStatus(getActiveOrInactive(getActiveStatus(objects[5])));
        return dto;
    }
}
