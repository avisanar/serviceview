package com.corpfield.serviceview.order.facade;

import com.corpfield.serviceview.common.exception.ServiceViewException;
import com.corpfield.serviceview.customer.entities.Customer;
import com.corpfield.serviceview.customer.repositories.CustomerRepo;
import com.corpfield.serviceview.order.dao.OrderDao;
import com.corpfield.serviceview.order.dto.pojo.OrderFilterDto;
import com.corpfield.serviceview.order.dto.responseDto.OrderListResDto;
import com.corpfield.serviceview.order.entities.Order;
import com.corpfield.serviceview.order.repositories.OrdersRepo;
import com.corpfield.serviceview.organization.enities.OrganizationAdmin;
import com.corpfield.serviceview.organization.repositories.OrganizationAdminsRepo;
import com.corpfield.serviceview.settings.entities.OrganizationDeliveryMode;
import com.corpfield.serviceview.settings.repositories.OrganizationDeliveryModesRepo;
import com.corpfield.serviceview.utils.AuthUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
public class OrderFacade {

    @Autowired
    CustomerRepo customerRepo;

    @Autowired
    OrganizationAdminsRepo organizationAdminsRepo;

    @Autowired
    OrdersRepo ordersRepo;

    @Autowired
    OrganizationDeliveryModesRepo deliveryModesRepo;

    @Autowired
    OrderDao orderDao;


    public void setCustomer(Order order, long customerId) throws Exception {
        Optional<Customer> optionalCustomer = customerRepo.findById(customerId);
        optionalCustomer.orElseThrow(() -> new ServiceViewException("Cannot Find Customer"));
        optionalCustomer.ifPresent(order::setCustomer);
    }

    public void setOrganization(Order order) throws Exception {
        String organizationAdminUuid = AuthUtil.currentUserId();
        Optional<OrganizationAdmin> optOrganizationAdmin = this.organizationAdminsRepo.findByOrganizationAdminUuid(organizationAdminUuid);
        optOrganizationAdmin.orElseThrow(() -> new ServiceViewException("Organization Admin not found"));
        if (optOrganizationAdmin.isPresent()) {
            order.setOrganization(optOrganizationAdmin.get().getOrganization());
        }
    }


    public void persistOrder(Order order) {
        ordersRepo.save(order);
    }


    public void setDeliveryMode(Order order, long deliveryModeId) throws Exception{
        Optional<OrganizationDeliveryMode> optDeliveryMode = deliveryModesRepo.findById(deliveryModeId);
        optDeliveryMode.orElseThrow(() -> new ServiceViewException("DeliveryMode not found"));
        optDeliveryMode.ifPresent(order::setOrganizationDeliveryMode);
    }

    public List<OrderListResDto> getOrderListSorted(OrderFilterDto filter, OrganizationAdmin admin) {
        List<Object[]> orderObject = orderDao.findOrderListSorted(filter, admin);
        List<OrderListResDto> orderList = orderObject.stream()
                .map(OrderListResDto::convertEntityToDto)
                .collect(Collectors.toList());
        return orderList;
    }

    public Order findOrderByOrderId(long orderId) throws Exception {
        Optional<Order> optionalOrder = ordersRepo.findById(orderId);
        return optionalOrder.orElseThrow(()-> new ServiceViewException("Order not found"));
    }

}
