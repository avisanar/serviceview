package com.corpfield.serviceview.organization.dto.responseDto;

import com.corpfield.serviceview.organization.enities.Organization;
import com.corpfield.serviceview.organization.enities.OrganizationAdmin;
import lombok.Data;

@Data
public class OrganizationAdminResDto {
    private String organizationDomainName;
    private String organizationUuid;
    private String organizationAdminUuid;

    public OrganizationAdminResDto covertEntityToDto(Organization organization, OrganizationAdmin organizationAdmin) {
        OrganizationAdminResDto dto = new OrganizationAdminResDto();
        dto.setOrganizationDomainName(organization.getOrganizationDomainName());
        dto.setOrganizationUuid(organization.getOrganizationUuid());
        dto.setOrganizationAdminUuid(organizationAdmin.getOrganizationAdminUuid());
        return dto;
    }
}
