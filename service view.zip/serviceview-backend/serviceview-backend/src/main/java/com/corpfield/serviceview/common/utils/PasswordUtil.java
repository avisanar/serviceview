package com.corpfield.serviceview.common.utils;


import org.springframework.security.crypto.bcrypt.BCrypt;

public class PasswordUtil {

    public static boolean verifyPassword(String password, String hashedPassword) {
        return BCrypt.checkpw(password, hashedPassword);
    }

    public static String hashPassword(String rawPassword) {
        return BCrypt.hashpw(rawPassword, BCrypt.gensalt());
    }

}
