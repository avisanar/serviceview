package com.corpfield.serviceview.settings.entities;

import com.corpfield.serviceview.common.enities.AuditEntity;
import com.corpfield.serviceview.organization.enities.Organization;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@EqualsAndHashCode(callSuper = true)
@Data
@Entity
@Table(name = "organization_settings")
public class OrganizationSetting extends AuditEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "organization_settings_id")
    private long organizationSettingsId;

    @Column(name = "gst")
    private String gst;

    @Column(name = "reference_prefix")
    private String referencePrefix;

    @Column(name = "reference_number")
    private String referenceNumber;

    @Column(name = "terms_and_conditions")
    private String termsAndConditions;

    @ManyToOne
    @JoinColumn(name = "organization_id")
    @NotNull
    private Organization organization;

}
