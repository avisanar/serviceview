package com.corpfield.serviceview.common.department.facade;

import com.corpfield.serviceview.common.department.entities.OrganizationDepartment;
import com.corpfield.serviceview.common.department.repositories.OrganizationDepartmentsRepo;
import com.corpfield.serviceview.common.exception.ServiceViewException;
import com.corpfield.serviceview.organization.enities.Organization;
import com.corpfield.serviceview.organization.enities.OrganizationAdmin;
import com.corpfield.serviceview.organization.repositories.OrganizationAdminsRepo;
import com.corpfield.serviceview.organization.repositories.OrganizationRepo;
import com.corpfield.serviceview.utils.AuthUtil;
import org.hibernate.service.spi.ServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class DepartmentFacade {

    @Autowired
    OrganizationRepo organizationsRepo;

    @Autowired
    OrganizationDepartmentsRepo departmentsRepo;

    @Autowired
    OrganizationAdminsRepo organizationAdminsRepo;

    public Organization findOrganizationById(Long organizationId) throws Exception{
        Optional<Organization> optOrganization = organizationsRepo.findById(organizationId);
        return optOrganization.orElseThrow(() -> new ServiceViewException("No data found"));
    }

    public void persistDepartment(OrganizationDepartment department) {
        departmentsRepo.save(department);
    }

    public OrganizationDepartment findOrganizationDepartmentById(long organizationDepartmentId) throws Exception {
        Optional<OrganizationDepartment> departmentOptional = departmentsRepo.findById(organizationDepartmentId);
        return departmentOptional.orElseThrow(() -> new ServiceViewException("Department not found"));
    }

    public void setOrganization(OrganizationDepartment department) {
        String organizationAdminUuid = AuthUtil.currentUserId();
        Optional<OrganizationAdmin> optOrganizationAdmin = this.organizationAdminsRepo.findByOrganizationAdminUuid(organizationAdminUuid);
        optOrganizationAdmin.orElseThrow(() -> new ServiceException("Organization not found"));
        if (optOrganizationAdmin.isPresent()) {
            department.setOrganization(optOrganizationAdmin.get().getOrganization());
        }
    }

}
