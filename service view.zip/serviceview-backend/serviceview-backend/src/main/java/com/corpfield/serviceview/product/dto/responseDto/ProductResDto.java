package com.corpfield.serviceview.product.dto.responseDto;

import com.corpfield.serviceview.product.entities.Product;
import lombok.Data;

import static com.corpfield.serviceview.utils.DateUtil.getDate;
import static com.corpfield.serviceview.utils.QueryUtils.*;

@Data
public class ProductResDto {
    private long productId;
    private String productImageUrl;
    private String productName;
    private String unitName;
    private long availableStock;
    private double currentPrice;
    private double newPrice;
    private String effectiveDate;
    private boolean active;

    public static ProductResDto convertObjToDto(Object[] objects) {
        ProductResDto dto=new ProductResDto();
        dto.setProductId(convertObjToLong(objects[0]));
        dto.setProductImageUrl(convertObjToString(objects[1]));
        dto.setProductName(convertObjToString(objects[2]));
        dto.setUnitName(convertObjToString(objects[3]));
        dto.setAvailableStock(convertObjToLong(objects[4]));
        dto.setCurrentPrice(convertObjToDouble(objects[5]));
        dto.setNewPrice(convertObjToDouble(objects[6]));
        dto.setEffectiveDate(getDate(objects[7]));
        dto.setActive(getActiveStatus(objects[8]));
        return dto;
    }

    public static ProductResDto convertEntityToDto(Product product) {
        ProductResDto dto=new ProductResDto();
        dto.setProductId(product.getProductId());
        dto.setProductImageUrl(product.getProductImageUrl());
        dto.setProductName(product.getProductImageUrl());
        dto.setUnitName(product.getOrganizationUnit().getUnitName());
        dto.setAvailableStock(product.getAvailableStock());
        dto.setCurrentPrice(product.getCurrentPrice());
        dto.setNewPrice(product.getNewPrice());
        dto.setEffectiveDate(getDate(product.getPriceEffectiveDate()));
        dto.setActive(product.isActive());
        return dto;
    }
}
