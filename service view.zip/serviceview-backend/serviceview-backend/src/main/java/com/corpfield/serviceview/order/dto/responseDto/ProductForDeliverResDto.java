package com.corpfield.serviceview.order.dto.responseDto;

import com.corpfield.serviceview.order.entities.OrderProduct;
import lombok.Data;

@Data
public class ProductForDeliverResDto {
    private long productId;
    private String productName;
    private int quantity;
    private double productTotalPrice;
    private double totalPrice;

    public static ProductForDeliverResDto convertOrderProductToDto(OrderProduct product) {
        ProductForDeliverResDto dto = new ProductForDeliverResDto();
        dto.setProductId(product.getProduct().getProductId());
        dto.setProductName(product.getProduct().getProductName());
        dto.setQuantity(product.getQuantity());
        dto.setProductTotalPrice(product.getProductTotalPrice());
        dto.setTotalPrice(product.getProductTotalPrice() * product.getQuantity());
        return dto;
    }

}
