package com.corpfield.serviceview.utils;

import com.corpfield.serviceview.security.config.UserDetail;
import org.springframework.security.core.context.SecurityContextHolder;

public class AuthUtil {
    public static String currentUserId(){
        UserDetail userDetail = (UserDetail) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userDetail.getUsername();
    }
}
