package com.corpfield.serviceview.organization.repositories;

import com.corpfield.serviceview.organization.enities.OrganizationAdmin;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface OrganizationAdminsRepo extends JpaRepository<OrganizationAdmin, Long> {
    Optional<OrganizationAdmin> findByOrganizationAdminUuid(String userUuid);

    Optional<OrganizationAdmin> findByEmail(String email);

    Optional<OrganizationAdmin> findByPhone(String contactNumber);
}
