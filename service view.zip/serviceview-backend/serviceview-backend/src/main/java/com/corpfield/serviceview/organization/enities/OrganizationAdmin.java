package com.corpfield.serviceview.organization.enities;

import com.corpfield.serviceview.common.enities.AuditEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;

@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@Table(name = "organization_admins")
public class OrganizationAdmin extends AuditEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "organization_admin_id")
    private long organizationAdminId;

    @Column(name = "organization_admin_uuid", unique = true, nullable = false)
    private String organizationAdminUuid;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "organization_id")
    private Organization organization;

    @Column(name = "email", unique = true)
    private String email;

    @Column(name = "country_code", nullable = false)
    private String countryCode;

    @Column(name = "phone", nullable = false)
    private String phone;

    @Column(name = "role", nullable = false)
    private String role;

    @Column(name = "password")
    private String password;


}
