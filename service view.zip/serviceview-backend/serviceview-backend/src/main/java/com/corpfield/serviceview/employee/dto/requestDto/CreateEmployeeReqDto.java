package com.corpfield.serviceview.employee.dto.requestDto;

import com.corpfield.serviceview.employee.entities.Employee;
import lombok.Data;

import java.util.UUID;

@Data
public class CreateEmployeeReqDto {
    private String firstName;
    private String lastName;
    private String gender;
    private String phoneNumber;
    private String email;
    private long departmentId;

    public Employee convertDtoToEntity(String employeeUuid) {
        Employee employee = new Employee();
        employee.setEmployeeUuid(employeeUuid);
        employee.setFirstName(firstName);
        employee.setLastName(lastName);
        employee.setGender(gender);
        employee.setPhoneNumber(phoneNumber);
        employee.setEmail(email.toLowerCase());
        employee.setActive(true);
        return employee;
    }

}
