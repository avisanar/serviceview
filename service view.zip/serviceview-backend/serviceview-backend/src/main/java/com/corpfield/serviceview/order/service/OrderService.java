package com.corpfield.serviceview.order.service;

import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.order.dto.pojo.OrderFilterDto;
import com.corpfield.serviceview.order.dto.requestDto.CreateOrderReqDto;

public interface OrderService {

    ResponseDto createOrder(CreateOrderReqDto reqDto);

    ResponseDto findOrderList(OrderFilterDto filter);

    ResponseDto viewOrderDetailsByOrderId(long orderId);

    ResponseDto findDeliveredDetail(long orderId);

}
