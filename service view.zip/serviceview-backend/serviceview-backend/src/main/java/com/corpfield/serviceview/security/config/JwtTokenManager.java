package com.corpfield.serviceview.security.config;

import com.corpfield.serviceview.security.pojo.ServiceViewUser;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.stereotype.Component;

import javax.crypto.spec.SecretKeySpec;
import java.security.Key;
import java.util.Date;
import java.util.Map;

@Component
public class JwtTokenManager {
    public static final long JWT_TOKEN_VALIDITY = 30 * 24 * 60 * 60;

    private final String secret = System.getenv("JWT_SECRET_KEY");

    private final Key signingKey = new SecretKeySpec(secret.getBytes(), SignatureAlgorithm.HS512.getJcaName());

    public Claims getAllClaimsFromToken(String token) {
        JwtParser parser = Jwts.parserBuilder().setSigningKey(signingKey).build();
        return parser.parseClaimsJws(token).getBody();
    }

    public String generateToken(ServiceViewUser user) {
        return doGenerateToken(user.generateClaims(), user.getUuid());
    }

    private String doGenerateToken(Map<String, Object> claims, String subject) {
        return Jwts.builder().setClaims(claims).setSubject(subject).setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + JWT_TOKEN_VALIDITY * 1000))
                .signWith(signingKey).compact();
    }


}
