package com.corpfield.serviceview.settings.dto.requestDto;

import com.corpfield.serviceview.settings.entities.OrganizationSetting;
import lombok.Data;

@Data
public class UpdateReferenceIdReqDto {
    private long organizationSettingsId;
    private String referencePrefix;
    private String referenceNumber;


    public void updateReferenceNumberAndPrefix(OrganizationSetting organizationSetting) {
        organizationSetting.setReferencePrefix(referencePrefix);
        organizationSetting.setReferenceNumber(referenceNumber);
    }
}
