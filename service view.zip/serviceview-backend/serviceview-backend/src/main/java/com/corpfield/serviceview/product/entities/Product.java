package com.corpfield.serviceview.product.entities;

import com.corpfield.serviceview.common.enities.AuditEntity;
import com.corpfield.serviceview.organization.enities.Organization;
import com.corpfield.serviceview.settings.entities.OrganizationUnit;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Date;

@EqualsAndHashCode(callSuper = true)
@Data
@Entity
@Table(name = "products")
public class Product extends AuditEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "product_id")
    private long productId;

    @Column(name = "product_image_url")
    private String productImageUrl;

    @Column(name = "product_name")
    @NotNull
    private String productName;

    @Column(name = "available_stock")
    @NotNull
    private long availableStock;

    @Column(name = "current_price")
    @NotNull
    private Double currentPrice;

    @Column(name = "new_price")
    private Double newPrice;

    @Column(name = "price_effective_date")
    private Date priceEffectiveDate;

    @Column(name = "active")
    @NotNull
    private boolean active;

    @ManyToOne
    @JoinColumn(name = "organization_unit_id")
    @NotNull
    private OrganizationUnit organizationUnit;

    @Column(name = "gst", columnDefinition = "double default 0")
    private double gst;

    @ManyToOne
    @JoinColumn(name = "organization_id")
    @NotNull
    private Organization organization;

}
