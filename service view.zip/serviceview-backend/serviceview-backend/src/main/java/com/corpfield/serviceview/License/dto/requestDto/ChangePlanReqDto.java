package com.corpfield.serviceview.License.dto.requestDto;

import lombok.Data;

@Data
public class ChangePlanReqDto {
    private long planId;
    private long numberOfLicense;
}
