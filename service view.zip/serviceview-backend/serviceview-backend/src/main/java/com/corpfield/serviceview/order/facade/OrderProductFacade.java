package com.corpfield.serviceview.order.facade;

import com.corpfield.serviceview.common.constants.CommonConstants;
import com.corpfield.serviceview.common.exception.ServiceViewException;
import com.corpfield.serviceview.order.dto.requestDto.OrderProductReqDto;
import com.corpfield.serviceview.order.dto.responseDto.DeliveredOrderDetailResDto;
import com.corpfield.serviceview.order.dto.responseDto.OrderProductResDto;
import com.corpfield.serviceview.order.dto.responseDto.OrderResDto;
import com.corpfield.serviceview.order.dto.responseDto.ProductForDeliverResDto;
import com.corpfield.serviceview.order.entities.Order;
import com.corpfield.serviceview.order.entities.OrderProduct;
import com.corpfield.serviceview.order.repositories.OrderProductsRepo;
import com.corpfield.serviceview.order.repositories.OrdersRepo;
import com.corpfield.serviceview.product.entities.Product;
import com.corpfield.serviceview.product.repositories.ProductsRepo;
import org.hibernate.service.spi.ServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
public class OrderProductFacade {

    @Autowired
    OrderProductsRepo orderProductsRepo;

    @Autowired
    ProductsRepo productsRepo;

    @Autowired
    OrdersRepo ordersRepo;

    public void setProductsForOrder(Order order, List<OrderProductReqDto> productReqDtoList) {
        List<OrderProduct> orderProducts = new ArrayList<>();
        for (OrderProductReqDto reqDto : productReqDtoList) {
            OrderProduct product = new OrderProduct();
            this.setProduct(product, reqDto.getProductId());
            if (reqDto.getQuantity() < 1) {
                throw new ServiceException("Invalid Quantity");
            }
            product.setQuantity(reqDto.getQuantity());
            product.setProductTotalPrice(reqDto.getQuantity() * product.getProduct().getCurrentPrice());
            product.setOrder(order);
            orderProducts.add(product);
        }
        orderProductsRepo.saveAll(orderProducts);
    }

    private void setProduct(OrderProduct orderProduct, long productId) {
        Optional<Product> productOptional = productsRepo.findById(productId);
        productOptional.orElseThrow(() -> new ServiceException("Product Not Found"));
        orderProduct.setProduct(productOptional.get());
    }

    public void mapProductToOrder(OrderResDto orderDto) {
        List<OrderProduct> productList = orderProductsRepo.findByOrderOrderId(orderDto.getOrderId());
        List<OrderProductResDto> productDtoList = productList.stream()
                .map(OrderProductResDto::convertEntityToDto)
                .collect(Collectors.toList());
        orderDto.setOrderProductList(productDtoList);
    }

    public OrderProduct findOrderProductById(long orderProductId) throws Exception {
        Optional<OrderProduct> optionalOrderProduct = orderProductsRepo.findById(orderProductId);
        optionalOrderProduct.orElseThrow(() -> new ServiceViewException("Order Product Not found"));
        return optionalOrderProduct.get();
    }

    public void checkIfProductToBeEdited(Order order) throws Exception {
        if (order.getDeliveryStatus().equals(CommonConstants.DELIVERY)) {
            throw new ServiceViewException("Product cannot be edited");
        }
    }

    public void persistOrderProduct(OrderProduct updatedOrderProduct) {
        orderProductsRepo.save(updatedOrderProduct);
    }

    public void removeProductFromOrderProduct(long orderProductId) {
        orderProductsRepo.deleteById(orderProductId);
    }

    public void mapDeliveredProductForOrder(DeliveredOrderDetailResDto deliveredDto) {
        List<OrderProduct> productList = orderProductsRepo.findByOrderOrderId(deliveredDto.getOrderId());
        List<ProductForDeliverResDto> deliverResDto = productList.stream()
                .map(ProductForDeliverResDto::convertOrderProductToDto)
                .collect(Collectors.toList());
        deliveredDto.setOrderProductList(deliverResDto);
    }

}
