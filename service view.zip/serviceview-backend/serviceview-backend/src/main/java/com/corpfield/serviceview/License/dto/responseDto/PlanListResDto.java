package com.corpfield.serviceview.License.dto.responseDto;

import com.corpfield.serviceview.License.entities.Plan;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class PlanListResDto {
    public long planId;
    public double costPerLicense;
    private int validity;
    private String planUuid;

    public static List<PlanListResDto> convertEntityToDto(List<Plan> plans) {
        List<PlanListResDto> plansList=new ArrayList<>();
        for(Plan plan:plans){
          PlanListResDto planListResDto=new PlanListResDto();
          planListResDto.setPlanId(plan.getPlanId());
          planListResDto.setCostPerLicense(plan.getPerLicenseCost());
          planListResDto.setPlanUuid(plan.getPlanUuid());
          plansList.add(planListResDto);
        }
        return plansList;
    }
}
