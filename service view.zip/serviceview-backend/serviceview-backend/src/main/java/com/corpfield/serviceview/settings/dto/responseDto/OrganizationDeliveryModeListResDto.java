package com.corpfield.serviceview.settings.dto.responseDto;

import com.corpfield.serviceview.settings.entities.OrganizationDeliveryMode;
import lombok.Data;

import static com.corpfield.serviceview.utils.QueryUtils.*;

@Data
public class OrganizationDeliveryModeListResDto {
    private long deliveryModeId;
    private String deliveryModeType;
    private Boolean status;


    public static OrganizationDeliveryModeListResDto convertObjToDto(Object[] objects) {
        OrganizationDeliveryModeListResDto dto = new OrganizationDeliveryModeListResDto();
        dto.setDeliveryModeId(convertObjToLong(objects[0]));
        dto.setDeliveryModeType(convertObjToString(objects[1]));
        dto.setStatus(getActiveStatus(objects[2]));
        return dto;
    }
}

