package com.corpfield.serviceview.License.dto.requestDto;

import lombok.Data;

@Data
public class BuyMoreLicenseReqDto {
    private long addLicense;
}
