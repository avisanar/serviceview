package com.corpfield.serviceview.product.dto.pojo;

import lombok.Builder;
import lombok.Data;
import org.springframework.data.domain.Pageable;

@Data
@Builder
public class ProductListFilter {
    private Pageable pageable;
    private String status;
    private String searchKey;
}
