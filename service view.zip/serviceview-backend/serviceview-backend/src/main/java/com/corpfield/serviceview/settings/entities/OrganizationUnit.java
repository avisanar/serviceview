package com.corpfield.serviceview.settings.entities;

import com.corpfield.serviceview.common.enities.AuditEntity;
import com.corpfield.serviceview.organization.enities.Organization;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@EqualsAndHashCode(callSuper = true)
@Data
@Entity
@Table(name = "organization_units")
public class OrganizationUnit extends AuditEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "organization_unit_id")
    private long OrganizationUnitId;

    @Column(name = "unit_name")
    @NotNull
    private String unitName;

    @Column(name = "active")
    @NotNull
    private boolean active;

    @ManyToOne
    @JoinColumn(name = "organization_id")
    @NotNull
    private Organization organization;
}
