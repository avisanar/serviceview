package com.corpfield.serviceview.settings.dto.requestDto;

import com.corpfield.serviceview.settings.entities.OrganizationDeliveryMode;
import lombok.Data;

@Data
public class EditDeliveryModeReqDto {

    private long organizationDeliveryModeId;
    private Boolean active;

    public void updateDeliveryMode(OrganizationDeliveryMode deliveryMode) {
        if (active != null) {
            deliveryMode.setActive(active);
        }
    }

}
