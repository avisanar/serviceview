package com.corpfield.serviceview.License.dto.responseDto;

import com.corpfield.serviceview.License.entities.License;
import lombok.Data;

@Data
public class LicensePlanResDto {
    private String accountType;
    private String licensePlan;
    private long availableLicense;
    private long assignedLicense;
    private long userLicense;

    public static LicensePlanResDto convertEntityToDto(License license) {
        LicensePlanResDto licensePlanResDto=new LicensePlanResDto();
        licensePlanResDto.setLicensePlan(license.getPlan().getNumberOfDays()+"days");
        licensePlanResDto.setAssignedLicense(license.getAssignedLicense());
        licensePlanResDto.setAvailableLicense(license.getTotalLicense());
        return licensePlanResDto;
    }
}
