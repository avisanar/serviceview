package com.corpfield.serviceview.License.dto.responseDto;

import lombok.Data;

@Data
public class LicenseRenewDetailsResDto {
    private String accountType;
    private double renewalAmount;
    private long currentLicense;
    private double totalCost;
}
