package com.corpfield.serviceview.security.config;

import com.corpfield.serviceview.security.pojo.ServiceViewUser;
import io.jsonwebtoken.Claims;
import lombok.extern.log4j.Log4j2;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


@Log4j2
public class AuthRequestFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {

        String jwtTokenHeader = request.getHeader("Authorization");
        try {
            String jwtToken = jwtTokenHeader.substring(7);
            Claims tokenClaims = new JwtTokenManager().getAllClaimsFromToken(jwtToken);
            UserDetail user = ServiceViewUser.createUserFromClaims(tokenClaims);

            UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(
                    user, null, user.getAuthorities());
            usernamePasswordAuthenticationToken
                    .setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

            SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
        } catch (Exception e) {
            log.info(request.getRemoteAddr() + " tried to access " + request.getRequestURL() + " and failed due to invalid token");
            e.printStackTrace();
        }

        filterChain.doFilter(request, response);
    }


}
