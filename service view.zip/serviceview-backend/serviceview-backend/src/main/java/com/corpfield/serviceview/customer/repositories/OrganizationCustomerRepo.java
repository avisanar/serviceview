package com.corpfield.serviceview.customer.repositories;

import com.corpfield.serviceview.customer.entities.OrganizationCustomer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface OrganizationCustomerRepo extends JpaRepository<OrganizationCustomer,Long> {
    Optional<OrganizationCustomer> findByOrganizationCustomerUuid(String organizationCustomerUuid);

    Optional<OrganizationCustomer> findByCustomerCustomerId(long customerId);

    Optional<OrganizationCustomer> findByCustomerCustomerIdAndOrganizationOrganizationId(long customerId, long organizationId);
}
