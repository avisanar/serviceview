package com.corpfield.serviceview.License.facade;

import com.corpfield.serviceview.License.dto.requestDto.*;
;
import com.corpfield.serviceview.License.dto.responseDto.*;
import com.corpfield.serviceview.License.entities.License;
import com.corpfield.serviceview.License.entities.Plan;
import com.corpfield.serviceview.License.pojo.LicensePlanFilter;
import com.corpfield.serviceview.License.repositories.LicenseRepo;
import com.corpfield.serviceview.employee.entities.OrganizationEmployee;
import com.corpfield.serviceview.employee.repositories.OrganizationEmployeesRepo;
import com.corpfield.serviceview.organization.enities.Organization;
import com.corpfield.serviceview.organization.enities.OrganizationAdmin;
import com.corpfield.serviceview.organization.facade.OrganizationAdminFacade;
import com.corpfield.serviceview.organization.repositories.OrganizationRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Component
public class LicenseFacade {
    @Autowired
    LicenseRepo licenseRepo;

    @Autowired
    PlanFacade planFacade;

    @Autowired
    OrganizationAdminFacade organizationAdminFacade;

    @Autowired
    OrganizationEmployeesRepo organizationEmployeesRepo;

    @Autowired
    OrganizationRepo organizationRepo;



    public void persistLicense(License license) {
        licenseRepo.save(license);

    }


    public String checkAlreadyExistLicenseUuid(String licenseUuid) {
        Optional<License> licenseOptional = licenseRepo.findByLicenseUuid(licenseUuid);
        while (licenseOptional.isPresent()) {
            licenseUuid = UUID.randomUUID().toString().replace("-", "");
            checkAlreadyExistLicenseUuid(licenseUuid);
        }
        return licenseUuid;
    }


    public LicensePackageDetailsResDto getPlanPackageDetails(LicensePlanFilter filter) {
        LicensePackageDetailsResDto planPackageDetailsResDto = new LicensePackageDetailsResDto();
        Plan plan = planFacade.findById(filter.getPlanId());
        planPackageDetailsResDto.setCostPerLicense(plan.getPerLicenseCost());
        planPackageDetailsResDto.setPlanSelected(plan.getNumberOfDays() + "days");
        planPackageDetailsResDto.setTotalCost(planPackageDetailsResDto.getCostPerLicense() * filter.getNumberOfLicense());
        return planPackageDetailsResDto;
    }


    public LicensePackageSummaryResDto getPackageDetails(LicensePlanFilter filter) {
        LicensePackageSummaryResDto dto = new LicensePackageSummaryResDto();
        Plan plan = planFacade.findById(filter.getPlanId());
        int days=plan.getNumberOfDays();
        Calendar current = Calendar.getInstance();
        current.add(Calendar.DATE, days);
        dto.setCostPerLicense(plan.getPerLicenseCost());
        dto.setPlanSelected(plan.getNumberOfDays() + " days");
        dto.setLicenseValidity(current.getTime());
        if(filter.getLicenseUuid()!=null) {
            Optional<License> license=licenseRepo.findByLicenseUuid(filter.getLicenseUuid());
            dto.setLicenseCost(filter.getNumberOfLicense() * plan.getPerLicenseCost());
            dto.setPreviousBalance(license.get().getPreviousBalance());
            dto.setTotalCost(dto.getLicenseCost()- dto.getPreviousBalance());
        }
        else{
            dto.setLicenseCost(filter.getNumberOfLicense() * plan.getPerLicenseCost());
            dto.setPreviousBalance(0);
            dto.setTotalCost(dto.getLicenseCost());
        }
        return dto;
    }


    private int getAvailableDays(Date purchasedDate, Date expiryDate) throws ParseException {
        SimpleDateFormat obj = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
        Date date1 = obj.parse(String.valueOf(purchasedDate));
        Date date2 = obj.parse(String.valueOf(expiryDate));
        long time_difference = date2.getTime() - date1.getTime();
        int days_difference = (int) ((time_difference / (1000 * 60 * 60 * 24)) % 365);
        return days_difference;
    }



    public Organization findOrganizationByAdminUuid(String adminUuid) {
        OrganizationAdmin organizationAdmin = organizationAdminFacade.findByAdminUUid(adminUuid);
        return organizationAdmin.getOrganization();
    }

    public License findByOrganizationOrganizationUuid(Organization organization) {
        Optional<License> license = licenseRepo.findByOrganizationOrganizationUuid(organization.getOrganizationUuid());
        if (license.isPresent()) {
            return license.get();
        } else {
            return new License();
        }
    }

    public List<UserListResDto> mapObjectsToDto(List<Object[]> objList) {
        List<UserListResDto> userList = objList.stream()
                .map(UserListResDto::convertObjToDto)
                .collect(Collectors.toList());
        return userList;
    }

    public void assignLicense(List<AssignLicenseReqDto> dto, License license) {

        for (AssignLicenseReqDto reqDto : dto) {
            long userId = reqDto.getUserId();
            boolean licenseAssign = reqDto.isLicenseAssign();
            if (license.getTotalLicense() != 0) {
                Optional<OrganizationEmployee> organizationEmployee = organizationEmployeesRepo.findById(userId);
                if (organizationEmployee.isPresent()) {
                    OrganizationEmployee employee = organizationEmployee.get();
                    employee.setLicenseAssigned(licenseAssign);
                    organizationEmployeesRepo.save(employee);
                    if (licenseAssign) {
                        license.setAssignedLicense(license.getAssignedLicense() + 1);
                    } else {
                        license.setAssignedLicense(license.getAssignedLicense() - 1);
                    }
                }
            }
        }
        licenseRepo.save(license);
    }


    public LicenseRenewDetailsResDto getRenewPlanDetails(String licenseUuid) {
        Optional<License> optLicense=licenseRepo.findByLicenseUuid(licenseUuid);
        License license=optLicense.get();
        LicenseRenewDetailsResDto resDto=new LicenseRenewDetailsResDto();
        resDto.setCurrentLicense(license.getTotalLicense());
        resDto.setRenewalAmount(license.getTotalCost());
        resDto.setRenewalAmount(license.getTotalCost());
        return resDto;
    }

    public void createLicensePlan(LicensePlanReqDto reqDto, Organization organization) {
        Plan plan = planFacade.findById(reqDto.getPlanId());
        int days = plan.getNumberOfDays();
        Calendar current = Calendar.getInstance();
        String licenseUuid = this.checkAlreadyExistLicenseUuid(UUID.randomUUID().toString().replace("-", ""));
        License license=new License();
        license.setTotalLicense(reqDto.getNumberOfLicense());
        license.setPlan(plan);
        license.setPurchasedDate(current.getTime());
        license.setLicenseUuid(licenseUuid);
        current.add(Calendar.DATE, days);
        license.setExpiryDate(current.getTime());
        license.setTotalCost(reqDto.getNumberOfLicense() * plan.getPerLicenseCost() * plan.getNumberOfDays());
        license.setOrganization(organization);
        license.setIsPaid(false);
        this.persistLicense(license);
    }

    public void changeLicensePlan(License license, LicensePlanReqDto reqDto) {
        Date current = Calendar.getInstance().getTime();
        long usedTime = current.getTime() - license.getPurchasedDate().getTime();
        long usedDays = usedTime / 1000 / 60 / 60 / 24;
        System.out.println(usedDays);
        double usedCost = license.getTotalLicense() * usedDays * 10;
        System.out.println(usedCost);
        Plan plan = planFacade.findById(reqDto.getPlanId());
        int days = Math.toIntExact(license.getPlan().getNumberOfDays());
        Calendar current2 = Calendar.getInstance();
        license.setPurchasedDate(current2.getTime());
        current2.add(Calendar.DATE, days);
        license.setExpiryDate(current2.getTime());
        license.setPlan(plan);
        license.setPreviousBalance(license.getTotalCost() - usedCost);
        license.setTotalLicense(reqDto.getNumberOfLicense());
        license.setTotalCost(reqDto.getNumberOfLicense() * plan.getPerLicenseCost() * plan.getNumberOfDays());
        this.persistLicense(license);
        double paymentBalance= license.getTotalCost()-license.getPreviousBalance();
    }

    public void renewPlan(License license, LicensePlanReqDto reqDto) throws ParseException {
        Plan plan = planFacade.findById(license.getPlan().getPlanId());
        int days = Math.toIntExact(license.getPlan().getNumberOfDays());
        Calendar current = Calendar.getInstance();
        license.setPurchasedDate(current.getTime());
        current.add(Calendar.DATE, days);
        license.setExpiryDate(current.getTime());
        license.setTotalLicense(reqDto.getNumberOfLicense());
        license.setTotalCost(reqDto.getNumberOfLicense() * plan.getPerLicenseCost() * plan.getNumberOfDays());
        this.persistLicense(license);
    }


    public LicenseExistingDetailsResDto getExistingLicenseDetails(License license) {
        LicenseExistingDetailsResDto dto=new LicenseExistingDetailsResDto();
        dto.setExistingLicenses(license.getTotalLicense());
        return dto;
    }

    public void addMoreLicense(License license, BuyMoreLicenseReqDto reqDto) {
        license.setTotalLicense(license.getTotalLicense()+ reqDto.getAddLicense());
        license.setTotalCost(license.getTotalCost()+reqDto.getAddLicense()*license.getPlan().getPerLicenseCost());
        double previousBalance=reqDto.getAddLicense()*license.getPlan().getPerLicenseCost()-license.getPreviousBalance();
        if(previousBalance>0){
            license.setPreviousBalance(previousBalance);
        }
        this.persistLicense(license);
    }
}