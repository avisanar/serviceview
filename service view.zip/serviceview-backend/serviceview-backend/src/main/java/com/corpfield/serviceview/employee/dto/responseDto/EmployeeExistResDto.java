package com.corpfield.serviceview.employee.dto.responseDto;


import com.corpfield.serviceview.employee.entities.Employee;
import com.corpfield.serviceview.employee.entities.OrganizationEmployee;
import lombok.Data;

@Data
public class EmployeeExistResDto {
    private String fullName;
    private String email;
    private String gender;
    private long departmentId;
    private String departmentName;

    public static EmployeeExistResDto convertEntityToDto(Employee employee, OrganizationEmployee organizationEmployee) {
        EmployeeExistResDto dto = new EmployeeExistResDto();
        if (employee.getLastName() != null) {
            dto.setFullName(employee.getFirstName() + " " + employee.getLastName());
        }
        dto.setFullName(employee.getFirstName());
        dto.setEmail(employee.getEmail());
        dto.setGender(employee.getGender());
        dto.setDepartmentId(organizationEmployee.getOrganizationDepartment().getOrganizationDepartmentId());
        dto.setDepartmentName(organizationEmployee.getOrganizationDepartment().getDepartmentName());
        return dto;
    }

}
