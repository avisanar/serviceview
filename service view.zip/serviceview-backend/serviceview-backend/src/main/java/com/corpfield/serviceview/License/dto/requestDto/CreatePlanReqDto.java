package com.corpfield.serviceview.License.dto.requestDto;

import lombok.Data;

@Data
public class CreatePlanReqDto {
    private long planId;
    private int numberOfDays;
    private double perLicenseCost;
}
