package com.corpfield.serviceview.License.queries;

public class LicenseQueries {
    public static final String GET_USERS_LIST = "SELECT oe.organization_employees_id, " +
            "concat(e.first_name, " +
            "e.last_name) as name," +
            "e.phone_number, " +
            "od.department_name, " +
            "oe.license_assigned " +
            "from organization_employees oe " +
            "inner join employees e on oe.employee_id=e.employee_id " +
            "inner join organization_departments od on oe.organization_department_id=od.organization_department_id " +
            "where oe.organization_id = :organizationId ";

    public static final String GET_USERS_COUNT = "SELECT count(*) " +
            "from organization_employees oe " +
            "inner join employees e on oe.employee_id=e.employee_id " +
            "inner join organization_departments od on oe.organization_department_id=od.organization_department_id " +
            "where oe.organization_id=:organizationId";
}
