package com.corpfield.serviceview.settings.repositories;

import com.corpfield.serviceview.common.department.entities.OrganizationDepartment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrganizationDepartmentListRepo extends JpaRepository<OrganizationDepartment,Long> {
    List<OrganizationDepartment> findByOrganizationOrganizationId(long organizationId);
}
