package com.corpfield.serviceview.License.dto.requestDto;

import lombok.Data;

@Data
public class AssignLicenseReqDto {
    private long userId;
    private boolean licenseAssign;

}
