package com.corpfield.serviceview.settings.queries;

public class OrganizationSettingQuery {

    public static final String FIND_SETTINGS_LIST = "select " +
            "o.organization_id, " +
            "o.organization_name, " +
            "oa.phone, " +
            "oa.email, " +
            "o.organization_image_url " +
            "from organizations o " +
            "inner join organization_admins oa " +
            "on oa.organization_id  = o.organization_id " +
            "where " +
            "o.organization_id =:organizationId " ;

    public static final String FIND_DEPARTMENT_LIST = "select " +
            "od.organization_department_id, " +
            "od.department_name, " +
            "od.active " +
            "from organization_departments od " +
            "inner join organizations o on o.organization_id = od.organization_id " +
            "where " +
            "o.organization_id =:organizationId " +
            "and od.created_at between :fromDate and :toDate " ;

    public static final String FIND_DELIVERY_MODE_LIST = "select " +
            "odm.organization_delivery_mode_id, " +
            "odm.delivery_mode, " +
            "odm.active " +
            "from organization_delivery_mode odm " +
            "inner join organizations o on o.organization_id = odm.organization_id " +
            "where " +
            "o.organization_id =:organizationId " +
            "and odm.created_at between :fromDate and :toDate " ;
}
