package com.corpfield.serviceview.common.department.service;

import com.corpfield.serviceview.common.department.dto.CreateDepartmentReqDto;
import com.corpfield.serviceview.common.department.dto.DepartmentResDto;
import com.corpfield.serviceview.common.department.dto.EditDepartmentReqDto;
import com.corpfield.serviceview.common.department.entities.OrganizationDepartment;
import com.corpfield.serviceview.common.department.facade.DepartmentFacade;
import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.common.exception.ServiceViewException;
import com.corpfield.serviceview.organization.enities.Organization;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
public class DepartmentServiceImpl implements DepartmentService {

    @Autowired
    DepartmentFacade departmentFacade;

    @Override
    public ResponseDto createDepartment(CreateDepartmentReqDto reqDto) {
        try {
            OrganizationDepartment department = reqDto.convertDtoToEntity();
            departmentFacade.setOrganization(department);
            departmentFacade.persistDepartment(department);
            return new ResponseDto(HttpStatus.OK, "Department have been added");
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto findOrganizationDepartmentById(long organizationDepartmentId) {
        try {
            OrganizationDepartment organizationDepartment = departmentFacade
                    .findOrganizationDepartmentById(organizationDepartmentId);
            DepartmentResDto resDto = DepartmentResDto.convertEntityToDto(organizationDepartment);
            return new ResponseDto(HttpStatus.OK, "OK", resDto);
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto UpdateDepartmentDetails(EditDepartmentReqDto reqDto) {
        try {
            OrganizationDepartment organizationDepartment = departmentFacade
                    .findOrganizationDepartmentById(reqDto.getOrganizationDepartmentId());
            reqDto.updateDepartment(organizationDepartment);
            departmentFacade.persistDepartment(organizationDepartment);
            return new ResponseDto(HttpStatus.OK, "OK", "Department have been edited");
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

}
