package com.corpfield.serviceview.License.dto.requestDto;

import lombok.Data;

@Data
public class RenewPlanReqDto {
    private String accountType;
    private long numberOfLicense;
    private long planId;
    private double totalCost;
}
