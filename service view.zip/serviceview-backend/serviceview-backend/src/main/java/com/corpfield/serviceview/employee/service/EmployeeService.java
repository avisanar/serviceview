package com.corpfield.serviceview.employee.service;

import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.employee.dto.pojo.AdminEmployeeFilterDto;
import com.corpfield.serviceview.employee.dto.requestDto.CreateEmployeeReqDto;
import com.corpfield.serviceview.employee.dto.requestDto.UpdateEmployeeStatusReqDto;

public interface EmployeeService {

    ResponseDto createNewEmployee(CreateEmployeeReqDto reqDto);

    ResponseDto checkIfEmployeeExistByPhoneNumber(String phoneNumber);

    ResponseDto findEmployeeByEmployeeId(long employeeId);

    ResponseDto findAllEmployeesList(AdminEmployeeFilterDto filter);

    ResponseDto editEmployeeStatus(UpdateEmployeeStatusReqDto reqDto);

}
