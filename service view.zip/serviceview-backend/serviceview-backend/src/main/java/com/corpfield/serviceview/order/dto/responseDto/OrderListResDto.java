package com.corpfield.serviceview.order.dto.responseDto;

import lombok.Data;


import static com.corpfield.serviceview.utils.DateUtil.getDate;
import static com.corpfield.serviceview.utils.QueryUtils.convertObjToLong;
import static com.corpfield.serviceview.utils.QueryUtils.convertObjToString;

@Data
public class OrderListResDto {
    private long orderId;
    private String customerName;
    private String orderedOn;
    private String deliveryStatus;
    private double orderAmount;

    public static OrderListResDto convertEntityToDto(Object[] obj) {
        OrderListResDto dto = new OrderListResDto();
        dto.setOrderId(convertObjToLong(obj[0]));
        dto.setCustomerName(convertObjToString(obj[1]));
        dto.setOrderedOn(getDate(obj[2]));
        dto.setDeliveryStatus(convertObjToString(obj[3]));
        return dto;
    }

}
