package com.corpfield.serviceview.License.dto.requestDto;

import lombok.Data;

@Data
public class RenewLicensePlanReqDto {
    private long numberOfLicense;
}
