package com.corpfield.serviceview.order.dto.pojo;

import lombok.Builder;
import lombok.Data;
import org.springframework.data.domain.Pageable;

import java.util.Date;

@Data
@Builder
public class OrderFilterDto {
    private String searchKey;
    private Pageable pageable;
    private String sortField;
    private String sortMethod;
    private String status;
    private Date fromDate;
    private Date toDate;

}
