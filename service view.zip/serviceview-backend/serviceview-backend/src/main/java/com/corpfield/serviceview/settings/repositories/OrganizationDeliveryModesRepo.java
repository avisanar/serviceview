package com.corpfield.serviceview.settings.repositories;

import com.corpfield.serviceview.settings.entities.OrganizationDeliveryMode;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrganizationDeliveryModesRepo extends JpaRepository<OrganizationDeliveryMode, Long> {
    List<OrganizationDeliveryMode> findByOrganizationOrganizationId(long organizationId);
}
