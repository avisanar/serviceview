package com.corpfield.serviceview.organization.controllers;

import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.common.utils.ResponseUtil;
import com.corpfield.serviceview.organization.dto.requestDto.CheckDomainAvailableReqDto;
import com.corpfield.serviceview.organization.dto.requestDto.CreateOrganizationReqDto;
import com.corpfield.serviceview.organization.service.OrganizationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class OrganizationController {

    @Autowired
    OrganizationService organizationService;

    @PostMapping("/public/organization")
    public ResponseEntity<ResponseDto> createOrganization(@RequestBody CreateOrganizationReqDto dto) {
        ResponseDto response = organizationService.createOrganizationAdmin(dto);
        return ResponseUtil.generateResponse(response);
    }

    @PostMapping("/public/checkAvailability")
    public ResponseEntity<ResponseDto> checkDomainNameAvailability(@RequestBody CheckDomainAvailableReqDto dto){
        ResponseDto response=organizationService.checkDomainNameAvailability(dto);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatusCode()));
    }

    @GetMapping("/admin/profile")
    public ResponseEntity<ResponseDto> getAdminProfile() {
        ResponseDto response = this.organizationService.getAdminProfile();
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatusCode()));
    }
}


