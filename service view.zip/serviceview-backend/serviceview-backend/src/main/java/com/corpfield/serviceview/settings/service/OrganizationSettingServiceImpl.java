package com.corpfield.serviceview.settings.service;

import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.common.exception.ServiceViewException;
import com.corpfield.serviceview.customer.facade.CustomerServiceFacade;
import com.corpfield.serviceview.organization.enities.OrganizationAdmin;
import com.corpfield.serviceview.settings.dao.OrganizationSettingDao;
import com.corpfield.serviceview.settings.dto.pojo.SettingFilterReqDto;
import com.corpfield.serviceview.settings.dto.responseDto.OrganizationSettingListResDto;
import com.corpfield.serviceview.settings.dto.responseDto.OrganizationSettingResDto;
import com.corpfield.serviceview.settings.dto.requestDto.UpdateReferenceIdReqDto;
import com.corpfield.serviceview.settings.entities.OrganizationSetting;
import com.corpfield.serviceview.settings.facade.OrganizationSettingFacade;
import com.corpfield.serviceview.settings.repositories.OrganizationSettingRepo;
import com.corpfield.serviceview.utils.AuthUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrganizationSettingServiceImpl implements OrganizationSettingService{

    @Autowired
    OrganizationSettingFacade organizationSettingFacade;

    @Autowired
    OrganizationSettingRepo organizationSettingRepo;

    @Autowired
    OrganizationSettingDao organizationSettingDao;

    @Autowired
    CustomerServiceFacade customerServiceFacade;

    @Override
    public ResponseDto createSetting() {
        try {
            OrganizationSetting organizationSetting = new OrganizationSetting();
            organizationSettingFacade.setOrganization(organizationSetting);
            organizationSettingRepo.save(organizationSetting);
            return new ResponseDto(HttpStatus.OK, "Setting added successfully");
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto updateTermsAndConditions(long organizationSettingsId, String termsAndConditions) {
        try {
            OrganizationSetting organizationSetting = this.organizationSettingFacade.findOrganizationSettingsById(organizationSettingsId);
            organizationSetting.setTermsAndConditions(termsAndConditions);
            organizationSettingRepo.save(organizationSetting);
            return new ResponseDto(HttpStatus.OK, "Terms and Conditions updated successfully");
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public  ResponseDto updateReferenceNumber(UpdateReferenceIdReqDto reqDto) {
        try {
            OrganizationSetting organizationSetting = this.organizationSettingFacade.findOrganizationSettingsById(reqDto.getOrganizationSettingsId());
            reqDto.updateReferenceNumberAndPrefix(organizationSetting);
            organizationSettingRepo.save(organizationSetting);
            return new ResponseDto(HttpStatus.OK, "Reference Number updated successfully");
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto findOrganizationSettingsById(long organizationSettingsId){
        try{
            OrganizationSetting organizationSetting = organizationSettingFacade.findOrganizationSettingsById(organizationSettingsId);
            OrganizationSettingResDto resDto = OrganizationSettingResDto.convertObjToDto(organizationSetting);
            return new ResponseDto(HttpStatus.OK,"OK",resDto);
        }catch (Exception e){
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto getAllSettingsList(SettingFilterReqDto filter) {
        try {
            String organizationAdminUuid = AuthUtil.currentUserId();
            OrganizationAdmin organizationAdmin = customerServiceFacade.findAuthOrganization(organizationAdminUuid);
            List<Object[]> settingsObject = organizationSettingDao.findSettingList(organizationAdmin);
            List<OrganizationSettingListResDto> settingListResDto = organizationSettingFacade.findListOfSetting(settingsObject,filter);
            return new ResponseDto(HttpStatus.OK, "OK", settingListResDto);
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }
}
