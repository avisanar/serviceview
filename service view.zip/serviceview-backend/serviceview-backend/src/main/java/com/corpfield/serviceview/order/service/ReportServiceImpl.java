package com.corpfield.serviceview.order.service;

import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.common.exception.ServiceViewException;
import com.corpfield.serviceview.employee.facade.EmployeeFacade;
import com.corpfield.serviceview.order.dao.ReportDao;
import com.corpfield.serviceview.order.dto.pojo.OrderFilterDto;
import com.corpfield.serviceview.order.dto.responseDto.OrderListResDto;
import com.corpfield.serviceview.order.dto.responseDto.ReportListResDto;
import com.corpfield.serviceview.order.facade.ReportFacade;
import com.corpfield.serviceview.organization.enities.OrganizationAdmin;
import com.corpfield.serviceview.utils.AuthUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReportServiceImpl implements ReportService{

    @Autowired
    ReportFacade reportFacade;

    @Autowired
    EmployeeFacade employeeFacade;

    @Autowired
    ReportDao reportDao;

    @Override
    public ResponseDto getReportList(OrderFilterDto filter) {
        try {
            String organizationAdminUuid = AuthUtil.currentUserId();
            OrganizationAdmin admin = employeeFacade.findAuthOrganization(organizationAdminUuid);
            List<ReportListResDto> reportListResDto = reportFacade.getReportListSorted(filter, admin);
            int totalReportCount = reportDao.getReportListCount(filter, admin);
            Page<ReportListResDto> page = new PageImpl<>(reportListResDto, filter.getPageable(), totalReportCount);
            return new ResponseDto(HttpStatus.OK, "OK", page);
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }
}
