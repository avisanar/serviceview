package com.corpfield.serviceview.settings.controller;

import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.settings.dto.requestDto.CreateUnitReqDto;
import com.corpfield.serviceview.settings.dto.requestDto.EditOrganizationUnitReqDto;
import com.corpfield.serviceview.settings.service.OrganizationUnitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class OrganizationUnitController {

    @Autowired
    OrganizationUnitService organizationUnitService;

    @PostMapping("/admin/addUnit")
    public ResponseEntity<ResponseDto> createUnit(@RequestBody CreateUnitReqDto dto) {
        ResponseDto response = organizationUnitService.createUnit(dto);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatusCode()));
    }

    @PutMapping("/admin/editUnit")
    public ResponseEntity<ResponseDto> editUnit(@RequestBody EditOrganizationUnitReqDto dto) {
        ResponseDto response = organizationUnitService.editUnit(dto);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatusCode()));
    }

    @GetMapping("/admin/unit/{organizationUnitId}")
    public ResponseEntity<ResponseDto> findOrganizationUnitById(
            @PathVariable("organizationUnitId") long organizationUnitId
    ) {
        ResponseDto response = organizationUnitService.findOrganizationUnitById(organizationUnitId);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatusCode()));
    }
}
