package com.corpfield.serviceview.settings.dto.responseDto;

import lombok.Data;

import java.util.List;

import static com.corpfield.serviceview.utils.QueryUtils.convertObjToLong;
import static com.corpfield.serviceview.utils.QueryUtils.convertObjToString;

@Data
public class OrganizationSettingListResDto {
    private long organizationId;
    private String organizationName;
    private String organizationContactNumber;
    private String organizationEmail;
    private String organizationLogo;
    private List<OrganizationUnitListResDto>organizationUnitList;
    private List<OrganizationDepartmentListResDto>organizationDepartmentList;
    private List<OrganizationReferenceListResDto>organizationReferenceList;
    private List<OrganizationDeliveryModeListResDto>organizationDeliveryModeList;

    public static OrganizationSettingListResDto convertObjToDto(Object[] objects) {
        OrganizationSettingListResDto dto = new OrganizationSettingListResDto();
        dto.setOrganizationId(convertObjToLong(objects[0]));
        dto.setOrganizationName(convertObjToString(objects[1]));
        dto.setOrganizationContactNumber(convertObjToString(objects[2]));
        dto.setOrganizationEmail(convertObjToString(objects[3]));
        dto.setOrganizationLogo(convertObjToString(objects[4]));
        return dto;
    }
}
