package com.corpfield.serviceview.settings.dto.responseDto;

import com.corpfield.serviceview.settings.entities.OrganizationSetting;
import lombok.Data;

@Data
public class OrganizationSettingResDto {
    private long organizationSettingsId;
    private String gst;
    private String referencePrefix;
    private String referenceNumber;
    private String termsAndCondition;
    private long organizationId;

    public static OrganizationSettingResDto convertObjToDto(OrganizationSetting organizationSetting) {
        OrganizationSettingResDto dto = new OrganizationSettingResDto();
        dto.setOrganizationSettingsId(organizationSetting.getOrganizationSettingsId());
        dto.setGst(organizationSetting.getGst());
        dto.setReferencePrefix(organizationSetting.getReferencePrefix());
        dto.setReferenceNumber(organizationSetting.getReferenceNumber());
        dto.setTermsAndCondition(organizationSetting.getTermsAndConditions());
        dto.setOrganizationId(organizationSetting.getOrganization().getOrganizationId());
        return dto;
    }
}
