package com.corpfield.serviceview.customer.query;

public class CustomerQueries {
    public static final String GET_ALL_CUSTOMER = "select " +
            "  oc.organization_customer_uuid, " +
            "  c.customer_name, " +
            "  c.customer_phone_number, " +
            "  c.customer_email, " +
            "  c.customer_location, " +
            "  oc.active " +
            "  from organization_customers oc " +
            "  INNER JOIN organizations o on o.organization_id = oc.organization_id " +
            "  INNER JOIN customers c on c.customer_id = oc.customer_id " +
            "  where " +
            "  o.organization_id =:organizationId and " +
                    "( c.customer_id LIKE :searchKey " +
                    " OR c.customer_name LIKE :searchKey " +
                    " OR c.customer_phone_number LIKE :searchKey " +
                    " OR c.customer_email LIKE :searchKey " +
                    " OR c.customer_location LIKE :searchKey " +
            "  ) " ;

    public static final String GET_ALL_CUSTOMER_COUNT = "SELECT count(*) " +
            "  from organization_customers oc " +
            "  INNER JOIN organizations o on o.organization_id = oc.organization_id " +
            "  INNER JOIN customers c on c.customer_id = oc.customer_id " +
            "  where " +
            "  o.organization_id =:organizationId and " +
            "( c.customer_id LIKE :searchKey " +
            " OR c.customer_name LIKE :searchKey " +
            " OR c.customer_phone_number LIKE :searchKey " +
            " OR c.customer_email LIKE :searchKey " +
            " OR c.customer_location LIKE :searchKey " +
            "  ) " ;
}
