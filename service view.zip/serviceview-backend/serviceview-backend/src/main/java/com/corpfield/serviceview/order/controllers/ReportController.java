package com.corpfield.serviceview.order.controllers;

import com.corpfield.serviceview.common.constants.RoleConstants;
import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.order.dto.pojo.OrderFilterDto;
import com.corpfield.serviceview.order.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class ReportController {

    @Autowired
    ReportService reportService;

    @GetMapping("/admin/reportList")
    public ResponseEntity<ResponseDto> getReportList(
            @PageableDefault(size = RoleConstants.DEFAULT_PAGE_SIZE) Pageable pageable,
            @RequestParam(value = "sortField", defaultValue = "o.order_id") String sortField,
            @RequestParam(value = "sortMethod", defaultValue = "DESC") String sortMethod,
            @RequestParam(value = "searchKey", required = false) String searchKey,
            @RequestParam(value = "status", required = false) String status
    ) {
        OrderFilterDto filter = OrderFilterDto.builder()
                .sortField(sortField)
                .sortMethod(sortMethod)
                .pageable(pageable)
                .searchKey(searchKey)
                .status(status)
                .build();
        ResponseDto response = reportService.getReportList(filter);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatusCode()));
    }
}
