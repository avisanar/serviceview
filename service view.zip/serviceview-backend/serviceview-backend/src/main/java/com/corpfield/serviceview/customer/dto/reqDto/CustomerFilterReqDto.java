package com.corpfield.serviceview.customer.dto.reqDto;

import lombok.Builder;
import lombok.Data;
import org.springframework.data.domain.Pageable;

import java.util.Date;

@Data
@Builder
public class CustomerFilterReqDto {
    private String sortField;
    private String sortMethod;
    private String status;
    private String licenceStatus;
    private Date fromDate;
    private Date toDate;
    private String searchKey;
    private Pageable pageable;
}
