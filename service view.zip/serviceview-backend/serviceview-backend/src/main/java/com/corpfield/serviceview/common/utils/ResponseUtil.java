package com.corpfield.serviceview.common.utils;

import com.corpfield.serviceview.common.dto.ResponseDto;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.SneakyThrows;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import javax.servlet.http.HttpServletResponse;

public class ResponseUtil {
    public static ResponseEntity<ResponseDto> generateResponse(ResponseDto response) {
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatusCode()));
    }

    @SneakyThrows
    public static void generateServletResponse(HttpStatus status, HttpServletResponse response) {
        response.setStatus(status.value());
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        ObjectMapper mapper = new ObjectMapper();
        ResponseDto responseData = new ResponseDto(status, "Invalid token");
        response.getWriter().println(mapper.writeValueAsString(responseData));
    }
}
