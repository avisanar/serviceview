package com.corpfield.serviceview.License.dao;

import com.corpfield.serviceview.License.queries.LicenseQueries;
import com.corpfield.serviceview.employee.queries.EmployeeQueries;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

import static com.corpfield.serviceview.utils.QueryUtils.*;

@Component
public class LicenseDao {

    @PersistenceContext
    EntityManager entityManager;

    public List<Object[]> findUsersList(Pageable pageable, long organizationId) {
        String sql = LicenseQueries.GET_USERS_LIST;
        Query query = entityManager.createNativeQuery(sql)
                .setParameter("organizationId",organizationId)
                .setFirstResult(pageable.getPageNumber() * pageable.getPageSize())
                .setMaxResults(pageable.getPageSize());
      return query.getResultList();
    }

    public long findUsersCount(long organizationId) {
        String sql = LicenseQueries.GET_USERS_COUNT;
        Query query = entityManager.createNativeQuery(sql)
                .setParameter("organizationId",organizationId);
        Object obj=query.getSingleResult();
        return convertObjToLong(obj);
    }
}
