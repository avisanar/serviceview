package com.corpfield.serviceview.License.controllers;

import com.corpfield.serviceview.License.dto.requestDto.CreatePlanReqDto;
import com.corpfield.serviceview.License.service.PlanService;
import com.corpfield.serviceview.common.dto.ResponseDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PlanController {

    @Autowired
    PlanService planService;

    @PostMapping("/public/plan/createPlan")
    public ResponseEntity<ResponseDto> createPlan(@RequestBody CreatePlanReqDto dto){
        ResponseDto response=planService.createPlan(dto);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatusCode()));
    }

    @GetMapping("/public/license-listPlans")
    public ResponseEntity<ResponseDto> listAllPlans(){
        ResponseDto response=planService.listAllPlans();
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatusCode()));
    }
}
