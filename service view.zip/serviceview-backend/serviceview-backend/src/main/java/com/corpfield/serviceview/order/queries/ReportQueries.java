package com.corpfield.serviceview.order.queries;

public class ReportQueries {
    public static final String GET_REPORT_LIST = "select " +
            "c.customer_id, " +
            "c.customer_name, " +
            "o.order_id, " +
            "o.ordered_on, " +
            "o.delivery_on, " +
            "o.delivery_status " +
            "from orders o " +
            "INNER JOIN organizations org on org.organization_id = o.organization_id " +
            "INNER JOIN customers c on c.customer_id = o.customer_id " +
            "where " +
            "(o.delivery_status ='Delivered' " +
            "or o.delivery_status ='Cancelled') and " +
            "org.organization_id =:organizationId and " +
            "( c.customer_id LIKE :searchKey " +
            " OR c.customer_name LIKE :searchKey " +
            " OR o.order_id LIKE :searchKey " +
            " OR o.ordered_on LIKE :searchKey " +
            " OR o.delivery_on LIKE :searchKey " +
            "  ) " ;


    public static final String GET_REPORT_LIST_COUNT = "SELECT count(*) " +
            "from orders o " +
            "INNER JOIN organizations org on org.organization_id = o.organization_id " +
            "INNER JOIN customers c on c.customer_id = o.customer_id " +
            "where " +
            "(o.delivery_status ='Delivered' " +
            "or o.delivery_status ='Cancelled') and " +
            "org.organization_id =:organizationId and " +
            "( c.customer_id LIKE :searchKey " +
            " OR c.customer_name LIKE :searchKey " +
            " OR o.order_id LIKE :searchKey " +
            " OR o.ordered_on LIKE :searchKey " +
            " OR o.delivery_on LIKE :searchKey " +
            "  ) " ;
}
