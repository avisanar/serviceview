package com.corpfield.serviceview.organization.dto.requestDto;

import lombok.Data;

@Data
public class CheckDomainAvailableReqDto {
    private String domainName;
}
