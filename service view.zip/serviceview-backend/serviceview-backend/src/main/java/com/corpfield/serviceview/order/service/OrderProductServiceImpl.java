package com.corpfield.serviceview.order.service;

import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.common.exception.ServiceViewException;
import com.corpfield.serviceview.order.dto.requestDto.EditOrderProductReqDto;
import com.corpfield.serviceview.order.entities.Order;
import com.corpfield.serviceview.order.entities.OrderProduct;
import com.corpfield.serviceview.order.facade.OrderProductFacade;
import com.corpfield.serviceview.product.entities.Product;
import com.corpfield.serviceview.product.facade.ProductFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
public class OrderProductServiceImpl implements OrderProductService {

    @Autowired
    OrderProductFacade orderProductFacade;

    @Autowired
    ProductFacade productFacade;


    @Override
    public ResponseDto editOrderProduct(EditOrderProductReqDto reqDto) {
        try {
            OrderProduct orderProduct = orderProductFacade.findOrderProductById(reqDto.getOrderProductId());
            Order order = orderProduct.getOrder();
            Product product = productFacade.findProductById(reqDto.getProductId());
            orderProductFacade.checkIfProductToBeEdited(order);
            OrderProduct updatedOrderProduct = reqDto.editOrderProduct(orderProduct, product);
            orderProductFacade.persistOrderProduct(updatedOrderProduct);
            return new ResponseDto(HttpStatus.OK, "OK", "Product Edited Successfully");
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto removeOrderProduct(long orderProductId) {
        try {
            OrderProduct orderProduct = orderProductFacade.findOrderProductById(orderProductId);
            orderProductFacade.checkIfProductToBeEdited(orderProduct.getOrder());
            orderProduct.setOrder(null);
            orderProduct.setProduct(null);
            orderProductFacade.removeProductFromOrderProduct(orderProduct.getOrderProductId());
            return new ResponseDto(HttpStatus.OK, "OK", "Product Removed successfully");
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }

    }

}
