package com.corpfield.serviceview.customer.dto.reqDto;

import com.corpfield.serviceview.customer.entities.Customer;
import lombok.Data;

import java.util.UUID;

@Data
public class CreateCustomerReqDto {
    private long customerId;
    private String customerName;
    private String customerPhoneNumber;
    private String customerEmail;
    private String customerLocation;

    public Customer convertObjToDto(String customerUuid) {
        Customer customer = new Customer();
        customer.setCustomerUuid(customerUuid);
        customer.setCustomerName(this.customerName);
        customer.setCustomerPhoneNumber(this.customerPhoneNumber);
        customer.setCustomerEmail(this.customerEmail);
        customer.setCustomerLocation(this.customerLocation);
        customer.setActive(true);
        return customer;
    }
}
