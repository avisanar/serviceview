package com.corpfield.serviceview.product.repositories;

import com.corpfield.serviceview.product.entities.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductsRepo extends JpaRepository<Product, Long> {

}
