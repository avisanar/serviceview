package com.corpfield.serviceview.organization.dto.requestDto;

import com.corpfield.serviceview.common.utils.PasswordUtil;
import com.corpfield.serviceview.organization.enities.Organization;
import com.corpfield.serviceview.organization.enities.OrganizationAdmin;
import lombok.Data;

import java.util.UUID;

@Data
public class CreateOrganizationReqDto {
    private String organizationName;
    private String organizationDomainName;
    private String contactNumber;
    private String contactEmail;
    private String newPassword;
    private String confirmPassword;
    //private boolean isVerifiedEmail;

    public Organization createOrganizationEntity() {
        Organization organization = new Organization();
        organization.setOrganizationName(this.organizationName);
        organization.setOrganizationDomainName(this.organizationDomainName);
        return  organization;
    }

    public OrganizationAdmin createOrganizationAdmin() {
        OrganizationAdmin organizationAdmin = new OrganizationAdmin();
        organizationAdmin.setEmail(this.contactEmail);
        organizationAdmin.setPhone(this.getContactNumber());
        organizationAdmin.setRole("ADMIN");
        organizationAdmin.setCountryCode("91");
        organizationAdmin.setPassword(PasswordUtil.hashPassword(this.getNewPassword()));
        return  organizationAdmin;
    }
}
