package com.corpfield.serviceview.License.entities;

import com.corpfield.serviceview.common.enities.AuditEntity;
import com.corpfield.serviceview.organization.enities.Organization;
import com.corpfield.serviceview.organization.enities.OrganizationAdmin;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Date;

@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@Table(name = "License")
public class License extends AuditEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "license_id")
    private long licenseId;

    @Column(name = "total_license")
    private long totalLicense;

    @Column(name = "purchased_date")
    private Date purchasedDate;

    @Column(name="expiry_date")
    private Date expiryDate;

    @Column(name="assigned_license")
    private long assignedLicense;

    @Column(name="total_cost")
    private Double totalCost;

    @Column(name="previous_balance")
    private double previousBalance;

    @ManyToOne
    @JoinColumn(name = "plan_id")
    @JsonIgnore
    @NotNull
    private Plan plan;

    @ManyToOne
    @JoinColumn(name = "organization_id")
    @JsonIgnore
    @NotNull
    private Organization organization;

    @Column(name = "license_uuid", unique = true, nullable = false)
    private String licenseUuid;

    @Column(name="is_Paid")
    private Boolean isPaid;
}
