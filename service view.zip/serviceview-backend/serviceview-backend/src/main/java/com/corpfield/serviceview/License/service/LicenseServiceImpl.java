package com.corpfield.serviceview.License.service;

import com.corpfield.serviceview.License.dao.LicenseDao;
import com.corpfield.serviceview.License.dto.requestDto.AssignLicenseReqDto;
import com.corpfield.serviceview.License.dto.requestDto.BuyMoreLicenseReqDto;
import com.corpfield.serviceview.License.dto.requestDto.LicensePlanReqDto;
import com.corpfield.serviceview.License.dto.responseDto.*;
import com.corpfield.serviceview.License.entities.License;
import com.corpfield.serviceview.License.facade.LicenseFacade;
import com.corpfield.serviceview.License.pojo.LicensePlanFilter;
import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.common.exception.ServiceViewException;
import com.corpfield.serviceview.common.utils.AuthUtil;
import com.corpfield.serviceview.organization.enities.Organization;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LicenseServiceImpl implements LicenseService {


    @Autowired
    LicenseFacade licenseFacade;

    @Autowired
    LicenseDao licenseDao;


    @Override
    public ResponseDto getPackageSummary(LicensePlanFilter filter) {
        try {
            LicensePackageSummaryResDto dto = this.licenseFacade.getPackageDetails(filter);
            return new ResponseDto(HttpStatus.OK, dto);
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }


    @Override
    public ResponseDto getUsers(Pageable pageable) {
        try {
            String adminUuid = AuthUtil.currentUserUUId();
            Organization organization = this.licenseFacade.findOrganizationByAdminUuid(adminUuid);
            List<Object[]> objList = this.licenseDao.findUsersList(pageable, organization.getOrganizationId());
            List<UserListResDto> userList = this.licenseFacade.mapObjectsToDto(objList);
            long userListCount = this.licenseDao.findUsersCount(organization.getOrganizationId());
            Page<UserListResDto> pagedUserList = new PageImpl<>(userList, pageable, userListCount);
            return new ResponseDto(HttpStatus.OK, "OK", pagedUserList);

        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto assignLicense(List<AssignLicenseReqDto> dto) {
        try {
            String adminUuid = AuthUtil.currentUserUUId();
            Organization organization = this.licenseFacade.findOrganizationByAdminUuid(adminUuid);
            License license = this.licenseFacade.findByOrganizationOrganizationUuid(organization);
            this.licenseFacade.assignLicense(dto, license);
            return new ResponseDto(HttpStatus.OK, "license Assigned");
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto getPackageDetails(LicensePlanFilter filter) {
        try {
            LicensePackageDetailsResDto planPackageDetailsResDto = this.licenseFacade.getPlanPackageDetails(filter);
            return new ResponseDto(HttpStatus.OK, planPackageDetailsResDto);
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto getRenewPlanDetails(String licenseUuid) {
        try {
            LicenseRenewDetailsResDto resDto = this.licenseFacade.getRenewPlanDetails(licenseUuid);
            return new ResponseDto(HttpStatus.OK, resDto);
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto createLicensePlan(LicensePlanReqDto reqDto) {
        try {
            String adminUuid = AuthUtil.currentUserUUId();
            Organization organization = this.licenseFacade.findOrganizationByAdminUuid(adminUuid);
            this.licenseFacade.createLicensePlan(reqDto, organization);
            return new ResponseDto(HttpStatus.OK, "License Plan Created Successfully");
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }

    }

    @Override
    public ResponseDto changeLicensePlan(LicensePlanReqDto reqDto) {
        try {
            String adminUuid = AuthUtil.currentUserUUId();
            Organization organization = this.licenseFacade.findOrganizationByAdminUuid(adminUuid);
            License license = this.licenseFacade.findByOrganizationOrganizationUuid(organization);
            this.licenseFacade.changeLicensePlan(license, reqDto);
            return new ResponseDto(HttpStatus.OK, "License Plan Changed Successfully");
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto renewLicensePlan(LicensePlanReqDto reqDto) {
        try {
            String adminUuid = AuthUtil.currentUserUUId();
            Organization organization = this.licenseFacade.findOrganizationByAdminUuid(adminUuid);
            License license = this.licenseFacade.findByOrganizationOrganizationUuid(organization);
            this.licenseFacade.renewPlan(license, reqDto);
            return new ResponseDto(HttpStatus.OK, "License Plan Changed Successfully");
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }

    }

    @Override
    public ResponseDto getExistingLicenseDetails(long addLicense) {
        try {
            String adminUuid = AuthUtil.currentUserUUId();
            Organization organization = this.licenseFacade.findOrganizationByAdminUuid(adminUuid);
            License license = this.licenseFacade.findByOrganizationOrganizationUuid(organization);
            LicenseExistingDetailsResDto resDto = this.licenseFacade.getExistingLicenseDetails(license);
            return new ResponseDto(HttpStatus.OK, resDto);
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto addMoreLicense(BuyMoreLicenseReqDto reqDto) {
        try {
            String adminUuid = AuthUtil.currentUserUUId();
            Organization organization = this.licenseFacade.findOrganizationByAdminUuid(adminUuid);
            License license = this.licenseFacade.findByOrganizationOrganizationUuid(organization);
            this.licenseFacade.addMoreLicense(license,reqDto);
            return new ResponseDto(HttpStatus.OK,"License Added Successfully");
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }
}
