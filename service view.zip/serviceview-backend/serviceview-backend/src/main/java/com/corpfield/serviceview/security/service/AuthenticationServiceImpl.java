package com.corpfield.serviceview.security.service;

import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.common.exception.ServiceViewException;
import com.corpfield.serviceview.common.utils.PasswordUtil;
import com.corpfield.serviceview.organization.enities.OrganizationAdmin;
import com.corpfield.serviceview.organization.facade.OrganizationAdminFacade;
import com.corpfield.serviceview.organization.repositories.OrganizationAdminsRepo;
import com.corpfield.serviceview.security.config.JwtTokenManager;
import com.corpfield.serviceview.security.dto.OrganizationAdminLoginDto;
import com.corpfield.serviceview.security.pojo.ServiceViewUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
public class AuthenticationServiceImpl implements AuthenticationService {

    @Autowired
    private OrganizationAdminsRepo organizationAdminsRepo;

    @Autowired
    private JwtTokenManager jwtTokenManager;

    @Autowired
    private OrganizationAdminFacade organizationAdminFacade;

    @Override
    public ResponseDto organizationalAdminLogin(OrganizationAdminLoginDto dto) {
        try {
            OrganizationAdmin user = organizationAdminFacade.getOrThrowOrganizationAdminByEmail(dto.getEmail());
            boolean isPasswordValid = PasswordUtil.verifyPassword(dto.getPassword(), user.getPassword());
            if (!isPasswordValid) {
                return new ResponseDto(HttpStatus.BAD_REQUEST, "Invalid Credentials");
            }
            ServiceViewUser serviceViewUser = ServiceViewUser.generateUser(user);
            String token = jwtTokenManager.generateToken(serviceViewUser);
            return new ResponseDto(HttpStatus.OK, "OK", token);
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }
}
