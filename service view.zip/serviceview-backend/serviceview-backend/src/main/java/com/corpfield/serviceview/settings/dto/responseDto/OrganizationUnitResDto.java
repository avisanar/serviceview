package com.corpfield.serviceview.settings.dto.responseDto;

import com.corpfield.serviceview.settings.entities.OrganizationUnit;
import lombok.Data;

@Data
public class OrganizationUnitResDto {
    private long organizationUnitId;
    private String organizationUnitName;
    private boolean status;
    private long organizationId;

    public static OrganizationUnitResDto convertObjToDto(OrganizationUnit organizationUnit) {
        OrganizationUnitResDto dto = new OrganizationUnitResDto();
        dto.setOrganizationUnitId(organizationUnit.getOrganizationUnitId());
        dto.setOrganizationUnitName(organizationUnit.getUnitName());
        dto.setStatus(organizationUnit.isActive());
        dto.setOrganizationId(organizationUnit.getOrganization().getOrganizationId());
        return dto;
    }
}
