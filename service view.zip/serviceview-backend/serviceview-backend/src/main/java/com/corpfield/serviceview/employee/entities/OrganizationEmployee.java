package com.corpfield.serviceview.employee.entities;

import com.corpfield.serviceview.common.department.entities.OrganizationDepartment;
import com.corpfield.serviceview.common.enities.AuditEntity;
import com.corpfield.serviceview.organization.enities.Organization;
import lombok.Data;
import lombok.EqualsAndHashCode;


import javax.persistence.*;
import javax.validation.constraints.NotNull;

@EqualsAndHashCode(callSuper = true)
@Data
@Entity
@Table(name = "organization_employees")
public class OrganizationEmployee extends AuditEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "organization_employees_id")
    private long OrganizationEmployeeId;

    @Column(name = "organization_employee_uuid", unique = true, nullable = false)
    private String organizationEmployeeUuid;

    @ManyToOne
    @JoinColumn(name = "employee_id")
    @NotNull
    private Employee employee;

    @ManyToOne
    @JoinColumn(name = "organization_department_id")
    @NotNull
    private OrganizationDepartment organizationDepartment;

    @Column(name = "active")
    private boolean active;

    @Column(name = "license_assigned",  columnDefinition = "Boolean default FALSE")
    private boolean licenseAssigned;

    @ManyToOne
    @JoinColumn(name = "organization_id")
    @NotNull
    private Organization organization;



}
