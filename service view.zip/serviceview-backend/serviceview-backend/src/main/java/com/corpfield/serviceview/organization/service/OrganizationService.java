package com.corpfield.serviceview.organization.service;

import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.organization.dto.requestDto.CheckDomainAvailableReqDto;
import com.corpfield.serviceview.organization.dto.requestDto.CreateOrganizationReqDto;
import org.springframework.stereotype.Service;

public interface OrganizationService {
    ResponseDto createOrganizationAdmin(CreateOrganizationReqDto dto);


    ResponseDto checkDomainNameAvailability(CheckDomainAvailableReqDto dto);

    ResponseDto getAdminProfile();
}
