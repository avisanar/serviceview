package com.corpfield.serviceview.settings.service;

import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.settings.dto.requestDto.CreateUnitReqDto;
import com.corpfield.serviceview.settings.dto.requestDto.EditOrganizationUnitReqDto;

public interface OrganizationUnitService {

    ResponseDto createUnit(CreateUnitReqDto dto);

    ResponseDto editUnit(EditOrganizationUnitReqDto dto);

    ResponseDto findOrganizationUnitById(long organizationUnitId);
}
