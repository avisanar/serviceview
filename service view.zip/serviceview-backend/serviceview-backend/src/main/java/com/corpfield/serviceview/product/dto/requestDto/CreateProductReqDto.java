package com.corpfield.serviceview.product.dto.requestDto;

import lombok.Data;

import java.util.Date;

@Data
public class CreateProductReqDto {
    private String productName;
    private long unitId;
    private long availableStock;
    private double currentPrice;
    private double newPrice;
    private Date priceEffectiveDate;
}
