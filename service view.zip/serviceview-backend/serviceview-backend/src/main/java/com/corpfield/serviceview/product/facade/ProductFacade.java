package com.corpfield.serviceview.product.facade;

import com.corpfield.serviceview.common.exception.ServiceViewException;
import com.corpfield.serviceview.organization.enities.Organization;
import com.corpfield.serviceview.product.dto.requestDto.CreateProductReqDto;
import com.corpfield.serviceview.product.dto.requestDto.EditProductReqDto;
import com.corpfield.serviceview.product.dto.responseDto.ProductResDto;
import com.corpfield.serviceview.product.entities.Product;
import com.corpfield.serviceview.product.repositories.ProductsRepo;
import com.corpfield.serviceview.settings.entities.OrganizationUnit;
import com.corpfield.serviceview.settings.facade.OrganizationUnitFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
public class ProductFacade {

    @Autowired
    ProductsRepo productsRepo;

    @Autowired
    OrganizationUnitFacade organizationUnitFacade;


    public Product findProductById(long productId) throws Exception {
        Optional<Product> productOpt = this.productsRepo.findById(productId);
        productOpt.orElseThrow(() -> new ServiceViewException("Product not found"));
        return productOpt.get();
    }

    public void createProduct(CreateProductReqDto reqDto, Organization organization) throws Exception {
        Product product=new Product();
        product.setOrganization(organization);
        product.setProductName(reqDto.getProductName());
        product.setAvailableStock(reqDto.getAvailableStock());
        product.setCurrentPrice(reqDto.getCurrentPrice());
        product.setNewPrice(reqDto.getNewPrice());
        product.setPriceEffectiveDate(reqDto.getPriceEffectiveDate());
        OrganizationUnit organizationUnit=organizationUnitFacade.findOrganizationUnitById(reqDto.getUnitId());
        product.setOrganizationUnit(organizationUnit);
        productsRepo.save(product);
    }


    public void editProduct(EditProductReqDto reqDto) throws Exception {
        Product product=this.findProductById(reqDto.getProductId());
        product.setProductName(reqDto.getProductName());
        product.setAvailableStock(reqDto.getAvailableStock());
        product.setCurrentPrice(reqDto.getCurrentPrice());
        product.setNewPrice(reqDto.getNewPrice());
        product.setPriceEffectiveDate(reqDto.getPriceEffectiveDate());
        product.setActive(reqDto.isStatus());
        OrganizationUnit organizationUnit=organizationUnitFacade.findOrganizationUnitById(reqDto.getUnitId());
        product.setOrganizationUnit(organizationUnit);
        productsRepo.save(product);
    }

    public List<ProductResDto> mapObjectsToDto(List<Object[]> objProductList) {
        List<ProductResDto> productsList=objProductList.stream()
                .map(ProductResDto::convertObjToDto)
                .collect(Collectors.toList());
        return productsList;
    }
}
