package com.corpfield.serviceview.License.entities;

import com.corpfield.serviceview.common.enities.AuditEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;

@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@Table(name = "Plan")
public class Plan extends AuditEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "plan_id")
    private long planId;

    @Column(name = "per_License_cost")
    private double perLicenseCost;

    @Column(name = "number_of_days")
    private int numberOfDays;

    @Column(name = "plan_uuid", unique = true, nullable = false)
    private String planUuid;


}
