package com.corpfield.serviceview.employee.dto.responseDto;

import lombok.Data;

import static com.corpfield.serviceview.utils.QueryUtils.*;

@Data
public class EmployeeListResDto {
    private String employeeUuid;
    private String fullName;
    private String phoneNumber;
    private String departmentName;
    private boolean licenseAssigned;
    private boolean active;

    public static EmployeeListResDto convertObjToDto(Object[] obj) {
        EmployeeListResDto dto = new EmployeeListResDto();
        dto.setEmployeeUuid(convertObjToString(obj[0]));
        dto.setFullName(convertObjToString(obj[1]));
        if (convertObjToString(obj[2]) != null) {
            dto.setFullName(convertObjToString(obj[1]) + " " + convertObjToString(obj[2]));
        }
        dto.setPhoneNumber(convertObjToString(obj[3]));
        dto.setDepartmentName(convertObjToString(obj[4]));
        dto.setLicenseAssigned(getActiveStatus(obj[5]));
        dto.setActive(getActiveStatus(obj[6]));
        return dto;
    }

}
