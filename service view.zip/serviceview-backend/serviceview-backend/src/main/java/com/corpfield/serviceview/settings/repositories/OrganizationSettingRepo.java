package com.corpfield.serviceview.settings.repositories;

import com.corpfield.serviceview.settings.entities.OrganizationSetting;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrganizationSettingRepo extends JpaRepository<OrganizationSetting,Long> {
    List<OrganizationSetting> findByOrganizationOrganizationId(long organizationId);
}
