package com.corpfield.serviceview.dashboard.dao;

import com.corpfield.serviceview.dashboard.queries.DashboardQueries;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static com.corpfield.serviceview.utils.QueryUtils.setSearchKey;

@Component
public class DashboardDao {

    @PersistenceContext
    EntityManager entityManager;



    public List<Object[]> getOverviewDetails(long organizationId, String todayDate) {
        String sql= DashboardQueries.GET_OVERVIEW_DETAILS;
        Query query=entityManager.createNativeQuery(sql)
                .setParameter("organizationId",organizationId)
                .setParameter("todayDate",setSearchKey(todayDate));
        return query.getResultList();
    }
}
