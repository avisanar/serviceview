package com.corpfield.serviceview.settings.controller;

import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.settings.dto.requestDto.DeliveryModeCreateReqDto;
import com.corpfield.serviceview.settings.dto.requestDto.EditDeliveryModeReqDto;
import com.corpfield.serviceview.settings.service.OrganizationDeliveryModeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class OrganizationDeliveryModeController {

    @Autowired
    OrganizationDeliveryModeService deliveryModeService;

    @PostMapping("/admin/deliveryMode")
    public ResponseEntity<ResponseDto> addDeliveryMode(@RequestBody DeliveryModeCreateReqDto reqDto) {
        ResponseDto dto = deliveryModeService.addDeliveryType(reqDto);
        return new ResponseEntity<>(dto, HttpStatus.valueOf(dto.getStatusCode()));
    }

    @GetMapping("/admin/deliveryMode/{deliveryModeId}")
    public ResponseEntity<ResponseDto> getOrganizationById(
            @PathVariable("deliveryModeId") long deliveryModeId
    ) {
        ResponseDto dto = deliveryModeService.findDeliveryModeById(deliveryModeId);
        return new ResponseEntity<>(dto, HttpStatus.valueOf(dto.getStatusCode()));
    }

    @PutMapping("/admin/deliveryMode")
    public ResponseEntity<ResponseDto> editDeliveryMode(@RequestBody EditDeliveryModeReqDto reqDto) {
        ResponseDto dto = deliveryModeService.editDeliveryModeStatus(reqDto);
        return new ResponseEntity<>(dto, HttpStatus.valueOf(dto.getStatusCode()));
    }

}
