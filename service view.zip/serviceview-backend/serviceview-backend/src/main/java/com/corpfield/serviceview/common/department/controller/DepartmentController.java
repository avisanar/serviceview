package com.corpfield.serviceview.common.department.controller;

import com.corpfield.serviceview.common.department.dto.CreateDepartmentReqDto;
import com.corpfield.serviceview.common.department.dto.EditDepartmentReqDto;
import com.corpfield.serviceview.common.department.service.DepartmentService;
import com.corpfield.serviceview.common.dto.ResponseDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class DepartmentController {

    @Autowired
    DepartmentService departmentService;

    @PostMapping("/admin/addDepartment")
    public ResponseEntity<ResponseDto> createDepartment(
            @RequestBody CreateDepartmentReqDto reqDto
    ) {
        ResponseDto dto = departmentService.createDepartment(reqDto);
        return new ResponseEntity<>(dto, HttpStatus.valueOf(dto.getStatusCode()));
    }

   @GetMapping("/admin/department/{organizationDepartmentId}")
    public ResponseEntity<ResponseDto> findOrganizationDepartmentById(
            @PathVariable ("organizationDepartmentId") long organizationDepartmentId
   ) {
       ResponseDto dto = departmentService.findOrganizationDepartmentById(organizationDepartmentId);
       return new ResponseEntity<>(dto, HttpStatus.valueOf(dto.getStatusCode()));
   }

   @PutMapping("/admin/editDepartment")
    public ResponseEntity<ResponseDto> editDepartment(
            @RequestBody EditDepartmentReqDto reqDto
   ) {
       ResponseDto dto = departmentService.UpdateDepartmentDetails(reqDto);
       return new ResponseEntity<>(dto, HttpStatus.valueOf(dto.getStatusCode()));
   }

}
