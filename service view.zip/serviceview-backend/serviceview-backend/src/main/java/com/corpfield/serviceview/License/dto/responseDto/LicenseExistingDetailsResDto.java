package com.corpfield.serviceview.License.dto.responseDto;

import lombok.Data;

@Data
public class LicenseExistingDetailsResDto {
    private long ExistingLicenses;
    private long addLicense;
    private long totalLicense;
    private double totalCost;
}
