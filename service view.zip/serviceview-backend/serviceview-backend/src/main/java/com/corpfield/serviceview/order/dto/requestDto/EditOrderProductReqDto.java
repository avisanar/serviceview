package com.corpfield.serviceview.order.dto.requestDto;

import com.corpfield.serviceview.order.entities.OrderProduct;
import com.corpfield.serviceview.product.entities.Product;
import lombok.Data;
import org.hibernate.service.spi.ServiceException;

@Data
public class EditOrderProductReqDto {
    private long orderProductId;
    private long productId;
    private int quantity;

    public OrderProduct editOrderProduct(OrderProduct orderProduct, Product product) {
        orderProduct.setProduct(product);
        if (quantity < 1) {
            throw new ServiceException("Quantity is required and cannot be less than zero");
        }
        orderProduct.setQuantity(quantity);
        return orderProduct;
    }

}
