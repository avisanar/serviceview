package com.corpfield.serviceview.employee.facade;

import com.corpfield.serviceview.common.department.entities.OrganizationDepartment;
import com.corpfield.serviceview.common.exception.ServiceViewException;
import com.corpfield.serviceview.employee.dao.EmployeeDao;
import com.corpfield.serviceview.employee.dto.pojo.AdminEmployeeFilterDto;
import com.corpfield.serviceview.employee.dto.requestDto.CreateEmployeeReqDto;
import com.corpfield.serviceview.employee.dto.responseDto.EmployeeListResDto;
import com.corpfield.serviceview.employee.entities.Employee;
import com.corpfield.serviceview.employee.entities.OrganizationEmployee;
import com.corpfield.serviceview.employee.repositories.EmployeesRepo;
import com.corpfield.serviceview.employee.repositories.OrganizationEmployeesRepo;
import com.corpfield.serviceview.organization.enities.OrganizationAdmin;
import com.corpfield.serviceview.organization.repositories.OrganizationAdminsRepo;
import com.corpfield.serviceview.utils.AuthUtil;
import org.hibernate.service.spi.ServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Component
public class EmployeeFacade {

    @Autowired
    EmployeesRepo employeesRepo;

    @Autowired
    EmployeeDao employeeDao;

    @Autowired
    OrganizationEmployeesRepo organizationEmployeesRepo;

    @Autowired
    OrganizationAdminsRepo organizationsAdminsRepo;

    public void persistEmployee(Employee employee) {
        employeesRepo.save(employee);
    }

    public Employee findEmployeeByPhoneNumber(String phoneNumber) {
        Optional<Employee> optionalEmployee = employeesRepo.findByPhoneNumber(phoneNumber);
        return optionalEmployee.orElseThrow(() -> new ServiceException("No data found"));
    }

    public Employee findEmployeeById(long employeeId) {
        Optional<Employee> optEmployee = employeesRepo.findById(employeeId);
        return optEmployee.orElseThrow(() -> new ServiceException("No data found"));
    }

    public List<EmployeeListResDto> findEmployeeListSorted(AdminEmployeeFilterDto filter, OrganizationAdmin admin) {
        List<Object[]> employeeObj = employeeDao.findEmployeeList(filter, admin);
        List<EmployeeListResDto> employeeResList = employeeObj.stream()
                .map(EmployeeListResDto::convertObjToDto)
                .collect(Collectors.toList());
        return employeeResList;
    }


    public void addEmployee(CreateEmployeeReqDto reqDto, OrganizationDepartment department) {
        Optional<Employee> optionalEmployee = employeesRepo.findByPhoneNumber(reqDto.getPhoneNumber());
        if (optionalEmployee.isPresent()) {
            String organizationEmployeeUuid = UUID.randomUUID().toString().replace("-", "");
            organizationEmployeeUuid = this.checkAlreadyExistOrganizationEmployeeUUID(organizationEmployeeUuid);
            this.setOrganizationEmployee(optionalEmployee, organizationEmployeeUuid, department);

        } else {
            String employeeUuid = UUID.randomUUID().toString().replace("-", "");
            employeeUuid = this.checkAlreadyExistEmployeeUuid(employeeUuid);
            Employee employee = reqDto.convertDtoToEntity(employeeUuid);
            this.persistEmployee(employee);
            String organizationEmployeeUuid = UUID.randomUUID().toString().replace("-", "");
            organizationEmployeeUuid = this.checkAlreadyExistOrganizationEmployeeUUID(organizationEmployeeUuid);
            this.setEmployeeForOrganization(employee, organizationEmployeeUuid, department);
        }
    }


    private String checkAlreadyExistEmployeeUuid(String employeeUuid) {
        Optional<Employee> optionalEmployee = employeesRepo.findByEmployeeUuid(employeeUuid);
        while (optionalEmployee.isPresent()) {
            employeeUuid = UUID.randomUUID().toString().replace("-", "");
            checkAlreadyExistEmployeeUuid(employeeUuid);
        }
        return employeeUuid;
    }

    private String checkAlreadyExistOrganizationEmployeeUUID(String organizationEmployeeUuid) {
        Optional<OrganizationEmployee> optOrganizationEmployee = organizationEmployeesRepo.
                findByOrganizationEmployeeUuid(organizationEmployeeUuid);
        while (optOrganizationEmployee.isPresent()) {
            organizationEmployeeUuid = UUID.randomUUID().toString().replace("-", "");
            checkAlreadyExistOrganizationEmployeeUUID(organizationEmployeeUuid);
        }
        return organizationEmployeeUuid;
    }

    private void setEmployeeForOrganization(Employee employee, String organizationEmployeeUuid, OrganizationDepartment department) {
        OrganizationEmployee organizationEmployee = new OrganizationEmployee();
        organizationEmployee.setOrganizationEmployeeUuid(organizationEmployeeUuid);
        organizationEmployee.setEmployee(employee);
        organizationEmployee.setActive(true);
        organizationEmployee.setOrganizationDepartment(department);
        this.setOrganization(organizationEmployee);
        organizationEmployeesRepo.save(organizationEmployee);
    }

    private void setOrganizationEmployee(Optional<Employee> optionalEmployee, String organizationEmployeeUuid, OrganizationDepartment department) {
        OrganizationEmployee organizationEmployee = new OrganizationEmployee();
        organizationEmployee.setOrganizationEmployeeUuid(organizationEmployeeUuid);
        organizationEmployee.setEmployee(optionalEmployee.get());
        organizationEmployee.setActive(true);
        organizationEmployee.setOrganizationDepartment(department);
        this.setOrganization(organizationEmployee);
        organizationEmployeesRepo.save(organizationEmployee);
    }

    private void setOrganization(OrganizationEmployee organizationEmployee) {
        String organizationAdminUuid = AuthUtil.currentUserId();
        Optional<OrganizationAdmin> optOrganizationAdmin = this.organizationsAdminsRepo.findByOrganizationAdminUuid(organizationAdminUuid);
        optOrganizationAdmin.orElseThrow(() -> new ServiceException("Organization not found"));
        if (optOrganizationAdmin.isPresent()) {
            organizationEmployee.setOrganization(optOrganizationAdmin.get().getOrganization());
        }
    }

    public OrganizationEmployee findEmployeeInOrganizationEmployee(long employeeId) throws Exception {
        Optional<OrganizationEmployee> optOrganizationEmployee = organizationEmployeesRepo.findByEmployeeEmployeeId(employeeId);
        return optOrganizationEmployee.orElseThrow(() -> new ServiceViewException("No data found"));
    }

    public void persistOrganizationEmployee(OrganizationEmployee organizationEmployee) {
        organizationEmployeesRepo.save(organizationEmployee);
    }

    public OrganizationAdmin findAuthOrganization(String organizationAdminUuid) {
        Optional<OrganizationAdmin> optOrganizationAdmin = this.organizationsAdminsRepo.findByOrganizationAdminUuid(organizationAdminUuid);
        return optOrganizationAdmin.orElseThrow(() -> new ServiceException("Organization Admin not found"));
    }

    public OrganizationEmployee findOrganizationInOrganizationEmp(OrganizationAdmin admin) {
        Optional<OrganizationEmployee> optOrganizationEmp = organizationEmployeesRepo.
                findByOrganizationOrganizationId(admin.getOrganization().getOrganizationId());
        return optOrganizationEmp.orElseThrow(() -> new ServiceException("Organization not found"));

    }

    public void checkIfEmployeeIsAlreadyPresentInOrganization(CreateEmployeeReqDto reqDto) throws ServiceViewException {
        String organizationAdminUuid = AuthUtil.currentUserId();
        Optional<OrganizationAdmin> optOrganizationAdmin = this.organizationsAdminsRepo.findByOrganizationAdminUuid(organizationAdminUuid);
        Optional<Employee> optionalEmployee = employeesRepo.findByPhoneNumber(reqDto.getPhoneNumber());
        if (optionalEmployee.isPresent()) {
            long employeeId = optionalEmployee.get().getEmployeeId();
            long organizationId = optOrganizationAdmin.get().getOrganization().getOrganizationId();
            Optional<OrganizationEmployee> organizationEmployee = organizationEmployeesRepo.findByEmployeeEmployeeIdAndOrganizationOrganizationId(employeeId, organizationId);
            if(organizationEmployee.isPresent()){
                throw new ServiceViewException("Employee Already Presented");
            }
        }
    }
}

