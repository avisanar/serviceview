package com.corpfield.serviceview.dashboard.service;

import com.corpfield.serviceview.common.dto.ResponseDto;

public interface DashboardService {
    ResponseDto getOverviewDetails();
}
