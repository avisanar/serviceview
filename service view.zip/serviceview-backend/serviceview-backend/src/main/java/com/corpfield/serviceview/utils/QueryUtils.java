package com.corpfield.serviceview.utils;

import java.util.Calendar;
import java.util.Date;

public class QueryUtils {
    public static String addSortArgs(String sql, String sortField, String sortMethod) {
        sql = sql + " ORDER BY " + sortField + " " + sortMethod;
        return sql;
    }

    public static String convertObjToString(Object obj) {
        if (null == obj || String.valueOf(obj).equals("")) {
            return null;
        }
        return String.valueOf(obj);
    }

    public static String setSearchKey(String param) {
        if (null == param || param.equals("")) {
            return "%%";
        }
        return "%" + param + "%";
    }

    public static boolean getActiveStatus(Object obj) {
        return Boolean.parseBoolean(convertObjToString(obj));
    }

    public static Long convertObjToLong(Object obj) {
        if (null == obj) {
            return 0L;
        }
        return Long.parseLong(String.valueOf(obj));
    }

    public static Integer convertObjToInteger(Object obj) {
        if (null == obj) {
            return 0;
        }
        return Integer.parseInt(String.valueOf(obj));
    }

    public static String addStatusArgs(String sql, String tableName, String fieldName, String status) {
        if (status == null || status.isEmpty())
            return sql;
        return String.format("%s and %s.%s = %s ", sql, tableName, fieldName, status);
    }

    public static Double convertObjToDouble(Object obj) {
        if (null == obj) {
            return 0.00;
        }
        return (Double.parseDouble(String.valueOf(obj)));
    }

    public static String getActiveOrInactive(boolean status) {
        if (status) {
            return "Active";
        }
        return "Inactive";
    }

    public static String getString(String str) {
        if (str != null) {
            return str;
        }
        return "";
    }

    public static Date getStartOfTheDay(Date date){
        if(date == null){
            return new Date(0); // jan 1, 1970
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        return calendar.getTime();
    }

    public static Date getEndOfTheDay(Date date){
        Calendar calendar = Calendar.getInstance();
        if(date == null){
            date = new Date(); //set today as end date
        }
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        return calendar.getTime();
    }

    public static String addFilterArgs(String sql, String fieldName, String fieldValue) {
        if (fieldValue == null || fieldValue.isEmpty())
            return sql;
        return String.format("%s and %s = '%s' ", sql, fieldName, fieldValue);
    }

}
