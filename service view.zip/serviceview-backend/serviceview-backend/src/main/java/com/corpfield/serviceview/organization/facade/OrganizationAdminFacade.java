package com.corpfield.serviceview.organization.facade;

import com.corpfield.serviceview.common.exception.ServiceViewException;
import com.corpfield.serviceview.organization.enities.Organization;
import com.corpfield.serviceview.organization.enities.OrganizationAdmin;
import com.corpfield.serviceview.organization.repositories.OrganizationAdminsRepo;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;
import java.util.UUID;

@Component
public class OrganizationAdminFacade {
    @Autowired
    private OrganizationAdminsRepo organizationAdminsRepo;

    @SneakyThrows
    public OrganizationAdmin getOrThrowOrganizationAdminByEmail(String email) {
        Optional<OrganizationAdmin> optionalAdmin = organizationAdminsRepo.findByEmail(email);
        return optionalAdmin
                .orElseThrow(() -> new ServiceViewException("Invalid Credentials"));
    }


    public void checkOrganizationEmailAndMobileNumberAlreadyExistOrNot(String contactEmail, String contactNumber) throws ServiceViewException {
        Optional<OrganizationAdmin> optionalAdminByEmail = organizationAdminsRepo.findByEmail(contactEmail);
        if(optionalAdminByEmail.isPresent()){
            throw new ServiceViewException("Email Already Exist");
        }
        Optional<OrganizationAdmin> optionalAdminByContactNumber = organizationAdminsRepo.findByPhone(contactNumber);
        if(optionalAdminByContactNumber.isPresent()){
            throw new ServiceViewException("Contact Number Already Exist");
        }
    }

    public void checkPassword(String newPassword, String confirmPassword) throws ServiceViewException {
        if(!newPassword.equals(confirmPassword)){
            throw new ServiceViewException("Password Incorrect");
        }
    }

    public String checkOrganizationAdminUuidExistOrNot(String organizationAdminUuid) {
        Optional<OrganizationAdmin> organizationAdminOptional = this.organizationAdminsRepo.findByOrganizationAdminUuid(organizationAdminUuid);
        while (organizationAdminOptional.isPresent()){
            organizationAdminUuid = UUID.randomUUID().toString().replace("-","");
            checkOrganizationAdminUuidExistOrNot(organizationAdminUuid);
        }
        return organizationAdminUuid;
    }

    public void persistOrganizationAdmin(OrganizationAdmin organizationAdmin) {
        this.organizationAdminsRepo.save(organizationAdmin);
    }

    public OrganizationAdmin findByAdminUUid(String adminUUid) {
        Optional<OrganizationAdmin> organizationAdminOptional = this.organizationAdminsRepo.findByOrganizationAdminUuid(adminUUid);
        return organizationAdminOptional.get();
    }

    public Organization findOrganizationByAdminUuid(String adminUuid) {
        Optional<OrganizationAdmin> organizationAdmin = this.organizationAdminsRepo.findByOrganizationAdminUuid(adminUuid);
        return organizationAdmin.get().getOrganization();
    }
}
