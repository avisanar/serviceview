package com.corpfield.serviceview.settings.service;

import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.settings.dto.requestDto.DeliveryModeCreateReqDto;
import com.corpfield.serviceview.settings.dto.requestDto.EditDeliveryModeReqDto;

public interface OrganizationDeliveryModeService {

    ResponseDto addDeliveryType(DeliveryModeCreateReqDto reqDto);

    ResponseDto findDeliveryModeById(long deliveryModeId);

    ResponseDto editDeliveryModeStatus(EditDeliveryModeReqDto reqDto);

}
