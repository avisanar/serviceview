package com.corpfield.serviceview.order.dao;

import com.corpfield.serviceview.order.dto.pojo.OrderFilterDto;
import com.corpfield.serviceview.order.queries.OrderQueries;
import com.corpfield.serviceview.order.queries.ReportQueries;
import com.corpfield.serviceview.organization.enities.OrganizationAdmin;
import com.corpfield.serviceview.utils.QueryUtils;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

import static com.corpfield.serviceview.utils.QueryUtils.*;
@Component
public class ReportDao {

    @PersistenceContext
    EntityManager entityManager;

    public List<Object[]> findReportListSorted(OrderFilterDto filter, OrganizationAdmin admin) {
        String sql = ReportQueries.GET_REPORT_LIST;
        sql = addFilterArgs(sql, "o.delivery_status", filter.getStatus());
        sql = addSortArgs(sql, filter.getSortField(), filter.getSortMethod());
        Pageable pageable = filter.getPageable();
        Query query = entityManager.createNativeQuery(sql)
                .setParameter("organizationId", admin.getOrganization().getOrganizationId())
                .setParameter("searchKey", setSearchKey(filter.getSearchKey()))
                .setFirstResult(pageable.getPageNumber() * pageable.getPageSize())
                .setMaxResults(pageable.getPageSize());
        return query.getResultList();
    }

    public int getReportListCount(OrderFilterDto filter, OrganizationAdmin admin) {
        String sql = ReportQueries.GET_REPORT_LIST_COUNT;
        sql = addFilterArgs(sql, "o.delivery_status", filter.getStatus());
        Query query = entityManager.createNativeQuery(sql)
                .setParameter("organizationId", admin.getOrganization().getOrganizationId())
                .setParameter("searchKey", setSearchKey(filter.getSearchKey()));
        Object object = query.getSingleResult();
        return convertObjToInteger(object);
    }
}
