package com.corpfield.serviceview.settings.dto.requestDto;
import com.corpfield.serviceview.settings.entities.OrganizationUnit;
import lombok.Data;

@Data
public class CreateUnitReqDto {
    private String unitName;

    public OrganizationUnit convertObjToEntity() {
        OrganizationUnit organizationUnit = new OrganizationUnit();
        organizationUnit.setUnitName(unitName);
        organizationUnit.setActive(true);
        return organizationUnit;
    }
}
