package com.corpfield.serviceview.dashboard.service;

import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.common.exception.ServiceViewException;
import com.corpfield.serviceview.common.utils.AuthUtil;
import com.corpfield.serviceview.dashboard.dao.DashboardDao;
import com.corpfield.serviceview.dashboard.dto.OverviewResDto;
import com.corpfield.serviceview.dashboard.facade.DashboardFacade;
import com.corpfield.serviceview.organization.enities.Organization;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DashboardServiceImpl implements DashboardService {

    @Autowired
    DashboardFacade dashboardFacade;

    @Autowired
    DashboardDao dashboardDao;

    @Override
    public ResponseDto getOverviewDetails() {
        try{
            String adminUuid= AuthUtil.currentUserUUId();
            Organization organization=this.dashboardFacade.findOrganizationByAdminUuid(adminUuid);
            String todayDate=this.dashboardFacade.getTodayDate();
            List<Object[]> detailsObjects=this.dashboardDao.getOverviewDetails(organization.getOrganizationId(),todayDate);
            List<OverviewResDto> resDto=this.dashboardFacade.mapObjectsToDto(detailsObjects);
            return new ResponseDto(HttpStatus.OK,resDto);
        }catch (Exception e){
            return ServiceViewException.sendErrorResponse(e);
        }
    }
}
