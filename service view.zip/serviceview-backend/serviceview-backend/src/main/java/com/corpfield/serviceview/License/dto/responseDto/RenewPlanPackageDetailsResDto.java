package com.corpfield.serviceview.License.dto.responseDto;

import lombok.Data;

@Data
public class RenewPlanPackageDetailsResDto {
    private String accountType;
    private double renewAmount;
    private long currentLicense;
    private double totalCost;
}
