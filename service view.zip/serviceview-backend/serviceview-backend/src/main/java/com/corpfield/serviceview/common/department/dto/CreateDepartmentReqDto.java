package com.corpfield.serviceview.common.department.dto;

import com.corpfield.serviceview.common.department.entities.OrganizationDepartment;
import lombok.Data;

@Data
public class CreateDepartmentReqDto {
    private String departmentName;

    public OrganizationDepartment convertDtoToEntity() {
        OrganizationDepartment department = new OrganizationDepartment();
        department.setDepartmentName(departmentName);
        department.setActive(true);
        return department;
    }

}
