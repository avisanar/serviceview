package com.corpfield.serviceview.settings.service;

import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.common.exception.ServiceViewException;
import com.corpfield.serviceview.settings.dto.requestDto.CreateUnitReqDto;
import com.corpfield.serviceview.settings.dto.requestDto.EditOrganizationUnitReqDto;
import com.corpfield.serviceview.settings.dto.responseDto.OrganizationUnitResDto;
import com.corpfield.serviceview.settings.entities.OrganizationUnit;
import com.corpfield.serviceview.settings.facade.OrganizationUnitFacade;
import com.corpfield.serviceview.settings.repositories.OrganizationUnitRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
public class OrganizationUnitServiceImpl implements OrganizationUnitService{

    @Autowired
    OrganizationUnitFacade organizationUnitFacade;

    @Autowired
    OrganizationUnitRepo organizationUnitRepo;

    @Override
    public ResponseDto createUnit(CreateUnitReqDto dto) {
        try {
            organizationUnitFacade.checkUnitAlreadyExist(dto.getUnitName());
            OrganizationUnit organizationUnit = dto.convertObjToEntity();
            organizationUnitFacade.setOrganization(organizationUnit);
            organizationUnitRepo.save(organizationUnit);
            return new ResponseDto(HttpStatus.OK, "Unit added successfully");
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto editUnit(EditOrganizationUnitReqDto dto) {
        try {
            OrganizationUnit organizationUnit = organizationUnitFacade.findOrganizationUnitById(dto.getOrganizationUnitId());
            organizationUnitFacade.checkUnitAlreadyExistForEdit(dto);
            dto.editUnit(organizationUnit);
            organizationUnitRepo.save(organizationUnit);
            return new ResponseDto(HttpStatus.OK, "Unit updated successfully");
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto findOrganizationUnitById(long organizationUnitId){
        try{
            OrganizationUnit organizationUnit = organizationUnitFacade.findOrganizationUnitById(organizationUnitId);
            OrganizationUnitResDto resDto = OrganizationUnitResDto.convertObjToDto(organizationUnit);
            return new ResponseDto(HttpStatus.OK,"OK",resDto);
        }catch (Exception e){
            return ServiceViewException.sendErrorResponse(e);
        }
    }
}