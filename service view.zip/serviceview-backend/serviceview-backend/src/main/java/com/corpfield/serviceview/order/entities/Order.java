package com.corpfield.serviceview.order.entities;


import com.corpfield.serviceview.common.enities.AuditEntity;
import com.corpfield.serviceview.customer.entities.Customer;
import com.corpfield.serviceview.organization.enities.Organization;
import com.corpfield.serviceview.settings.entities.OrganizationDeliveryMode;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Date;

@EqualsAndHashCode(callSuper = true)
@Data
@Entity
@Table(name = "orders")
public class Order extends AuditEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "order_id")
    private long orderId;

    @Column(name = "order_uuid", unique = true, nullable = false)
    private String orderUuid;

    @ManyToOne
    @JoinColumn(name = "customer_id")
    @NotNull
    private Customer customer;

    @Column(name = "ordered_on")
    private Date orderedOn;

    @Column(name = "delivery_on")
    private Date deliveryOn;

    @Column(name = "delivery_status")
    private String deliveryStatus;

    @Column(name = "delivery_person")
    private String deliveryPerson;

    @ManyToOne
    @JoinColumn(name = "organization_id")
    @NotNull
    private Organization organization;

    @ManyToOne
    @JoinColumn(name = "organization_delivery_mode_id")
    @NotNull
    private OrganizationDeliveryMode organizationDeliveryMode;

}
