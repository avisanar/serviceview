package com.corpfield.serviceview.product.dao;

import com.corpfield.serviceview.employee.queries.EmployeeQueries;
import com.corpfield.serviceview.product.dto.pojo.ProductListFilter;
import com.corpfield.serviceview.product.queries.ProductQueries;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

import static com.corpfield.serviceview.utils.QueryUtils.*;


@Component
public class ProductDao {

    @PersistenceContext
    EntityManager entityManager;

    public List<Object[]> findAllProducts(ProductListFilter filter, long organizationId) {
        String sql = ProductQueries.GET_PRODUCTS_LIST;
        sql = addFilterArgs(sql, "p.active", filter.getStatus());
        Pageable pageable = filter.getPageable();
        Query query = entityManager.createNativeQuery(sql)
                .setParameter("searchKey", setSearchKey(filter.getSearchKey()))
                .setParameter("organizationId", organizationId)
                .setFirstResult(pageable.getPageNumber() * pageable.getPageSize())
                .setMaxResults(pageable.getPageSize());
        return query.getResultList();
    }

    public int findAllProductsCount(ProductListFilter filter, long organizationId) {
        String sql = ProductQueries.GET_PRODUCTS_LIST_COUNT;
        sql = addFilterArgs(sql, "p.active", filter.getStatus());
        Query query = entityManager.createNativeQuery(sql)
                .setParameter("searchKey", setSearchKey(filter.getSearchKey()))
                .setParameter("organizationId",organizationId);
        Object object = query.getSingleResult();
        return convertObjToInteger(object);
    }
}
