package com.corpfield.serviceview.License.dto.responseDto;

import lombok.Data;

import static com.corpfield.serviceview.utils.QueryUtils.*;

@Data
public class UserListResDto {
    private long userId;
    private String userName;
    private String contactNumber;
    private String department;
    private boolean active;

    public static UserListResDto convertObjToDto(Object[] objects) {
        UserListResDto userListResDto=new UserListResDto();
        userListResDto.setUserId(convertObjToLong(objects[0]));
        userListResDto.setUserName(convertObjToString(objects[1]));
        userListResDto.setContactNumber(convertObjToString(objects[2]));
        userListResDto.setDepartment(convertObjToString(objects[3]));
        userListResDto.setActive(getActiveStatus(objects[4]));
        return userListResDto;
    }
}
