package com.corpfield.serviceview.order.service;

import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.order.dto.requestDto.EditOrderProductReqDto;

public interface OrderProductService {

    ResponseDto editOrderProduct(EditOrderProductReqDto reqDto);

    ResponseDto removeOrderProduct(long orderProductId);

}
