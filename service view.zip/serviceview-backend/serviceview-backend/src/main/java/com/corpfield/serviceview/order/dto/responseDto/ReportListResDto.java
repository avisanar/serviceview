package com.corpfield.serviceview.order.dto.responseDto;

import com.corpfield.serviceview.utils.DateUtil;
import lombok.Data;

import java.time.format.DateTimeFormatter;
import java.util.Date;

import static com.corpfield.serviceview.utils.QueryUtils.*;
@Data
public class ReportListResDto {
    private long customerId;
    private String customerName;
    private long orderId;
    private String orderDate;
    private String deliveredDate;
    private String status;

    public static ReportListResDto convertObjToDto(Object[] objects) {
        ReportListResDto dto = new ReportListResDto();
        dto.setCustomerId(convertObjToLong(objects[0]));
        dto.setCustomerName(convertObjToString(objects[1]));
        dto.setOrderId(convertObjToLong(objects[2]));
        dto.setOrderDate(convertObjToString(objects[3]));
        dto.setDeliveredDate(convertObjToString(objects[4]));
        dto.setStatus(convertObjToString(objects[5]));
       return dto;
    }
}
