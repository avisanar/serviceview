package com.corpfield.serviceview.License.controllers;

import com.corpfield.serviceview.License.dto.requestDto.*;
import com.corpfield.serviceview.License.pojo.LicensePlanFilter;
import com.corpfield.serviceview.License.service.LicenseService;
import com.corpfield.serviceview.common.constants.CommonConstants;
import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.common.utils.ResponseUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class LicenseController {

    @Autowired
    LicenseService licenseService;



    @GetMapping("/admin/packageDetails")
    public ResponseEntity<ResponseDto> getPackageDetails(
            @RequestParam(value = "planId") long planId,
            @RequestParam(value="numberOfLicense")long numberOfLicense){
        LicensePlanFilter filter=LicensePlanFilter.builder()
                .planId(planId)
                .numberOfLicense(numberOfLicense)
                .build();
        ResponseDto response=licenseService.getPackageDetails(filter);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatusCode()));
    }

    @GetMapping("/admin/PackageSummary")
    public ResponseEntity<ResponseDto> getPackageSummary(
            @RequestParam(value = "planId") long planId,
            @RequestParam(value="numberOfLicense")long numberOfLicense){
        LicensePlanFilter filter=LicensePlanFilter.builder()
                .planId(planId)
                .numberOfLicense(numberOfLicense)
                .build();
        ResponseDto response=licenseService.getPackageSummary(filter);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatusCode()));
    }

    @GetMapping("/admin/renew-planDetails")
    public ResponseEntity<ResponseDto> getPlanDetails(
            @RequestParam(value = "licenseUuid") String licenseUuid
    ){
        ResponseDto response=licenseService.getRenewPlanDetails(licenseUuid);
        return ResponseUtil.generateResponse(response);
    }

    @PostMapping("/admin/createLicensePlan-pay")
    public ResponseEntity<ResponseDto> createLicensePlan(@RequestBody LicensePlanReqDto reqDto){
        ResponseDto response=licenseService.createLicensePlan(reqDto);
        return ResponseUtil.generateResponse(response);
    }

    @PutMapping("/admin/changeLicensePlan-pay")
    public ResponseEntity<ResponseDto> changeLicensePlan(@RequestBody LicensePlanReqDto reqDto){
        ResponseDto response=licenseService.changeLicensePlan(reqDto);
        return ResponseUtil.generateResponse(response);
    }

    @PutMapping("/admin/renewLicensePlan-pay")
    public ResponseEntity<ResponseDto> renewLicensePlan(@RequestBody LicensePlanReqDto reqDto){
        ResponseDto response=licenseService.renewLicensePlan(reqDto);
        return ResponseUtil.generateResponse(response);
    }

    @GetMapping("/admin/getUsers")
    public ResponseEntity<ResponseDto> getUsers(@PageableDefault(size = CommonConstants.DEFAULT_PAGE_SIZE) Pageable pageable) {
        ResponseDto response = licenseService.getUsers(pageable);
        return ResponseUtil.generateResponse(response);
    }

    @PutMapping("/admin/assignLicense")
    public ResponseEntity<ResponseDto> assignLicense(@RequestBody List<AssignLicenseReqDto> dto){
        ResponseDto response=licenseService.assignLicense(dto);
        return ResponseUtil.generateResponse(response);
    }

    @GetMapping("/admin/buyMoreLicense")
    public ResponseEntity<ResponseDto> getExistingLicenseDetails(
            @RequestParam(value="addLicense")long addLicense ){
        ResponseDto response=licenseService.getExistingLicenseDetails(addLicense);
        return ResponseUtil.generateResponse(response);
    }

    @PutMapping("/admin/buyMoreLicense-pay")
    public ResponseEntity<ResponseDto> addMoreLicense(@RequestBody BuyMoreLicenseReqDto reqDto){
        ResponseDto response=licenseService.addMoreLicense(reqDto);
        return ResponseUtil.generateResponse(response);
    }
}
