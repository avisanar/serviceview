package com.corpfield.serviceview.customer.facade;

import com.corpfield.serviceview.common.exception.ServiceViewException;
import com.corpfield.serviceview.customer.dao.CustomerDao;
import com.corpfield.serviceview.customer.dto.reqDto.CreateCustomerReqDto;
import com.corpfield.serviceview.customer.dto.reqDto.CustomerFilterReqDto;
import com.corpfield.serviceview.customer.dto.resDto.CustomerListResDto;
import com.corpfield.serviceview.customer.entities.Customer;
import com.corpfield.serviceview.customer.entities.OrganizationCustomer;
import com.corpfield.serviceview.customer.repositories.CustomerRepo;
import com.corpfield.serviceview.customer.repositories.OrganizationCustomerRepo;
import com.corpfield.serviceview.employee.entities.Employee;
import com.corpfield.serviceview.employee.entities.OrganizationEmployee;
import com.corpfield.serviceview.organization.enities.OrganizationAdmin;
import com.corpfield.serviceview.organization.repositories.OrganizationAdminsRepo;
import com.corpfield.serviceview.utils.AuthUtil;
import org.hibernate.service.spi.ServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Component
public class CustomerServiceFacade {

    @Autowired
    CustomerDao customerDao;

    @Autowired
    CustomerRepo customerRepo;

    @Autowired
    OrganizationCustomerRepo organizationCustomerRepo;

    @Autowired
    OrganizationAdminsRepo organizationAdminsRepo;

    public Page<CustomerListResDto> customerList(CustomerFilterReqDto filter, Pageable pageable,OrganizationAdmin admin) {
        List<Object[]> customerList = customerDao.listOfCustomer(filter, pageable,admin);
        List<CustomerListResDto> list = customerList
                .stream()
                .map(CustomerListResDto::mapListToDto)
                .collect(Collectors.toList());
        int totalCustomer = customerDao.totalCustomer(filter,admin);
        Page<CustomerListResDto> pagedCustomer = new PageImpl<>(list, pageable, totalCustomer);
        return pagedCustomer;
    }

    public void addCustomer(CreateCustomerReqDto reqDto) {
        Optional<Customer> optionalCustomer = customerRepo.findByCustomerPhoneNumber(reqDto.getCustomerPhoneNumber());
        if (optionalCustomer.isPresent()) {
            this.setOrganizationCustomer(optionalCustomer);
        } else {
            String customerUuid = UUID.randomUUID().toString().replace("-","");
            customerUuid = this.checkCustomerUuidExistOrNot(customerUuid);
            Customer customer = reqDto.convertObjToDto(customerUuid);
            this.customerRepo.save(customer);
            this.setCustomerAndOrganizationCustomer(customer);
        }
    }

    private void setCustomerAndOrganizationCustomer(Customer customer) {
        OrganizationCustomer organizationCustomer = new OrganizationCustomer();
        organizationCustomer.setCustomer(customer);
        organizationCustomer.setActive(true);
        this.setOrganization(organizationCustomer);
        String organizationCustomerUuid = UUID.randomUUID().toString().replace("-","");
        organizationCustomerUuid = this.checkOrganizationCustomerUuidExistOrNot(organizationCustomerUuid);
        organizationCustomer.setOrganizationCustomerUuid(organizationCustomerUuid);
        organizationCustomerRepo.save(organizationCustomer);
    }

    private void setOrganizationCustomer(Optional<Customer> optionalCustomer) {
        OrganizationCustomer organizationCustomer = new OrganizationCustomer();
        organizationCustomer.setCustomer(optionalCustomer.get());
        organizationCustomer.setActive(true);
        this.setOrganization(organizationCustomer);
        String organizationCustomerUuid = UUID.randomUUID().toString().replace("-","");
        organizationCustomerUuid = this.checkOrganizationCustomerUuidExistOrNot(organizationCustomerUuid);
        organizationCustomer.setOrganizationCustomerUuid(organizationCustomerUuid);
        organizationCustomerRepo.save(organizationCustomer);
    }

    private String checkCustomerUuidExistOrNot(String customerUuid) {
        Optional<Customer>customerOptional=this.customerRepo.findByCustomerUuid(customerUuid);
        while (customerOptional.isPresent()){
            customerUuid=UUID.randomUUID().toString().replace("-","");
            checkCustomerUuidExistOrNot(customerUuid);
        }
        return customerUuid;
    }

    private String checkOrganizationCustomerUuidExistOrNot(String organizationCustomerUuid) {
        Optional<OrganizationCustomer> organizationCustomerOptional = this.organizationCustomerRepo.findByOrganizationCustomerUuid(organizationCustomerUuid);
        while (organizationCustomerOptional.isPresent()) {
            organizationCustomerUuid = UUID.randomUUID().toString().replace("-", "");
            checkOrganizationCustomerUuidExistOrNot(organizationCustomerUuid);
        }
        return organizationCustomerUuid;
    }

    private void setOrganization(OrganizationCustomer organizationCustomer) {
        String organizationAdminUuid = AuthUtil.currentUserId();
        Optional<OrganizationAdmin>organizationAdminOptional=this.organizationAdminsRepo.findByOrganizationAdminUuid(organizationAdminUuid);
        organizationAdminOptional.orElseThrow(()->new ServiceException("Organization not found"));
        if(organizationAdminOptional.isPresent())
            organizationCustomer.setOrganization(organizationAdminOptional.get().getOrganization());
    }

    public Customer findCustomerByCustomerId(long customerId) {
        Optional<Customer> optionalCustomer = customerRepo.findById(customerId);
        return optionalCustomer.orElseThrow(() -> new ServiceException("Cannot find Customer"));
    }

    public OrganizationCustomer findCustomerInOrganizationCustomer(long customerId) throws Exception {
        Optional<OrganizationCustomer> optionalOrganizationCustomer = organizationCustomerRepo.findByCustomerCustomerId(customerId);
        return optionalOrganizationCustomer.orElseThrow(() -> new ServiceViewException("Cannot find Organization customer"));
    }

    public OrganizationAdmin findAuthOrganization(String organizationAdminUuid) {
        Optional<OrganizationAdmin> optOrganizationAdmin = this.organizationAdminsRepo.findByOrganizationAdminUuid(organizationAdminUuid);
        return optOrganizationAdmin.orElseThrow(() -> new ServiceException("Organization Admin not found"));
    }

    public void checkIfCustomerAlreadyPresentInOrganization(CreateCustomerReqDto reqDto) throws ServiceViewException {
        String organizationAdminUuid = AuthUtil.currentUserId();
        Optional<OrganizationAdmin> optOrganizationAdmin = this.organizationAdminsRepo.findByOrganizationAdminUuid(organizationAdminUuid);
        Optional<Customer> optionalCustomer = customerRepo.findByCustomerPhoneNumber(reqDto.getCustomerPhoneNumber());
        if (optionalCustomer.isPresent()) {
            long customerId = optionalCustomer.get().getCustomerId();
            long organizationId = optOrganizationAdmin.get().getOrganization().getOrganizationId();
            Optional<OrganizationCustomer> optionalOrganizationCustomer = organizationCustomerRepo.findByCustomerCustomerIdAndOrganizationOrganizationId(customerId, organizationId);
            if(optionalOrganizationCustomer.isPresent()){
                throw new ServiceViewException("Customer Already Presented");
            }
        }
    }
}