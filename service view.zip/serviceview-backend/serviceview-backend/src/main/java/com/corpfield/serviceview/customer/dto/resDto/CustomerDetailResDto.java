package com.corpfield.serviceview.customer.dto.resDto;

import com.corpfield.serviceview.customer.entities.Customer;
import lombok.Data;

@Data
public class CustomerDetailResDto {
    private String customerName;
    private String customerEmail;
    private String customerLocation;

    public static CustomerDetailResDto convertObjToDto(Customer customer) {
        CustomerDetailResDto dto = new CustomerDetailResDto();
        dto.setCustomerName(customer.getCustomerName());
        dto.setCustomerEmail(customer.getCustomerEmail());
        dto.setCustomerLocation(customer.getCustomerLocation());
        return dto;
    }
}
