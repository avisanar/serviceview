package com.corpfield.serviceview.order.facade;

import com.corpfield.serviceview.order.dao.ReportDao;
import com.corpfield.serviceview.order.dto.pojo.OrderFilterDto;
import com.corpfield.serviceview.order.dto.responseDto.ReportListResDto;
import com.corpfield.serviceview.organization.enities.OrganizationAdmin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class ReportFacade {

    @Autowired
    ReportDao reportDao;

    public List<ReportListResDto> getReportListSorted(OrderFilterDto filter, OrganizationAdmin admin) {
        List<Object[]> objects = reportDao.findReportListSorted(filter, admin);
        List<ReportListResDto> reportListResDto = objects.stream()
                .map(ReportListResDto::convertObjToDto)
                .collect(Collectors.toList());
        return reportListResDto;
    }
}
