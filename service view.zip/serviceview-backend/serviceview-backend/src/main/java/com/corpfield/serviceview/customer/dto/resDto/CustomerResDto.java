package com.corpfield.serviceview.customer.dto.resDto;

import com.corpfield.serviceview.customer.entities.Customer;
import lombok.Data;

@Data
public class CustomerResDto {
    private long customerId;
    private String customerName;
    private String customerPhoneNumber;
    private String customerEmail;
    private String customerLocation;
    private boolean status;

    public CustomerResDto(Customer customer){
        this.setCustomerId(customer.getCustomerId());
        this.setCustomerName(customer.getCustomerName());
        this.setCustomerPhoneNumber(customer.getCustomerPhoneNumber());
        this.setCustomerEmail(customer.getCustomerEmail());
        this.setCustomerLocation(customer.getCustomerLocation());
        this.setStatus(customer.isActive());
    }
}
