package com.corpfield.serviceview.order.entities;

import com.corpfield.serviceview.common.enities.AuditEntity;
import com.corpfield.serviceview.product.entities.Product;
import lombok.Data;
import lombok.EqualsAndHashCode;


import javax.persistence.*;
import javax.validation.constraints.NotNull;


@EqualsAndHashCode(callSuper = true)
@Data
@Entity
@Table(name = "order_products")
public class OrderProduct extends AuditEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "order_product_id")
    private long orderProductId;

    @Column(name = "quantity")
    @NotNull
    private int quantity;

    @Column(name = "product_total_price")
    @NotNull
    private double productTotalPrice;

    @ManyToOne(cascade = {CascadeType.ALL})
    @JoinColumn(name = "order_id")
    @NotNull
    private Order order;

    @ManyToOne(cascade = {CascadeType.ALL})
    @JoinColumn(name = "product_id")
    @NotNull
    private Product product;

}
