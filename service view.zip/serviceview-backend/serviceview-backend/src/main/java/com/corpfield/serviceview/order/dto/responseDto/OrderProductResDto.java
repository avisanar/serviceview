package com.corpfield.serviceview.order.dto.responseDto;

import com.corpfield.serviceview.order.entities.OrderProduct;
import com.corpfield.serviceview.product.entities.Product;
import lombok.Data;

@Data
public class OrderProductResDto {
    private long productId;
    private String productImageUrl;
    private String productName;
    private int quantity;
    private double productTotalPrice;
    private double totalPrice;


    public static OrderProductResDto convertEntityToDto(OrderProduct product) {
        OrderProductResDto dto = new OrderProductResDto();
        dto.setProductId(product.getProduct().getProductId());
        dto.setProductImageUrl(product.getProduct().getProductImageUrl());
        dto.setProductName(product.getProduct().getProductName());
        dto.setQuantity(product.getQuantity());
        dto.setProductTotalPrice(product.getProductTotalPrice());
        dto.setTotalPrice(product.getQuantity() * product.getProductTotalPrice());
        return dto;
    }

}
