package com.corpfield.serviceview.License.dto.requestDto;

import lombok.Data;

@Data
public class LicensePlanReqDto {
    private long planId;
    private long numberOfLicense;
    private String accountType;
}
