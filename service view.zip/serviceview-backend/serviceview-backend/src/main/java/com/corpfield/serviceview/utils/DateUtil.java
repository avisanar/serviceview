package com.corpfield.serviceview.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class DateUtil {

    public static String getDate(Object obj){
        DateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy");
        String date=dateFormat.format(obj);
        return date;
    }

}
