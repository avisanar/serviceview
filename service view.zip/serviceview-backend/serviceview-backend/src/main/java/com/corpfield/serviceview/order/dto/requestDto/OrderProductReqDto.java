package com.corpfield.serviceview.order.dto.requestDto;

import lombok.Data;

@Data
public class OrderProductReqDto {
    private long productId;
    private int quantity;

}
