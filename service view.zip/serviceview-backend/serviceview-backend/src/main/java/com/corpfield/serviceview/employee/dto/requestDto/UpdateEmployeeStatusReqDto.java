package com.corpfield.serviceview.employee.dto.requestDto;

import com.corpfield.serviceview.employee.entities.OrganizationEmployee;
import lombok.Data;

@Data
public class UpdateEmployeeStatusReqDto {
    private long employeeId;
    private Boolean active;

    public void updateOrganizationEmployeeEntity(OrganizationEmployee employee) {
        if (active != null) {
            employee.setActive(active);
        }
    }

}
