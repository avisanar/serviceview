package com.corpfield.serviceview.License.dto.responseDto;

import lombok.Data;


@Data
public class LicensePackageDetailsResDto {
    private String planSelected;
    private double CostPerLicense;
    private double totalCost;
}
