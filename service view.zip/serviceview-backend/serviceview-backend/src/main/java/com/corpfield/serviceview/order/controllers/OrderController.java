package com.corpfield.serviceview.order.controllers;

import com.corpfield.serviceview.common.constants.RoleConstants;
import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.order.dto.pojo.OrderFilterDto;
import com.corpfield.serviceview.order.dto.requestDto.CreateOrderReqDto;
import com.corpfield.serviceview.order.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class OrderController {

    @Autowired
    OrderService orderService;

    @PostMapping("/admin/order")
    public ResponseEntity<ResponseDto> createOrder(@RequestBody CreateOrderReqDto reqDto) {
        ResponseDto dto = orderService.createOrder(reqDto);
        return new ResponseEntity<>(dto, HttpStatus.valueOf(dto.getStatusCode()));
    }

    @GetMapping("/admin/order")
    public ResponseEntity<ResponseDto> getOrderList(
            @PageableDefault(size = RoleConstants.DEFAULT_PAGE_SIZE) Pageable pageable,
            @RequestParam(value = "sortField", defaultValue = "o.order_id") String sortField,
            @RequestParam(value = "sortMethod", defaultValue = "DESC") String sortMethod,
            @RequestParam(value = "searchKey", required = false) String searchKey,
            @RequestParam(value = "status", required = false) String status

    ) {
        OrderFilterDto filter = OrderFilterDto.builder()
                .sortField(sortField)
                .sortMethod(sortMethod)
                .pageable(pageable)
                .searchKey(searchKey)
                .status(status)
                .build();
        ResponseDto dto = orderService.findOrderList(filter);
        return new ResponseEntity<>(dto, HttpStatus.valueOf(dto.getStatusCode()));
    }

    @GetMapping("/admin/order/viewOrder/{orderId}")
    public ResponseEntity<ResponseDto> viewOrderDetails(
            @PathVariable("orderId") long orderId
    ) {
        ResponseDto dto = orderService.viewOrderDetailsByOrderId(orderId);
        return new ResponseEntity<>(dto, HttpStatus.valueOf(dto.getStatusCode()));
    }

    @GetMapping("/admin/order/delivered/{orderId}")
    public ResponseEntity<ResponseDto> deliveredDetail(
            @PathVariable("orderId") long orderId
    ) {
        ResponseDto dto = orderService.findDeliveredDetail(orderId);
        return new ResponseEntity<>(dto, HttpStatus.valueOf(dto.getStatusCode()));
    }

}
