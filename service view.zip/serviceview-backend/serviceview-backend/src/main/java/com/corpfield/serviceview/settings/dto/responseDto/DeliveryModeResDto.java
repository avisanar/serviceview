package com.corpfield.serviceview.settings.dto.responseDto;

import com.corpfield.serviceview.settings.entities.OrganizationDeliveryMode;
import lombok.Data;

@Data
public class DeliveryModeResDto {

    private String deliveryType;
    private boolean active;

    public static DeliveryModeResDto convertEntityToDto(OrganizationDeliveryMode deliveryMode) {
        DeliveryModeResDto dto = new DeliveryModeResDto();
        dto.setDeliveryType(deliveryMode.getDeliveryType());
        dto.setActive(deliveryMode.isActive());
        return dto;
    }

}
