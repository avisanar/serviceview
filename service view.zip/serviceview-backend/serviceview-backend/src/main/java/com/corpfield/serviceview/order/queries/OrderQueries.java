package com.corpfield.serviceview.order.queries;

public class OrderQueries {

    public static final String GET_ORDER_LIST_SORTED = "SELECT " +
            "o.order_id, " +
            "c.customer_name, " +
            "o.ordered_on, " +
            "o.delivery_status " +
            "FROM orders o " +
            "INNER JOIN customers c on c.customer_id = o.customer_id " +
            "WHERE " +
            "o.organization_id =:organizationId and " +
            "(c.customer_name like :searchKey or o.order_id like :searchKey or " +
            "c.customer_phone_number like :searchKey) " +
            "and o.created_at between :fromDate and :toDate ";

    public static final String GET_ORDER_LIST_COUNT = "SELECT " +
            "count(*) " +
            "FROM orders o " +
            "INNER JOIN customers c on c.customer_id = o.customer_id " +
            "WHERE " +
            "o.organization_id =:organizationId and " +
            "(c.customer_name like :searchKey or o.order_id like :searchKey or " +
            "c.customer_phone_number like :searchKey) " +
            "and o.created_at between :fromDate and :toDate ";

}
