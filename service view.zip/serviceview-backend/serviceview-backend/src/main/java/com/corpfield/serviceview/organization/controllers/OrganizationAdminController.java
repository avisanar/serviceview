package com.corpfield.serviceview.organization.controllers;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class OrganizationAdminController {
}
