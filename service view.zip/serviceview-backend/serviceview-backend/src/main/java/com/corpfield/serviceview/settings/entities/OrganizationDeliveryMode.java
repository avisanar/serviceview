package com.corpfield.serviceview.settings.entities;

import com.corpfield.serviceview.common.enities.AuditEntity;
import com.corpfield.serviceview.organization.enities.Organization;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Data
@Entity
@Table(name = "organization_delivery_mode")
public class OrganizationDeliveryMode extends AuditEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "organization_delivery_mode_id")
    private long organizationDeliveryModeId;

    @Column(name = "active")
    private boolean active;

    @Column(name = "delivery_mode")
    @NotNull
    private String deliveryType;

    @ManyToOne
    @JoinColumn(name = "organization_id")
    @NotNull
    private Organization organization;

}
