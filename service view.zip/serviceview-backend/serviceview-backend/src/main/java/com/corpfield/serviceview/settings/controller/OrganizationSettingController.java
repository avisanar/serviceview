package com.corpfield.serviceview.settings.controller;

import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.settings.dto.pojo.SettingFilterReqDto;
import com.corpfield.serviceview.settings.dto.requestDto.UpdateReferenceIdReqDto;
import com.corpfield.serviceview.settings.service.OrganizationSettingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

@RestController
public class OrganizationSettingController {

    @Autowired
    OrganizationSettingService organizationSettingService;

    @PostMapping("/admin/addSetting")
    public ResponseEntity<ResponseDto> createSetting() {
        ResponseDto response = organizationSettingService.createSetting();
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatusCode()));
    }

    @PutMapping("/admin/termsAndCondition/{organizationSettingsId}")
    public ResponseEntity<ResponseDto> updateTermsAndConditions(
            @PathVariable("organizationSettingsId") long organizationSettingsId,
            @RequestBody String termsAndConditions
    ) {
        ResponseDto response = organizationSettingService.updateTermsAndConditions(organizationSettingsId, termsAndConditions);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatusCode()));
    }

    @PutMapping("/admin/referenceId")
    public ResponseEntity<ResponseDto> updateReferenceNumber(@RequestBody UpdateReferenceIdReqDto reqDto){
        ResponseDto response = organizationSettingService.updateReferenceNumber(reqDto);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatusCode()));
    }

    @GetMapping("/admin/settings/{organizationSettingsId}")
    public ResponseEntity<ResponseDto> findOrganizationSettingsById(@PathVariable("organizationSettingsId") long organizationSettingsId) {
        ResponseDto response = organizationSettingService.findOrganizationSettingsById(organizationSettingsId);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatusCode()));
    }

    @GetMapping("/admin/settings")
    public ResponseEntity<ResponseDto> getAllSettings(
            @RequestParam(name = "fromDate", required = false) Date fromDate,
            @RequestParam(name = "toDate", required = false) Date toDate
    ) {
        SettingFilterReqDto filter = SettingFilterReqDto.builder()
                .fromDate(fromDate)
                .toDate(toDate)
                .build();
        ResponseDto response = organizationSettingService.getAllSettingsList(filter);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatusCode()));
    }
}
