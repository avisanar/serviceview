package com.corpfield.serviceview.order.service;

import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.order.dto.pojo.OrderFilterDto;

public interface ReportService {

    ResponseDto getReportList(OrderFilterDto filter);
}
