package com.corpfield.serviceview.License.repositories;

import com.corpfield.serviceview.License.entities.Plan;
import com.corpfield.serviceview.organization.enities.OrganizationAdmin;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PlanRepo extends JpaRepository<Plan, Long> {

}
