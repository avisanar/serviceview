package com.corpfield.serviceview.organization.dto.responseDto;

import lombok.Data;

@Data
public class CheckDomainAvailableResDto {
    private Boolean isAvailable;
}
