package com.corpfield.serviceview.settings.dto.responseDto;

import com.corpfield.serviceview.settings.entities.OrganizationUnit;
import lombok.Data;

import java.util.Date;

@Data
public class OrganizationUnitListResDto {
    private long unitId;
    private String unitName;
    private Date CreatedOn;
    private Boolean status;

    public static OrganizationUnitListResDto convertObjToDto(OrganizationUnit organizationUnit) {
        OrganizationUnitListResDto dto = new OrganizationUnitListResDto();
        dto.setUnitId(organizationUnit.getOrganizationUnitId());
        dto.setUnitName(organizationUnit.getUnitName());
        dto.setCreatedOn(organizationUnit.getCreatedAt());
        dto.setStatus(organizationUnit.isActive());
        return dto;
    }
}
