package com.corpfield.serviceview.customer.controllers;

import com.corpfield.serviceview.common.constants.RoleConstants;
import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.customer.dto.reqDto.CreateCustomerReqDto;
import com.corpfield.serviceview.customer.dto.reqDto.CustomerFilterReqDto;
import com.corpfield.serviceview.customer.dto.reqDto.EditCustomerReqDto;
import com.corpfield.serviceview.customer.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class CustomerController {

    @Autowired
    CustomerService customerService;

    @PostMapping("/admin/customer")
    public ResponseEntity<ResponseDto> createCustomer(@RequestBody CreateCustomerReqDto reqDto) {
        ResponseDto response = this.customerService.createCustomer(reqDto);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatusCode()));
    }

    @GetMapping("/admin/customer-exist")
    public ResponseEntity<ResponseDto> findCustomerByNumber(
            @RequestParam(value = "customerPhoneNumber") String customerPhoneNumber
    ) {
        ResponseDto response = this.customerService.findCustomerByNumber(customerPhoneNumber);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatusCode()));
    }

    @GetMapping("/admin/customer-list")
    public ResponseEntity<ResponseDto> customerList(
            @PageableDefault(size = RoleConstants.DEFAULT_PAGE_SIZE) Pageable pageable,
            @RequestParam(name = "searchKey", required = false) String searchKey,
            @RequestParam(name = "status", required = false) String status,
            @RequestParam(name = "sortMethod", defaultValue = "DESC") String sortMethod,
            @RequestParam(name = "sortField", defaultValue = "c.customer_id") String sortField
    ) {
        CustomerFilterReqDto filter = CustomerFilterReqDto.builder()
                .searchKey(searchKey)
                .status(status)
                .sortField(sortField)
                .sortMethod(sortMethod)
                .build();
        ResponseDto response = this.customerService.customerList(filter, pageable);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatusCode()));
    }

    @GetMapping("/admin/customer/{customerId}")
    public ResponseEntity<ResponseDto> findCustomerById(@PathVariable("customerId") long customerId) {
        ResponseDto response = this.customerService.getCustomerById(customerId);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatusCode()));
    }

    @PutMapping("/admin/customer")
    public ResponseEntity<ResponseDto> editCustomer(@RequestBody EditCustomerReqDto reqDto) {
        ResponseDto response = this.customerService.editCustomer(reqDto);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatusCode()));
    }
}
