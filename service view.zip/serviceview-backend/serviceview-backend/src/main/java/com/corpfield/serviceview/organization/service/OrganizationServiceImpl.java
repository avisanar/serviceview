package com.corpfield.serviceview.organization.service;

import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.common.exception.ServiceViewException;
import com.corpfield.serviceview.organization.dto.requestDto.CheckDomainAvailableReqDto;
import com.corpfield.serviceview.organization.dto.requestDto.CreateOrganizationReqDto;
import com.corpfield.serviceview.organization.dto.responseDto.CheckDomainAvailableResDto;
import com.corpfield.serviceview.organization.dto.responseDto.OrganizationAdminProfileResDto;
import com.corpfield.serviceview.organization.dto.responseDto.OrganizationAdminResDto;
import com.corpfield.serviceview.organization.enities.Organization;
import com.corpfield.serviceview.organization.enities.OrganizationAdmin;
import com.corpfield.serviceview.organization.facade.OrganizationAdminFacade;
import com.corpfield.serviceview.organization.facade.OrganizationFacade;
import com.corpfield.serviceview.organization.repositories.OrganizationAdminsRepo;
import com.corpfield.serviceview.organization.repositories.OrganizationRepo;
import com.corpfield.serviceview.utils.AuthUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;
@Service
public class OrganizationServiceImpl implements OrganizationService {
    @Autowired
    private OrganizationAdminFacade organizationAdminFacade;

    @Autowired
    private OrganizationFacade organizationFacade;

    @Autowired
    OrganizationAdminsRepo organizationAdminsRepo;

    @Override
    public ResponseDto createOrganizationAdmin(CreateOrganizationReqDto dto) {
        try {
            organizationAdminFacade.checkOrganizationEmailAndMobileNumberAlreadyExistOrNot(dto.getContactEmail(), dto.getContactNumber());
            organizationAdminFacade.checkPassword(dto.getNewPassword(), dto.getConfirmPassword());
            Organization organization = dto.createOrganizationEntity();
            String organizationUuid = UUID.randomUUID().toString().replace("-", "");
            organizationUuid = organizationFacade.checkAlreadyExistOrganizationUuid(organizationUuid);
            organization.setOrganizationUuid(organizationUuid);
            organizationFacade.persistOrganization(organization);
            OrganizationAdmin organizationAdmin = dto.createOrganizationAdmin();
            String organizationAdminUuid = UUID.randomUUID().toString().replace("-", "");
            organizationAdminUuid = organizationAdminFacade.checkOrganizationAdminUuidExistOrNot(organizationAdminUuid);
            organizationAdmin.setOrganizationAdminUuid(organizationAdminUuid);
            organizationAdmin.setOrganization(organization);
            organizationAdminFacade.persistOrganizationAdmin(organizationAdmin);
            OrganizationAdminResDto resDto = new OrganizationAdminResDto().covertEntityToDto(organization, organizationAdmin);
            return new ResponseDto(HttpStatus.OK, "Organization Registered Successfully", resDto);
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }

    @Override
    public ResponseDto checkDomainNameAvailability(CheckDomainAvailableReqDto dto) {
        Organization organization=organizationFacade.findOrganizationByName(dto.getDomainName());
        CheckDomainAvailableResDto resDto=new CheckDomainAvailableResDto();
        System.out.println("kkk");
        if(organization==null){
            resDto.setIsAvailable(true);
        }
        else{
            resDto.setIsAvailable(false);
        }
        return new ResponseDto(HttpStatus.OK,resDto);

    }

    @Override
    public ResponseDto getAdminProfile() {
        try {
            String organizationAdminUuid = AuthUtil.currentUserId();
            OrganizationAdmin organizationAdmin = organizationFacade.findAdminProfileByAdminUuid(organizationAdminUuid);
            OrganizationAdminProfileResDto dto = new OrganizationAdminProfileResDto(organizationAdmin);
            return new ResponseDto(HttpStatus.OK, dto);
        } catch (Exception e) {
            return ServiceViewException.sendErrorResponse(e);
        }
    }
}


