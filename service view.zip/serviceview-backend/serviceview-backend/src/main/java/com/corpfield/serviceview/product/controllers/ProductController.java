package com.corpfield.serviceview.product.controllers;

import com.corpfield.serviceview.common.constants.CommonConstants;
import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.common.utils.ResponseUtil;
import com.corpfield.serviceview.product.dto.requestDto.CreateProductReqDto;
import com.corpfield.serviceview.product.dto.requestDto.EditProductReqDto;
import com.corpfield.serviceview.product.dto.pojo.ProductListFilter;
import com.corpfield.serviceview.product.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class ProductController {

    @Autowired
    ProductService productService;

    @PostMapping("/admin/product")
    public ResponseEntity<ResponseDto> createProduct(@RequestBody CreateProductReqDto reqDto){
        ResponseDto response=this.productService.createProduct(reqDto);
        return ResponseUtil.generateResponse(response);
    }

    @PutMapping("/admin/product")
    public ResponseEntity<ResponseDto> editProduct(@RequestBody EditProductReqDto reqDto){
        ResponseDto response=this.productService.editProduct(reqDto);
        return ResponseUtil.generateResponse(response);
    }

    @GetMapping("/admin/product")
    public ResponseEntity<ResponseDto> getProducts(
            @PageableDefault(size = CommonConstants.DEFAULT_PAGE_SIZE) Pageable pageable,
            @RequestParam(value = "searchKey", required = false) String searchKey,
            @RequestParam(value = "status", required = false) String status){
        ProductListFilter filter=ProductListFilter.builder()
                .searchKey(searchKey)
                .status(status)
                .pageable(pageable)
                .build();
        ResponseDto response=this.productService.getProductsList(filter);
        return ResponseUtil.generateResponse(response);
    }

    @GetMapping("/admin/product/{productId}")
    public ResponseEntity<ResponseDto> getProductById(
            @PathVariable("productId")long productId
    ){
        ResponseDto response=this.productService.getProductById(productId);
        return ResponseUtil.generateResponse(response);
    }
}
