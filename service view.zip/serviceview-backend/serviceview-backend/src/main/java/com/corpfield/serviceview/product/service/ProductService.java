package com.corpfield.serviceview.product.service;

import com.corpfield.serviceview.common.dto.ResponseDto;
import com.corpfield.serviceview.product.dto.requestDto.CreateProductReqDto;
import com.corpfield.serviceview.product.dto.requestDto.EditProductReqDto;
import com.corpfield.serviceview.product.dto.pojo.ProductListFilter;

public interface ProductService {
    ResponseDto createProduct(CreateProductReqDto reqDto);

    ResponseDto editProduct(EditProductReqDto reqDto);

    ResponseDto getProductsList(ProductListFilter filter);

    ResponseDto getProductById(long productId);
}
