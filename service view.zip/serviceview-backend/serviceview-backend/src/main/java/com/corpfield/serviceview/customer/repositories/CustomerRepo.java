package com.corpfield.serviceview.customer.repositories;

import com.corpfield.serviceview.customer.entities.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CustomerRepo extends JpaRepository<Customer, Long> {

    Optional<Customer> findByCustomerPhoneNumber(String customerPhoneNumber);


    Optional<Customer> findByCustomerUuid(String customerUuid);
}
