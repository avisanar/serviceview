package com.corpfield.serviceview.License.dto.responseDto;

import lombok.Data;

import java.util.Date;
@Data
public class PackageSummaryResDto {
    private String planSelected;
    private double CostPerLicense;
    private Date licenseValidity;
    private double licenseCost;
    private double previousBalance;
    private double totalCost;
}
