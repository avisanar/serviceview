package com.corpfield.serviceview.settings.dao;

import com.corpfield.serviceview.organization.enities.OrganizationAdmin;
import com.corpfield.serviceview.settings.dto.pojo.SettingFilterReqDto;
import com.corpfield.serviceview.settings.queries.OrganizationSettingQuery;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

import static com.corpfield.serviceview.utils.QueryUtils.getEndOfTheDay;
import static com.corpfield.serviceview.utils.QueryUtils.getStartOfTheDay;

@Service
public class OrganizationSettingDao {

    @PersistenceContext
    EntityManager em;

    public List<Object[]> findSettingList(OrganizationAdmin organizationAdmin) {
        String sql = OrganizationSettingQuery.FIND_SETTINGS_LIST;
        Query query = em.createNativeQuery(sql)
                .setParameter("organizationId", organizationAdmin.getOrganization().getOrganizationId());
        return query.getResultList();
    }

    public List<Object[]> findDepartmentList(OrganizationAdmin organizationAdmin, SettingFilterReqDto filter) {
        String sql = OrganizationSettingQuery.FIND_DEPARTMENT_LIST;
        Query query = em.createNativeQuery(sql)
                .setParameter("fromDate", getStartOfTheDay(filter.getFromDate()))
                .setParameter("toDate", getEndOfTheDay(filter.getToDate()))
                .setParameter("organizationId", organizationAdmin.getOrganization().getOrganizationId());
        return query.getResultList();
    }

    public List<Object[]> findDeliveryModeList(OrganizationAdmin organizationAdmin, SettingFilterReqDto filter) {
        String sql = OrganizationSettingQuery.FIND_DELIVERY_MODE_LIST;
        Query query = em.createNativeQuery(sql)
                .setParameter("fromDate", getStartOfTheDay(filter.getFromDate()))
                .setParameter("toDate", getEndOfTheDay(filter.getToDate()))
                .setParameter("organizationId", organizationAdmin.getOrganization().getOrganizationId());
        return query.getResultList();
    }
}
