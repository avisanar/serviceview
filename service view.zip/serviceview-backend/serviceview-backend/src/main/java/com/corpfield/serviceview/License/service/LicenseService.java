package com.corpfield.serviceview.License.service;

import com.corpfield.serviceview.License.dto.requestDto.AssignLicenseReqDto;
import com.corpfield.serviceview.License.dto.requestDto.BuyMoreLicenseReqDto;
import com.corpfield.serviceview.License.dto.requestDto.LicensePlanReqDto;
import com.corpfield.serviceview.License.pojo.LicensePlanFilter;
import com.corpfield.serviceview.common.dto.ResponseDto;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface LicenseService {


    ResponseDto getPackageSummary(LicensePlanFilter filter);

    ResponseDto getUsers(Pageable pageable);

    ResponseDto assignLicense(List<AssignLicenseReqDto> dto);

    ResponseDto getPackageDetails(LicensePlanFilter filter);

    ResponseDto getRenewPlanDetails(String licenseUuid);

    ResponseDto createLicensePlan(LicensePlanReqDto reqDto);

    ResponseDto changeLicensePlan(LicensePlanReqDto reqDto);

    ResponseDto renewLicensePlan(LicensePlanReqDto reqDto);

    ResponseDto getExistingLicenseDetails(long addLicense);

    ResponseDto addMoreLicense(BuyMoreLicenseReqDto reqDto);
}
